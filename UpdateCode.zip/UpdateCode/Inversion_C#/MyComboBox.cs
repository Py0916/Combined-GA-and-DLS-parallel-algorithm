﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VelocitySpectral
{
    class MyComboBox : ComboBox
	{
		public MyComboBox(int ColNum=8) : base()
		{
			this.DropDownStyle = ComboBoxStyle.DropDownList;
			this.DrawMode = DrawMode.OwnerDrawFixed;
			fillList(ColNum);
			this.SelectedIndex = 0;
			this.DrawItem += new DrawItemEventHandler(ColorDropDownList_DrawItem);
		}
		private void fillList(int ColNum)
		{
			string[] names = new string[ColNum];
            for (int i = 0; i < ColNum; i++)
            {
				names[i] = (i + 1).ToString();

			}
			this.Items.AddRange(names);
		}
		private void ColorDropDownList_DrawItem(object sender, DrawItemEventArgs e)
		{
			string colorName = (string)this.Items[e.Index];
			Color color = GetColor(e.Index,this.Items.Count);
			Rectangle rect = new Rectangle(e.Bounds.X, e.Bounds.Y, e.Bounds.Width / 4, e.Bounds.Height - 2);
			Brush brush = new SolidBrush(color);
			e.Graphics.DrawRectangle(new Pen(Color.Black), rect);
			rect.X += 1;
			rect.Y += 1;
			rect.Width -= 1;
			rect.Height -= 1;
			e.Graphics.FillRectangle(brush, rect);
			rect.Offset(rect.Width + 4, 0);
			e.Graphics.DrawString(colorName, e.Font, Brushes.Black, rect.Location);
		}
		public static Color GetColor(int Index,int Totle=7)
        {
			if (Index > Totle - 1)
				Index = Totle - 1;
			Bitmap colorRamp = Properties.Resources.Rainbow_White;
			int length = (int)((colorRamp.Width - 1) * (Totle - Index-1) / (Totle-1));

			Color color = colorRamp.GetPixel(colorRamp.Width - length - 1, 1);
			return color;
		}
	}
}
