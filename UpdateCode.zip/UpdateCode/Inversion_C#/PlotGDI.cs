﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace VelocitySpectral
{
    public class PlotGDI
    {





        public double stepX_1, stepX_2;
        public double scaleX_1, scaleX_2;
        public double scaleY_1, scaleY_2;
        public double EdgeWidth_1 = 0.078;//设置panel1边缘距比例
        public double EdgeWidth_2 = 0.22;//设置panel2边缘距比例
        public double EdgeHeight = 0.06;//设置边缘距比例
        private double labelScale_1 = 0.01;//小刻度长度占画板宽的比例
        private double labelScale_2 = 0.03;//小刻度长度占画板宽的比例

        public int EdgeLeft_1 = 50, EdgeRight_1 = 30, EdgeUp_1 = 30, EdgeButton_1 = 30,EdgeLabel=2;//此处是DrawFVGDI中左右上下边距，该图比例为scaleX_1与scaleY_1
        public int EdgeLeft_2 = 50, EdgeRight_2 = 30, EdgeUp_2 = 30, EdgeButton_2 = 30;//此处是DrawHVGDI中左右上下边距，该图比例为scaleX_2与scaleY_2






        /// <summary>
        /// 用于绘制频散曲线彩色图，输入文件为bitmap格式
        /// </summary>
        /// <param name="ImageFile"></param>
        /// <param name="PWidth"></param>
        /// <param name="PHeight"></param>
        /// <param name="FVPlot"></param>
        /// <returns></returns>
        public Bitmap DrawImageGDI_New(string File, int PWidth, int PHeight, double[][][] FVPlot_Multi = null,int EdgeW=60,int EdgeH=40)
        {
            Bitmap ImageFile;
            if(File=="")
            {
                ImageFile = new Bitmap(PWidth,PHeight);
            }
            else
            {
                ImageFile = GetImage(File);
            }
            Bitmap bit = new Bitmap(PWidth-1, PHeight-1);//实例化一个和窗体一样大的bitmap
            Graphics g = Graphics.FromImage(bit);
            g.Clear(Color.White);
            PointF point1 = new PointF();//用于存放单个数据点
            PointF point2 = new PointF();//用于存放单个数据点
            Pen p = new Pen(Color.Black);
            Font FontLabel = new Font("宋体", 10);
            string X;
            Brush brush = new SolidBrush(Color.Black);
            SizeF sizeF;
            Rectangle srcRect;

            Bitmap img = new Bitmap(ImageFile);
            g.DrawImage(img, EdgeW, EdgeH, PWidth-2*EdgeW, PHeight-2*EdgeH + 1);
            point1.X = EdgeW;
            point1.Y = EdgeH;
            point2.X = EdgeW;
            point2.Y = PHeight-EdgeH;
            g.DrawLine(p, point1, point2);//左纵坐标线
            point1.X = PWidth - EdgeW;
            point1.Y = EdgeH;
            point2.X = PWidth - EdgeW;
            point2.Y = PHeight - EdgeH;
            g.DrawLine(p, point1, point2);//右纵坐标线
            X = "V(m/s)";
            sizeF = g.MeasureString(X, FontLabel);
            g.DrawString(X, FontLabel, brush, (float)(EdgeW - sizeF.Width), (float)(PHeight - EdgeH - sizeF.Height * 1.5));//纵坐标title
            for (int i = 0; i <= 10; i++)
            {
                point1.X = EdgeW;
                point1.Y = (PHeight - 2 * EdgeH) * i / 10f + EdgeH;//PHeight * (float)(0.1 + i * 0.08);
                point2.X = EdgeW - 10;
                point2.Y = point1.Y;
                g.DrawLine(p, point1, point2);//左侧纵坐标小刻度

                X = ((10 - i) * 100).ToString();
                sizeF = g.MeasureString(X, FontLabel);
                g.DrawString(X, FontLabel, brush, (float)(point2.X - sizeF.Width), (float)(point1.Y - sizeF.Height * 0.5+1));//左侧纵坐标数字

                point1.X = PWidth-EdgeW;
                point2.X = point1.X + 10;
                g.DrawLine(p, point1, point2);//右侧纵坐标小刻度

                X = ((10 - i) * 100).ToString();
                sizeF = g.MeasureString(X, FontLabel);
                g.DrawString(X, FontLabel, brush, (float)(point2.X ), (float)(point1.Y - sizeF.Height * 0.5+1));//右侧纵坐标数字

            }
            point1.X = EdgeW;
            point1.Y = EdgeH;
            point2.X = PWidth - EdgeW;
            point2.Y = EdgeH;
            g.DrawLine(p, point1, point2);//上横坐标线
            point1.X = EdgeW;
            point1.Y = PHeight - EdgeH;
            point2.X = PWidth - EdgeW;
            point2.Y = PHeight - EdgeH;
            g.DrawLine(p, point1, point2);//下横坐标线
            X = "F(Hz)";
            //g.MeasureString(X, FontLabel,
            sizeF = g.MeasureString(X, FontLabel);
            g.DrawString(X, FontLabel, brush, (float)(EdgeW - sizeF.Width), (float)(PHeight -EdgeH + 10));//横坐标title
            X = "F-V Dispersion Curve";
            //g.MeasureString(X, FontLabel,
            sizeF = g.MeasureString(X, FontLabel);
            g.DrawString(X, FontLabel, brush, (float)(PWidth * 0.5 - sizeF.Width * 0.5), (float)(EdgeH*0.5 - sizeF.Height * 0.1));//横坐标title
            for (int i = 0; i <= 10; i++)
            {
                point1.X = EdgeW + (PWidth - 2 * EdgeW) / 10f * i;//PWidth * (float)(0.15 + i * 0.08);
                point1.Y = PHeight - EdgeH;
                point2.X = point1.X;
                point2.Y = PHeight -EdgeH+10;
                g.DrawLine(p, point1, point2);//横坐标小刻度

                X = (i * 10).ToString();
                sizeF = g.MeasureString(X, FontLabel);
                g.DrawString(X, FontLabel, brush, (float)(point1.X - sizeF.Width * 0.5), (float)(point2.Y + sizeF.Height * 0.2));//横坐标数字
            }
            Brush[] Brs = new SolidBrush[7] { new SolidBrush(Color.Red), new SolidBrush(Color.Green), new SolidBrush(Color.Blue), new SolidBrush(Color.Yellow), new SolidBrush(Color.Cyan), new SolidBrush(Color.Orange), new SolidBrush(Color.Purple) };
            Pen[] Ps = new Pen[7] { new Pen(Color.Red), new Pen(Color.Green), new Pen(Color.Blue), new Pen(Color.Yellow), new Pen(Color.Cyan), new Pen(Color.Orange), new Pen(Color.Purple)};
            for (int k = 0; k < FVPlot_Multi.Count(); k++)
            {
                double[][] FVPlot = FVPlot_Multi[k];
                if (FVPlot != null && FVPlot[1].Max() != 0)
                {
                    brush = Brs[k];
                    p = Ps[k];
                    //brush = new SolidBrush(Color.Black);
                    //p = new Pen(Color.Black);
                    int R = 8;
                    if (FVPlot[1][0] > 0)
                    {
                        point1.X = EdgeW + (PWidth - 2 * EdgeW) * 0.01f * (float)FVPlot[0][0];
                        point1.Y = PHeight - EdgeH - (PHeight - 2 * EdgeH) * 0.001f * (float)FVPlot[1][0];
                        srcRect = new Rectangle((int)point1.X - R / 2, (int)point1.Y - R / 2, R, R);
                        //g.FillRectangle(brush, srcRect);
                        g.FillEllipse(brush, srcRect);
                    }
                        
                    for (int i = 1; i < FVPlot[0].Count(); i++)
                    {
                        if(FVPlot[1][i]>0)
                        {
                            point2.X = EdgeW + (PWidth - 2 * EdgeW) * 0.01f * (float)FVPlot[0][i];
                            point2.Y = PHeight - EdgeH - (PHeight - 2 * EdgeH) * 0.001f * (float)FVPlot[1][i];
                            srcRect = new Rectangle((int)point2.X - R / 2, (int)point2.Y - R / 2, R, R);
                            //g.FillRectangle(brush, srcRect);
                            g.FillEllipse(brush, srcRect);
                            if (FVPlot[1][i-1] > 0)
                            {
                                g.DrawLine(p, point1, point2);
                            }
                            
                            point1.X = point2.X;
                            point1.Y = point2.Y;
                        }
                        
                    }
                }
            }
            
            return bit;
        }
       
        public Bitmap GetImage(string path)
        {
            System.IO.FileStream fs = new System.IO.FileStream(path, System.IO.FileMode.Open, System.IO.FileAccess.Read);
            Bitmap result = new Bitmap(Image.FromStream(fs));
            fs.Close();
            return result;
        }

    }
}
