﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VelocitySpectral
{
    class SurfaceWave
    {
        //注意此处原本Numinc=200，Numpoints=1000，运行200次约20s，改变后约10s
        public static int MaxRoot = 1, Numinc = 100;//分别为模式数，dk数量
        public static int Numpoints = 500, Lambda = 6;
        public static double Tol = 0.01;//误差精度

        public static double[][] FV_Multi(double[] Vs, double[] Thk, double[] Freq, double[] Dns = null, double[] Poisson = null,int MaxRoot=5)
        {
            int N = Vs.Count(),  j;
            double[] Vp = new double[N];

            if (Dns == null || Poisson == null)
            {
                Dns = new double[N];
                Poisson = new double[N];
                for (j = 0; j < N; j++)
                {
                    if (Vs[j] < 250)
                    {
                        Poisson[j] = 0.4;
                    }
                    else if (Vs[j] < 400)
                    {
                        Poisson[j] = 0.3;
                    }
                    else
                    {
                        Poisson[j] = 0.2;
                    }
                    Vp[j] = Math.Sqrt(2 * (1 - Poisson[j]) / (1 - 2 * Poisson[j])) * Vs[j];
                    Dns[j] = 0.31 * Math.Pow(Vp[j], 0.25);
                }
            }
            else
            {
                for (j = 0; j < N; j++)
                {
                    Vp[j] = Math.Sqrt(2 * (1 - Poisson[j]) / (1 - 2 * Poisson[j])) * Vs[j];
                }
            }
            double[][] FVDispersion = QSM_Multi_Root(Vp, Vs, Thk, Dns, Poisson, Freq, MaxRoot);
            //FVDispersion = FV_ModeSeparation(FVDispersion);
            return FVDispersion;
        }
        public static double VrCalculate(double Vs, double Poisson)//由纵横波计算面波波速
        {
            double Vr = (0.87 + 1.12 * Poisson) / (1 + Poisson) * Vs;
            return Vr;
        }


        /// <summary>
        /// 2021-10-10改，求多个根的方法
        /// </summary>
        /// <param name="Vp"></param>
        /// <param name="Vs"></param>
        /// <param name="Thk"></param>
        /// <param name="Dns"></param>
        /// <param name="Poisson"></param>
        /// <param name="Freq"></param>
        /// <param name="MaxRoottmp"></默认求五个根param>
        /// <returns></returns>
        public static double[][] QSM_Multi_Root(double[] Vp, double[] Vs, double[] Thk, double[] Dns, double[] Poisson, double[] Freq, int MaxRoottmp = 5)
        {
            int N = Freq.Count();
            double[][] Vr = new double[MaxRoottmp][];
            double VsMin = Vs.Min(), VsMax = Vs.Max();
            double VrMin, VrMax;
            VrMin = VsMin * 0.9;
            VrMax = VsMax;
            //if (VrMax > Vs.Last())
            //{
            //    VrMax = Vs.Last();//面波波速不能大于最底层横波波速
            //}
            for (int x = 0; x < MaxRoottmp; x++)
            {
                Vr[x] = new double[N];
            }
            double ct1, ct2, cx1, cx2, dct, ctOld = 0, cxOld = 0;
            double[] cxTrial = new double[Numinc + 1], ctTrial = new double[Numinc + 1];
            int Numroot, Search;
            Numinc = 400;
            double start = 100, end = 500;
            //VrMin = 100; VrMax = 600;
            if (Vs.Count() == 1)//只有一层的情况,所有频率波速都一样
            {
                for (int i = 0; i < N; i++)
                {
                    Vr[0][i] = VrCalculate(Vs[0], Poisson[0]);
                }
            }
            else
            {

                for (int i = 0; i < N; i++)
                {
                    Numroot = 0;
                    if (i == 0)
                    {
                        Numinc = 500;
                        start = VrMin;
                        end = VrMax;
                    }
                    else
                    {
                        Search = 150;
                        Numinc = 800;
                        start = Math.Max(VrMin, ctOld - Search);//默认搜索区间是上一个频点的-50~+50m/s
                        end = Math.Min(VrMax, ctOld + Search*2);
                    }

                    dct = (end - start) / Numinc;

                    ct1 = start;
                    cx1 = QuickScalarMatrix(ct1, Freq[i], Vp, Vs, Thk, Dns);
                    ctOld = ct1;
                    cxOld = cx1;
                    for (int j = 1; j < Numinc; j++)
                    {
                        ct1 = ctOld;
                        cx1 = cxOld;
                        ct2 = start + dct * j;
                        cx2 = QuickScalarMatrix(ct2, Freq[i], Vp, Vs, Thk, Dns);
                        ctOld = ct2;
                        cxOld = cx2;

                        if (cx1 * cx2 < 0)
                        {
                            Vr[Numroot][i] = ct2 - cx2 * (ct2 - ct1) / (cx2 - cx1);
                            Numroot++;

                        }
                        if (Numroot == MaxRoottmp)
                        {
                            ctOld = Vr[0][i];
                            break;
                        }
                        if (j == Numinc - 1)
                            ctOld = Vr[0][i];
                    }
                }
            }
            return Vr;
        }



        /// <单次QSM求解>
        /// </summary>
        /// <param name="ct">单次波速</param>
        /// <param name="f">单次频率</param>
        /// <param name="Vp">纵波波速</param>
        /// <param name="Vs">横波波速</param>
        /// <param name="Thk">层厚</param>
        /// <param name="Dns">密度g/cm^3</param>
        /// <returns></returns>
        public static double QuickScalarMatrix(double ct, double f, double[] Vp, double[] Vs, double[] Thk, double[] Dns)
        {
            int N = Vp.Count();
            double kk = 2 * Math.PI * f / ct;

            //注此处只有Rp，Rs，p，q可能为实数，可能为虚数，其他的都是实数
            Complex[] Rp = new Complex[N], Rs = new Complex[N], p = new Complex[N - 1], q = new Complex[N - 1];
            double[] t = new double[N], g = new double[N], r = new double[N - 1], s = new double[N - 1],
                a = new double[N - 1], b = new double[N - 1], c = new double[N - 1],
                d = new double[N - 1], l = new double[N - 1];

            double x1, x2, x3, x4, x5, p1, p2, p3, p4, p5, q1, q2, q3, q4;
            //注：对于面波波速ct始终小于最下面层的vp和vs，所以Rp[N-1]和Rs[N-1]始终为纯虚数
            for (int i = 0; i < N; i++)
            {

                if (ct >= Vp[i])
                {
                    Rp[i] = new Complex(Math.Sqrt(Math.Pow(ct / Vp[i], 2) - 1));
                }
                else
                {
                    Rp[i] = new Complex(0, Math.Sqrt(1 - Math.Pow(ct / Vp[i], 2)));
                }
                if (ct >= Vs[i])
                {
                    Rs[i] = new Complex(Math.Sqrt(Math.Pow(ct / Vs[i], 2) - 1));
                }
                else
                {
                    Rs[i] = new Complex(0, Math.Sqrt(1 - Math.Pow(ct / Vs[i], 2)));
                }
                t[i] = 1 - ct * ct / (2 * Vs[i] * Vs[i]);
                g[i] = 1 - t[i];
                //Rp[i] = Math.Sqrt(Math.Pow(ct / Vp[i], 2) - 1);
                //Rs[i] = Math.Sqrt(Math.Pow(ct / Vs[i], 2) - 1);
                //t[i] = 1 - Math.Pow(ct, 2) / (2 * Math.Pow(Vs[i], 2));
                //g[i] = 1 - t[i];
            }
            for (int i = 0; i < N - 1; i++)
            {
                r[i] = ct * ct / (Vp[i] * Vp[i]) - 1;
                s[i] = ct * ct / (Vs[i] * Vs[i]) - 1;
                p[i] = Rp[i].MultiplyRe(kk * Thk[i]);
                q[i] = Rs[i].MultiplyRe(kk * Thk[i]);
                a[i] = p[i].Cos().Real;
                b[i] = q[i].Cos().Real;
                if (Rp[i].Abs() == 0)
                {
                    c[i] = kk * Thk[i];
                }
                else
                {
                    c[i] = (p[i].Sin() / Rp[i]).Real;
                }
                if (Rs[i].Abs() == 0)
                {
                    d[i] = kk * Thk[i];
                }
                else
                {
                    d[i] = (q[i].Sin() / Rs[i]).Real;
                }
                l[i] = Math.Pow(Vs[i + 1], 2) * Dns[i + 1] / (Math.Pow(Vs[i], 2) * Dns[i]);

                //r[i] = Math.Pow(Rp[i], 2);
                //s[i] = Math.Pow(Rs[i], 2);
                //p[i] = Rp[i] * kk * Thk[i];
                //q[i] = Rs[i] * kk * Thk[i];
                //a[i] = Math.Cos(p[i]);
                //b[i] = Math.Cos(q[i]);
                //c[i] = Math.Sin(p[i]) / Rp[i];
                //d[i] = Math.Sin(q[i]) / Rs[i];
                //l[i] = Math.Pow(Vs[i + 1], 2) * Dns[i + 1] / (Math.Pow(Vs[i], 2) * Dns[i]);
            }
            //{//论文
            //    double tmp = (Rp[N - 1] * Rs[N - 1]).Real;
            //    x1 = 1 + tmp;
            //    x2 = t[N - 1] + tmp;
            //    x3 = -t[N - 1] * t[N - 1] - tmp;
            //    //注：对于面波波速ct始终小于最下面层的vp和vs，所以Rp[N-1]和Rs[N-1]始终为纯虚数
            //    x4 = g[N - 1] * (-1) * Rs[N - 1].Imaginary;
            //    x5 = g[N - 1] * Rp[N - 1].Imaginary;
            //    //x4 = Rs[N - 1] * g[N - 1].Multiply(new Complex(0, 1));
            //    //x5 = Rp[N - 1] * g[N - 1].Multiply(new Complex(0, -1));
            //}


            {//代码
                double tmp = (Rp[N - 1] * Rs[N - 1]).Real;
                x1 = 1 + tmp;
                x2 = t[N - 1] + tmp;
                x3 = g[N - 1] * (-1) * Rp[N - 1].Imaginary;
                x4 = g[N - 1] * Rp[N - 1].Imaginary;
                x5 = -t[N - 1] * t[N - 1] - tmp;
            }


            //x1 = new Complex(1 + Rp[N - 1] * Rs[N - 1]);
            //x2 = new Complex(t[N - 1] + Rp[N - 1] * Rs[N - 1]);
            //x3 = new Complex(0, Rp[N - 1] * g[N - 1]);
            //x4 = new Complex(0, -Rp[N - 1] * g[N - 1]);
            //x5 = new Complex(-Math.Pow(t[N - 1], 2) - Rp[N - 1] * Rs[N - 1]);
            for (int i = N - 2; i >= 0; i--)
            {
                //{//论文
                //    x1 = x1 / l[i];
                //    x3 = x3 * l[i];
                //    p1 = x1 - 2*x2 - x3;
                //    p2 = -x1 * t[i]*t[i] + 2*x2 * t[i] + x3;
                //    p3 = x4 * g[i];
                //    p4 = x5 * g[i];
                //    p5 = -x1 * t[i] + x2 * (1 + t[i]) + x3;
                //    q1 = a[i] * b[i] * p1 + c[i] * d[i] * p2 - a[i] * d[i] * p3 + b[i] * c[i] * p4;
                //    q2 = c[i] * d[i] * r[i] * s[i] * p1 + a[i] * b[i] * p2 + b[i] * c[i] * r[i] * p3 - a[i] * d[i] * s[i] * p4;
                //    q3 = a[i] * d[i] * s[i] * p1 - b[i] * c[i] * p2 + a[i] * d[i] * p3 + c[i] * d[i] * s[i] * p4;
                //    q4 = -b[i] * c[i] * r[i] * p1 + a[i] * d[i] * p2 + c[i] * d[i] * r[i] * p3 + a[i] * b[i] * p4;
                //    x1 = q1 - q2 + 2 * p5;
                //    x2 = q1 * t[i] - q2 - p5 * (1 + t[i]);
                //    x3 = -q1 * t[i] * t[i] + q2 - p5 * 2 * t[i];
                //    x4 = q3 * g[i];
                //    x5 = q4 * g[i];
                //}
                {//代码
                    x1 = x1 / l[i];
                    x5 = x5 * l[i];
                    p1 = -x1 * t[i] + x2 * (1 + t[i]) + x5;
                    p2 = x1 - 2 * x2 - x5;
                    p3 = x3 * g[i];
                    p4 = -x4 * g[i];
                    p5 = -x1 * t[i] * t[i] + 2 * x2 * t[i] + x5;
                    q1 = a[i] * b[i] * p2 + c[i] * d[i] * p5 - a[i] * d[i] * p3 - b[i] * c[i] * p4;
                    q2 = a[i] * d[i] * s[i] * p2 - b[i] * c[i] * p5 + a[i] * b[i] * p3 - c[i] * d[i] * s[i] * p4;
                    q3 = b[i] * c[i] * r[i] * p2 - a[i] * d[i] * p5 - c[i] * d[i] * r[i] * p3 + a[i] * b[i] * p4;
                    q4 = c[i] * d[i] * r[i] * s[i] * p2 + a[i] * b[i] * p5 + b[i] * c[i] * r[i] * p3 + a[i] * d[i] * s[i] * p4;
                    x1 = q1 - q4 + 2 * p1;
                    x2 = q1 * t[i] - q4 + p1 * (1 + t[i]);
                    x3 = q2 * g[i];
                    x4 = -q3 * g[i];
                    x5 = -q1 * t[i] * t[i] + q4 - 2 * p1 * t[i];
                }
                //x1 = x1.MultiplyRe(1 / l[i]);
                //x5 = x5.MultiplyRe(1 / l[i]);
                //p1 = x1.MultiplyRe(-t[i]) + x2.MultiplyRe(1 + t[i]) + x5;
                //p2 = x1 - x2.MultiplyRe(2) - x5;
                //p3 = x3.MultiplyRe(g[i]);
                //p4 = x4.MultiplyRe(-g[i]);
                //p5 = x1.MultiplyRe(-Math.Pow(t[i], 2)) + x2.MultiplyRe(2 * t[i]) + x5;
                //q1 = p2.MultiplyRe(a[i] * b[i]) + p5.MultiplyRe(c[i] * d[i]) - p3.MultiplyRe(a[i] * d[i]) - p4.MultiplyRe(b[i] * c[i]);
                //q2 = p2.MultiplyRe(a[i] * d[i] * s[i]) - p5.MultiplyRe(b[i] * c[i]) + p3.MultiplyRe(a[i] * b[i]) - p4.MultiplyRe(c[i] * d[i] * s[i]);
                //q3 = p2.MultiplyRe(b[i] * c[i] * r[i]) - p5.MultiplyRe(a[i] * d[i]) - p3.MultiplyRe(c[i] * d[i] * r[i]) + p4.MultiplyRe(a[i] * b[i]);
                //q4 = p2.MultiplyRe(c[i] * d[i] * r[i] * s[i]) + p5.MultiplyRe(a[i] * b[i]) + p3.MultiplyRe(b[i] * c[i] * r[i]) + p4.MultiplyRe(a[i] * d[i] * s[i]);
                //x1 = q1 - q4 + p1.MultiplyRe(2);
                //x2 = q1.MultiplyRe(t[i]) - q4 + p1.MultiplyRe(1 + t[i]);
                //x3 = q2.MultiplyRe(g[i]);
                //x4 = q3.MultiplyRe(-g[i]);
                //x5 = q1.MultiplyRe(-Math.Pow(t[i], 2)) + q4 - p1.MultiplyRe(2 * t[i]);
            }
            return x5;
            //Complex[] Rp = new Complex[N], Rs = new Complex[N], t = new Complex[N], g = new Complex[N];
            //Complex[] r = new Complex[N - 1], s = new Complex[N - 1], p = new Complex[N - 1], 
            //    q = new Complex[N - 1],a = new Complex[N - 1], b = new Complex[N - 1], 
            //    c = new Complex[N - 1], d = new Complex[N - 1],l = new Complex[N - 1];
            //Complex x1, x2, x3, x4, x5,p1,p2,p3,p4,p5,q1,q2,q3,q4;


            //for (int i=0;i<N;i++)
            //{
            //    if (ct >= Vp[i])
            //    {
            //        Rp[i] = new Complex(Math.Sqrt(Math.Pow(ct / Vp[i], 2) - 1));
            //    }
            //    else
            //    {
            //        Rp[i] = new Complex(0, Math.Sqrt(1 - Math.Pow(ct / Vp[i], 2)));
            //    }
            //    if (ct >= Vs[i])
            //    {
            //        Rs[i] = new Complex(Math.Sqrt(Math.Pow(ct / Vs[i], 2) - 1));
            //    }
            //    else
            //    {
            //        Rs[i] = new Complex(0, Math.Sqrt(1 - Math.Pow(ct / Vs[i], 2)));
            //    }
            //    t[i] = new Complex(1 - Math.Pow(ct, 2) / (2 * Math.Pow(Vs[i], 2)));
            //    g[i] = new Complex(1) - t[i];
            //    //Rp[i] = Math.Sqrt(Math.Pow(ct / Vp[i], 2) - 1);
            //    //Rs[i] = Math.Sqrt(Math.Pow(ct / Vs[i], 2) - 1);
            //    //t[i] = 1 - Math.Pow(ct, 2) / (2 * Math.Pow(Vs[i], 2));
            //    //g[i] = 1 - t[i];
            //}
            //for (int i=0;i<N-1;i++)
            //{
            //    r[i] = Rp[i].Pow(2);
            //    s[i] = Rs[i].Pow(2);
            //    p[i] = Rp[i].MultiplyRe(kk * Thk[i]);
            //    q[i] = Rs[i].MultiplyRe(kk * Thk[i]);
            //    a[i] = p[i].Cos();
            //    b[i] = q[i].Cos();
            //    c[i] = p[i].Sin() / Rp[i];
            //    d[i] = q[i].Sin() / Rs[i];
            //    l[i] = new Complex(Math.Pow(Vs[i + 1], 2) * Dns[i + 1] / (Math.Pow(Vs[i], 2) * Dns[i]));

            //    //r[i] = Math.Pow(Rp[i], 2);
            //    //s[i] = Math.Pow(Rs[i], 2);
            //    //p[i] = Rp[i] * kk * Thk[i];
            //    //q[i] = Rs[i] * kk * Thk[i];
            //    //a[i] = Math.Cos(p[i]);
            //    //b[i] = Math.Cos(q[i]);
            //    //c[i] = Math.Sin(p[i]) / Rp[i];
            //    //d[i] = Math.Sin(q[i]) / Rs[i];
            //    //l[i] = Math.Pow(Vs[i + 1], 2) * Dns[i + 1] / (Math.Pow(Vs[i], 2) * Dns[i]);
            //}
            //{//论文
            //    x1 = new Complex(1) + Rp[N - 1] * Rs[N - 1];
            //    x2 = t[N - 1] + Rp[N - 1] * Rs[N - 1];
            //    x3 = t[N - 1].Pow(2).MultiplyRe(-1) - Rp[N - 1] * Rs[N - 1];
            //    x4 = Rs[N - 1] * g[N - 1].Multiply(new Complex(0, 1));
            //    x5 = Rp[N - 1] * g[N - 1].Multiply(new Complex(0, -1));
            //}


            ////{//代码
            ////    x1 = new Complex(1) + Rp[N - 1] * Rs[N - 1];
            ////    x2 = t[N - 1] + Rp[N - 1] * Rs[N - 1];
            ////    x3 = Rs[N - 1] * g[N - 1].Multiply(new Complex(0, 1));
            ////    x4 = Rp[N - 1] * g[N - 1].Multiply(new Complex(0, -1));
            ////    x5 = t[N - 1].Pow(2).MultiplyRe(-1) - Rp[N - 1] * Rs[N - 1];
            ////}


            ////x1 = new Complex(1 + Rp[N - 1] * Rs[N - 1]);
            ////x2 = new Complex(t[N - 1] + Rp[N - 1] * Rs[N - 1]);
            ////x3 = new Complex(0, Rp[N - 1] * g[N - 1]);
            ////x4 = new Complex(0, -Rp[N - 1] * g[N - 1]);
            ////x5 = new Complex(-Math.Pow(t[N - 1], 2) - Rp[N - 1] * Rs[N - 1]);
            //for (int i=N-2;i>=0;i--)
            //{
            //    {//论文
            //        x1 = x1 / l[i];
            //        x3 = x3 / l[i];
            //        p1 = x1 - x2.MultiplyRe(2) - x3;
            //        p2 = x1.MultiplyRe(-1) * t[i].Pow(2) + x2.MultiplyRe(2) * t[i] + x3;
            //        p3 = x4 * g[i];
            //        p4 = x5 * g[i];
            //        p5 = x1 * t[i].MultiplyRe(-1) + x2 * (new Complex(1) + t[i]) + x3;
            //        q1 = a[i] * b[i] * p1 + c[i] * d[i] * p2 - a[i] * d[i] * p3 + b[i] * c[i] * p4;
            //        q2 = c[i] * d[i] * r[i] * s[i] * p1 + a[i] * b[i] * p2 + b[i] * c[i] * r[i] * p3 - a[i] * d[i] * s[i] * p4;
            //        q3 = a[i] * d[i] * s[i] * p1 - b[i] * c[i] * p2 + a[i] * d[i] * p3 + c[i] * d[i] * s[i] * p4;
            //        q4 = b[i] * c[i] * r[i] * p1.MultiplyRe(-1) + a[i] * d[i] * p2 + c[i] * d[i] * r[i] * p3 + a[i] * b[i] * p4;
            //        x1 = q1 - q2 + p5.MultiplyRe(2);
            //        x2 = q1 * t[i] - q2 - p5 * (new Complex(1) + t[i]);
            //        x3 = q1.MultiplyRe(-1) * t[i].Pow(2) + q2 - p5.MultiplyRe(2) * t[i];
            //        x4 = q3 * g[i];
            //        x5 = q4 * g[i];
            //    }
            //    //{//代码
            //    //    x1 = x1 / l[i];
            //    //    x5 = x5 / l[i];
            //    //    p1 = x1.MultiplyRe(-1) * t[i] + x2 * (new Complex(1) + t[i]) + x5;
            //    //    p2 = x1 - x2.MultiplyRe(2) - x5;
            //    //    p3 = x3 * g[i];
            //    //    p4 = x4 * g[i].MultiplyRe(-1);
            //    //    p5 = x1 * t[i].Pow(2).MultiplyRe(-1) + x2 * t[i].MultiplyRe(2) + x5;
            //    //    q1 = a[i] * b[i] * p2 + c[i] * d[i] * p5 - a[i] * d[i] * p3 - b[i] * c[i] * p4;
            //    //    q2 = a[i] * d[i] * s[i] * p2 - b[i] * c[i] * p5 + a[i] * b[i] * p3 - c[i] * d[i] * s[i] * p4;
            //    //    q3 = b[i] * c[i] * r[i] * p2 - a[i] * d[i] * p5 - c[i] * d[i] * r[i] * p3 + a[i] * b[i] * p4;
            //    //    q4 = c[i] * d[i] * r[i] * s[i] * p2 + a[i] * b[i] * p5 + b[i] * c[i] * r[i] * p3 + a[i] * d[i] * s[i] * p4;
            //    //    x1 = q1 - q4 + p1.MultiplyRe(2);
            //    //    x2 = q1 * t[i] - q4 + p1 * (new Complex(1) + t[i]);
            //    //    x3 = q2 * g[i];
            //    //    x4 = q3 * g[i].MultiplyRe(-1);
            //    //    x5 = q1.MultiplyRe(-1) * t[i].Pow(2) + q4 - p1.MultiplyRe(2) * t[i];
            //    //}
            //    //x1 = x1.MultiplyRe(1 / l[i]);
            //    //x5 = x5.MultiplyRe(1 / l[i]);
            //    //p1 = x1.MultiplyRe(-t[i]) + x2.MultiplyRe(1 + t[i]) + x5;
            //    //p2 = x1 - x2.MultiplyRe(2) - x5;
            //    //p3 = x3.MultiplyRe(g[i]);
            //    //p4 = x4.MultiplyRe(-g[i]);
            //    //p5 = x1.MultiplyRe(-Math.Pow(t[i], 2)) + x2.MultiplyRe(2 * t[i]) + x5;
            //    //q1 = p2.MultiplyRe(a[i] * b[i]) + p5.MultiplyRe(c[i] * d[i]) - p3.MultiplyRe(a[i] * d[i]) - p4.MultiplyRe(b[i] * c[i]);
            //    //q2 = p2.MultiplyRe(a[i] * d[i] * s[i]) - p5.MultiplyRe(b[i] * c[i]) + p3.MultiplyRe(a[i] * b[i]) - p4.MultiplyRe(c[i] * d[i] * s[i]);
            //    //q3 = p2.MultiplyRe(b[i] * c[i] * r[i]) - p5.MultiplyRe(a[i] * d[i]) - p3.MultiplyRe(c[i] * d[i] * r[i]) + p4.MultiplyRe(a[i] * b[i]);
            //    //q4 = p2.MultiplyRe(c[i] * d[i] * r[i] * s[i]) + p5.MultiplyRe(a[i] * b[i]) + p3.MultiplyRe(b[i] * c[i] * r[i]) + p4.MultiplyRe(a[i] * d[i] * s[i]);
            //    //x1 = q1 - q4 + p1.MultiplyRe(2);
            //    //x2 = q1.MultiplyRe(t[i]) - q4 + p1.MultiplyRe(1 + t[i]);
            //    //x3 = q2.MultiplyRe(g[i]);
            //    //x4 = q3.MultiplyRe(-g[i]);
            //    //x5 = q1.MultiplyRe(-Math.Pow(t[i], 2)) + q4 - p1.MultiplyRe(2 * t[i]);
            //}
            //return x3.Real;
        }
    }
}
