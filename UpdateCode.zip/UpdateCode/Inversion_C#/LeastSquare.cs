﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace VelocitySpectral
{
    class LeastSquare
    {

        public static Tuple<List<double[]>, List<double[]>, List<double[][]>, List<double>> M_LeastSqrInv(double[] Vs, double[] Thk, double[] Freq, double[][] V_m, int MaxRoot = 3, int MaxTimes = 20, int InvType = 0, double[] Dns = null, double[] Poisson = null, int dV = 10, double dThk = 0.1, int ErroeLevel = 1)
        {
            int M = Freq.Count() * MaxRoot, N = Vs.Count();//M是频率数，N层数，A矩阵(M*N)
            double[][] V_th0, V_th1;
            //double[] V_th0_1, V_th1_1, V_m_1;
            //V_m_1 = Array2Dto1D(V_m);//将二维变成一维，用于矩阵计算
            double[] VMod0 = new double[N], VMod1 = new double[N], ThkMod0 = new double[N - 1], ThkMod1 = new double[N - 1];
            int n;
            if (InvType == 0)
            {
                n = N;//定深度时n=Vs个数N
            }
            else if (InvType == 1)
            {
                n = N - 1;//定速度时n=Thk个数N-1
            }
            else
            {
                n = N * 2 - 1;//变深速时，n=N+N-1
            }

            double[,] dX = new double[n, 1];
            double[,] dY;
            double[,] g = new double[n, 1];
            double[,] A;//定义雅克比矩阵A(M,n)
            double[,] v = new double[n, n];//阻尼因子，默认0.5^2=0.25
            for (int i = 0; i < n; i++)
                v[i, i] = 0.25;
            double[] dXJugde = new double[n];
            dXJugde[0] = 100;//给个默认的大值，否则第一次迭代就跳出循环

            //输入的模型及迭代误差
            List<double[]> VsSave = new List<double[]>();
            List<double[]> ThkSave = new List<double[]>();
            List<double[][]> V_thSave = new List<double[][]>();
            List<double> Rms = new List<double>();
            VMod0 = DataClone(Vs);
            ThkMod0 = DataClone(Thk);
            ////导入初始模型,传值，避免对原数组改变
            //for (int i = 0; i < N; i++)
            //{
            //    VMod0[i] = Vs[i];//传值，避免对原数组改变
            //}
            //for (int i = 0; i < N - 1; i++)
            //{
            //    ThkMod0[i] = Thk[i];//传值，避免对原数组改变
            //}
            if (Dns == null || Poisson == null)
            {
                Poisson = new double[N];
                Dns = new double[N];
                for (int j = 0; j < N; j++)
                {
                    if (VMod0[j] < 250)
                    {
                        Poisson[j] = 0.4;
                    }
                    else if (VMod0[j] < 400)
                    {
                        Poisson[j] = 0.3;
                    }
                    else
                    {
                        Poisson[j] = 0.2;
                    }
                    double tmp2 = Math.Sqrt(2 * (1 - Poisson[j]) / (1 - 2 * Poisson[j])) * VMod0[j];
                    Dns[j] = 0.31 * Math.Pow(tmp2, 0.25);
                }
            }
            //Dns = null; Poisson = null;
            V_th0 = SurfaceWave.FV_Multi(VMod0, ThkMod0, Freq, Dns, Poisson, MaxRoot);//先计算初始模型速度值
            //V_th0_1 = Array2Dto1D(V_th0);
            double tmp = Multi_RmsErrorCalculate(V_th0, V_m);
            VsSave.Add(DataClone(VMod0));
            ThkSave.Add(DataClone(ThkMod0));
            V_thSave.Add(DataClone(V_th0));
            Rms.Add(tmp);
            if (tmp < ErroeLevel) //如果误差满足要求，则停止，否则继续迭代
            {
                return new Tuple<List<double[]>, List<double[]>, List<double[][]>, List<double>>(VsSave, ThkSave, V_thSave, Rms);
            }
            int[][] V_effective;
            for (int Time = 0; Time < MaxTimes; Time++)//默认最多迭代20次
            {
                V_effective = GetEffectiveV(V_th0, V_m);
                M = V_effective.Count();
                dY = new double[M, 1];
                A = new double[M, n];
                //先求雅克比矩阵A(M,n)
                //以下开始逐个改变变量求偏导数
                int j = 0;
                VMod1 = DataClone(VMod0);
                ThkMod1 = DataClone(ThkMod0);
                
                if (InvType == 0)//定深模式
                {
                    for (; j < n; j++) //速度偏导数
                    {
                        VMod1[j] += dV;//变量增加
                        V_th1 = SurfaceWave.FV_Multi(VMod1, ThkMod1, Freq, Dns, Poisson, MaxRoot);//先计算初始模型速度值
                        //V_th1_1 = Array2Dto1D(V_th1)
                        VMod1[j] -= dV;//变量还原
                        for (int i = 0; i < M; i++)
                        {
                            A[i, j] = (V_th1[V_effective[i][0]][V_effective[i][1]] - V_th0[V_effective[i][0]][V_effective[i][1]]) / dV;//求取差分偏导数
                        }
                    }
                    
                }
                else if (InvType == 1)//定速模式
                {
                    for (; j < n; j++) //厚度偏导数
                    {
                        ThkMod1[j] += dThk;//变量增加
                        V_th1 = SurfaceWave.FV_Multi(VMod1, ThkMod1, Freq, Dns, Poisson, MaxRoot);//先计算初始模型速度值
                        //V_th1_1 = Array2Dto1D(V_th1);
                        ThkMod1[j] -= dThk;//变量还原
                        for (int i = 0; i < M; i++)
                        {
                            A[i, j] = (V_th1[V_effective[i][0]][V_effective[i][1]] - V_th0[V_effective[i][0]][V_effective[i][1]]) / dThk;//求取差分偏导数
                        }
                    }
                }
                else
                {
                    for (; j < N; j++) //速度偏导数
                    {
                        VMod1[j] += dV;//变量增加
                        V_th1 = SurfaceWave.FV_Multi(VMod1, ThkMod1, Freq, Dns, Poisson, MaxRoot);//先计算初始模型速度值
                        //V_th1_1 = Array2Dto1D(V_th1);
                        VMod1[j] -= dV;//变量还原
                        for (int i = 0; i < M; i++)
                        {
                            A[i, j] = (V_th1[V_effective[i][0]][V_effective[i][1]] - V_th0[V_effective[i][0]][V_effective[i][1]]) / dV;//求取差分偏导数
                        }
                    }
                    for (; j < n; j++) //厚度偏导数
                    {
                        ThkMod1[j - N] += dThk;//变量增加
                        V_th1 = SurfaceWave.FV_Multi(VMod1, ThkMod1, Freq, Dns, Poisson, MaxRoot);//先计算初始模型速度值
                        //V_th1_1 = Array2Dto1D(V_th1);
                        ThkMod1[j - N] -= dThk;//变量还原
                        for (int i = 0; i < M; i++)
                        {
                            A[i, j] = (V_th1[V_effective[i][0]][V_effective[i][1]] - V_th0[V_effective[i][0]][V_effective[i][1]]) / dThk;//求取差分偏导数
                        }
                    }
                }
                for (int i = 0; i < M; i++)
                {

                    dY[i, 0] = V_m[V_effective[i][0]][V_effective[i][1]] - V_th0[V_effective[i][0]][V_effective[i][1]];//dY为实测值与理论模型值差值
                }
                g = Matrix.MultiplyMatrix(Matrix.Transpose(A), dY);
                dX = Matrix.MultiplyMatrix(Matrix.ReverseMatrix(Matrix.AddMatrix(Matrix.MultiplyMatrix(Matrix.Transpose(A), A), v)), g);
                //初始模型+计算得到的dX
                if (InvType == 0)//定深，只改变速度模型
                {
                    for (int i = 0; i < N; i++)
                    {
                        VMod0[i] += dX[i, 0];
                        if (VMod0[i] > 1000)
                            VMod0[i] = 1000;
                        else if (VMod0[i] < 50)
                            VMod0[i] = 50;
                    }
                }
                else if (InvType == 1)//定速，只改变深度模型
                {
                    for (int i = 0; i < N - 1; i++)
                    {
                        ThkMod0[i] += dX[i, 0];
                        if (ThkMod0[i] > 40)
                            ThkMod0[i] = 40;
                        else if (ThkMod0[i] < 0.5)
                            ThkMod0[i] = 0.5;
                    }
                }
                else//变深速模式，改变深度和速度模型
                {
                    for (int i = 0; i < N; i++)
                    {
                        VMod0[i] += dX[i, 0];
                        //VMod0[i] = Math.Round(VMod0[i] + dX[i, 0]);
                        if (VMod0[i] > 1000)
                            VMod0[i] = 1000;
                        else if (VMod0[i] < 50)
                            VMod0[i] = 50;
                    }
                    for (int i = 0; i < N - 1; i++)
                    {
                        ThkMod0[i] += dX[i + N, 0];
                        //ThkMod0[i] = Math.Round(ThkMod0[i] + dX[i + N, 0], 1);
                        if (ThkMod0[i] > 10)//因遗传算法中厚度只能表示成0.5~31m
                            ThkMod0[i] = 10;
                        else if (ThkMod0[i] < 1)
                            ThkMod0[i] = 1;
                    }
                }

                for (int i = 0; i < n; i++)
                {
                    dXJugde[i] = Math.Abs(dX[i, 0]);
                }
                Console.WriteLine("DLS_"+(Time+1).ToString());

                V_th0 = SurfaceWave.FV_Multi(VMod0, ThkMod0, Freq, Dns, Poisson, MaxRoot);//先计算初始模型速度值
                //V_th0_1 = Array2Dto1D(V_th0);
                tmp = Multi_RmsErrorCalculate( V_th0, V_m);
                VsSave.Add(DataClone(VMod0));
                ThkSave.Add(DataClone(ThkMod0));
                V_thSave.Add(DataClone(V_th0));
                Rms.Add(tmp);
                if (tmp < ErroeLevel || (dXJugde.Sum() < 10 && dXJugde.Sum() > -10)) //如果误差满足要求，则停止，否则继续迭代
                {
                    break;
                }
            }
            return new Tuple<List<double[]>, List<double[]>, List<double[][]>, List<double>>(VsSave, ThkSave, V_thSave, Rms);
        }
        private static int[][] GetEffectiveV(double[][] V_th0, double[][] V_m)
        {
            int M = V_m.Count();
            int N = V_m[0].Count();
            List<int[]> t1 = new List<int[]>();
            //if(Type==0)
            //{
            for (int i = 0; i < M; i++)
            {
                for (int j = 0; j < N; j++)
                {
                    if (V_m[i][j] > 49 && V_th0[i][j] > 49)
                    {
                        t1.Add(new int[] { i, j });
                    }
                }
            }
            return t1.ToArray();

        }

        public static double Multi_RmsErrorCalculate(double[][] TheoryVs, double[][] TestVs)
        {
            int M = TheoryVs.Count();
            int N = TheoryVs[0].Count();
            double RmsError;
            double temp = 0;
            int MM = 0;
            for (int i = 0; i < M; i++)
            {
                for (int j = 0; j < N; j++)
                {
                    if (TheoryVs[i][j] != 0 && TestVs[i][j] != 0)
                    {
                        temp += Math.Pow(TheoryVs[i][j] - TestVs[i][j], 2);
                        MM++;
                    }

                }
            }

            RmsError = Math.Sqrt(temp / MM);

            return RmsError;
        }


        private static T DataClone<T>(T RealObject)
        {
            using (Stream objectStream = new MemoryStream())
            {
                //利用 System.Runtime.Serialization序列化与反序列化完成引用对象的复制
                IFormatter formatter = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();
                formatter.Serialize(objectStream, RealObject);
                objectStream.Seek(0, SeekOrigin.Begin);
                return (T)formatter.Deserialize(objectStream);
            }
        }
    }
}
