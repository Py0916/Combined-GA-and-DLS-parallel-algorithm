﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VelocitySpectral
{
    //Complex [,] B=new Complex[2,2]{{new Complex(1,2),new Complex(2,2)},{new Complex(5,-1),new Complex(2,3)}};
    //已和matlab测试过B的逆，值，结果一致。ComplexMatrix.InvertAugmented(B);ComplexMatrix.Determinant(B);
    //Complex[,] ZZ = new Complex[2, 2] { { new Complex(1), new Complex(2) }, { new Complex(4), new Complex(3) } };
    //ComplexMatrix.Multiply(ZZ,ZZ);
    //注意：数组[,] zz = new {{},{}},每个{}写的列向量
    class ComplexMatrix
    {
        //CMatrixPart用于复数矩阵，实部和虚部分离
        public static Tuple<double[,], double[,]> CMatrixPart(Complex[,] CMatrixIn)
        {
            int M = CMatrixIn.GetLength(0), N = CMatrixIn.GetLength(1);
            double[,] CMatrix_Re = new double[M, N], CMatrix_Im = new double[M, N];
            for (int i = 0; i < M; i++)
            {
                for (int j = 0; j < N; j++)
                {
                    CMatrix_Re[i, j] = CMatrixIn[i, j].Real;
                    CMatrix_Im[i, j] = CMatrixIn[i, j].Imaginary;
                }
            }
            Tuple<double[,], double[,]> tup = new Tuple<double[,], double[,]>(CMatrix_Re, CMatrix_Im);
            return tup;
        }

        //CMatrixMerge用于实部和虚部矩阵合并成复数矩阵
        public static Complex[,] CMatrixMerge(double[,] CMatrix_Re, double[,] CMatrix_Im)
        {
            int M = CMatrix_Re.GetLength(0), N = CMatrix_Re.GetLength(1);
            Complex[,] CMatrixOut = new Complex[M, N];
            for (int i = 0; i < M; i++)
            {
                for (int j = 0; j < N; j++)
                {
                    CMatrixOut[i, j] = new Complex(CMatrix_Re[i, j], CMatrix_Im[i, j]);
                    //CMatrixOut[i, j].Real = CMatrix_Re[i, j];
                    //CMatrixOut[i, j].Imaginary = CMatrix_Im[i, j];
                }
            }

            return CMatrixOut;
        }
        ///   <summary> 
        ///   复数矩阵加法 
        ///   </summary> 
        ///   <param   name= "MatrixEin "> </param> 
        ///   <param   name= "MatrixZwei "> </param> 
        public static Complex[,] AddMatrix(Complex[,] MatrixC1, Complex[,] MatrixC2)
        {
            int M = MatrixC1.GetLength(0), N = MatrixC1.GetLength(1);
            Complex[,] MatrixResult = new Complex[M, N];
            if (M != MatrixC2.GetLength(0) || N != MatrixC2.GetLength(1))
            {
                return MatrixResult;
            }
            for (int i = 0; i < M; i++)
                for (int j = 0; j < N; j++)
                    MatrixResult[i, j] = new Complex(MatrixC1[i, j].Real + MatrixC2[i, j].Real, MatrixC1[i, j].Imaginary + MatrixC2[i, j].Imaginary);
            return MatrixResult;
        }

        ///   <summary> 
        ///   复数矩阵减法 
        ///   </summary> 
        ///   <param   name= "MatrixEin "> </param> 
        ///   <param   name= "MatrixZwei "> </param> 
        public static Complex[,] SubMatrix(Complex[,] MatrixC1, Complex[,] MatrixC2)
        {
            int M = MatrixC1.GetLength(0), N = MatrixC1.GetLength(1);
            Complex[,] MatrixResult = new Complex[M, N];
            if (M != MatrixC2.GetLength(0) || N != MatrixC2.GetLength(1))
            {
                return MatrixResult;
            }
            for (int i = 0; i < M; i++)
                for (int j = 0; j < N; j++)
                    MatrixResult[i, j] = new Complex(MatrixC1[i, j].Real - MatrixC2[i, j].Real, MatrixC1[i, j].Imaginary - MatrixC2[i, j].Imaginary);
            return MatrixResult;
        }

        ///   <summary> 
        ///   复数矩阵与实数的乘法 
        ///   </summary> 
        ///   <param   name= "MatrixEin "> </param> 
        ///   <param   name= "MatrixZwei "> </param> 
        public static Complex[,] MultiplyRe(Complex[,] MatrixC1, double Re)
        {
            int M = MatrixC1.GetLength(0), N = MatrixC1.GetLength(1);
            Complex[,] MatrixResult = new Complex[M, N];
            if (M == 0 || N == 0)
            {
                return MatrixResult;
            }
            for (int i = 0; i < M; i++)
                for (int j = 0; j < N; j++)
                    MatrixResult[i, j] = new Complex(MatrixC1[i, j].Real * Re, MatrixC1[i, j].Imaginary * Re);
            return MatrixResult;
        }

        /**
		 * 复矩阵的乘法
		 * 
		 * @param AR - 左边复矩阵的实部矩阵
		 * @param AI - 左边复矩阵的虚部矩阵
		 * @param BR - 右边复矩阵的实部矩阵
		 * @param BI - 右边复矩阵的虚部矩阵
		 * @param CR - 乘积复矩阵的实部矩阵
		 * @param CI - 乘积复矩阵的虚部矩阵
		 * @return bool型，复矩阵乘法是否成功
		 */
        public static Complex[,] Multiply(Complex[,] A, Complex[,] B)
        {
            Complex[,] MatrixResult = new Complex[A.GetLength(0), B.GetLength(1)];
            for (int i = 0; i < A.GetLength(0); i++)
            {
                for (int j = 0; j < B.GetLength(1); j++)
                {
                    MatrixResult[i, j] = new Complex();
                    for (int k = 0; k < A.GetLength(1); k++)
                    {
                        MatrixResult[i, j] += A[i, k] * B[k, j];
                    }
                }
            }
            return MatrixResult;
        }
        ///   <summary> 
        ///   矩阵的转置 
        ///   </summary> 
        ///   <param   name= "iMatrix "> </param> 
        public static Complex[,] Transpose(Complex[,] iMatrix,int type=1)
        {
            int row = iMatrix.GetLength(0);
            int column = iMatrix.GetLength(1);
            //double[,] iMatrix = new double[column, row];
            Complex[,] TempMatrix = new Complex[row, column];
            Complex[,] iMatrixT = new Complex[column, row];
            for (int i = 0; i < row; i++)
            {
                for (int j = 0; j < column; j++)
                {
                    TempMatrix[i, j] = iMatrix[i, j];
                }
            }
            for (int i = 0; i < column; i++)
            {
                for (int j = 0; j < row; j++)
                {
                    iMatrixT[i, j] = TempMatrix[j, i];
                }
            }
            if (type==2)//type=1默认直接转置，type=2是共轭转置，matlab默认虚数矩阵转置是type=2
            {
                for (int i = 0; i < column; i++)
                {
                    for (int j = 0; j < row; j++)
                    {
                        iMatrixT[i, j] = iMatrixT[i, j].Conjugate();
                    }
                }
            }
            return iMatrixT;

        }
        //{ 
        //double[,] AR, AI, BR, BI;
        //Tuple<double[,], double[,]> tup = CMatrixPart(A);
        //AR = tup.Item1;AI = tup.Item2;
        //tup = CMatrixPart(B);
        //BR = tup.Item2;BI = tup.Item2;
        //Complex[,] CMatrixOut=new Complex[AR.GetLength(0),AR.GetLength(1)];
        //// 首先检查行列数是否符合要求
        //if (AR.GetLength(0) != AI.GetLength(0) ||
        //    AR.GetLength(1) != AI.GetLength(1) ||
        //    BR.GetLength(0) != BI.GetLength(0) ||
        //    BR.GetLength(1) != BI.GetLength(1) ||
        //    AR.GetLength(1) != BR.GetLength(0))
        //    return CMatrixOut;

        //// 构造乘积矩阵实部矩阵和虚部矩阵
        //double[,] mtxCR = new double[AR.GetLength(0), BR.GetLength(1)];
        //double[,] mtxCI = new double[AR.GetLength(0), BR.GetLength(1)];
        //// 复矩阵相乘
        //for (int i = 0; i < AR.GetLength(0); i++)
        //{
        //    for (int j = 0; j < BR.GetLength(1); j++)
        //    {
        //        double vr = 0;
        //        double vi = 0;
        //        for (int k = 0; k < AR.GetLength(1); k++)
        //        {
        //            double p = AR[i, k] * BR[k, j];
        //            double q = AI[i, k] * BI[k, j];
        //            double s = (AR[i, k] + AI[i, k]) * (BR[k, j] + BI[k, j]);

        //            vr += p - q;
        //            vi += s - p - q;
        //        }
        //        mtxCR[i, j] = vr;
        //        mtxCI[i, j] = vi;
        //    }
        //}
        //CMatrixOut = CMatrixMerge(mtxCR, mtxCI);
        //return CMatrixOut;
        //}
        ///   <summary> 
        ///   矩阵的逆矩阵 另一种简单方法，源自实数矩阵逆运算Augmented matrix增广矩阵求逆法
        ///   </summary> 
        ///   <param   name= "iMatrix "> </param> 
        public static Complex[,] InvertAugmented(Complex[,] iMatrix)
        {
            int i = 0;
            int row = iMatrix.GetLength(0);
            Complex[,] MatrixZwei = new Complex[row, row * 2];
            Complex[,] iMatrixInv = new Complex[row, row];
            for (i = 0; i < row; i++)
            {
                for (int j = 0; j < row; j++)
                {
                    MatrixZwei[i, j] = iMatrix[i, j];
                }
            }
            for (i = 0; i < row; i++)
            {
                for (int j = row; j < row * 2; j++)
                {
                    MatrixZwei[i, j] = new Complex(0);
                    if (i + row == j)
                        MatrixZwei[i, j] = new Complex(1);
                }
            }

            for (i = 0; i < row; i++)
            {
                if (MatrixZwei[i, i] != new Complex(0))
                {
                    Complex intTemp = MatrixZwei[i, i];
                    for (int j = 0; j < row * 2; j++)
                    {
                        MatrixZwei[i, j] = MatrixZwei[i, j] / intTemp;
                    }
                }
                for (int j = 0; j < row; j++)
                {
                    if (j == i)
                        continue;
                    Complex intTemp = MatrixZwei[j, i];
                    for (int k = 0; k < row * 2; k++)
                    {
                        MatrixZwei[j, k] = MatrixZwei[j, k] - MatrixZwei[i, k] * intTemp;
                    }
                }
            }

            for (i = 0; i < row; i++)
            {
                for (int j = 0; j < row; j++)
                {
                    iMatrixInv[i, j] = MatrixZwei[i, j + row];
                }
            }
            return iMatrixInv;
        }

        /**
		 * 复矩阵求逆的全选主元高斯－约当法
		 * 
		 * @param mtxImag - 复矩阵的虚部矩阵，当前矩阵为复矩阵的实部
		 * @return bool型，求逆是否成功
		 */
        public static Complex[,] InvertGaussJordan(Complex[,] CMatrixIn)
        {

            int M = CMatrixIn.GetLength(0);
            Complex[,] CMatrixOut = new Complex[M, M];
            if (M != CMatrixIn.GetLength(1) || M == 0)
            {
                return CMatrixOut;
            }
            else if (M == 1)
            {
                double aa, bb;
                aa = CMatrixIn[0, 0].Real;
                bb = CMatrixIn[0, 0].Imaginary;
                CMatrixOut[0, 0].SetReAndIm(aa / (aa * aa + bb * bb), -bb / (aa * aa + bb * bb));
                return CMatrixOut;
            }
            double[,] CMatrixIn_Re, CMatrixIn_Im;
            Tuple<double[,], double[,]> tup = CMatrixPart(CMatrixIn);
            CMatrixIn_Re = tup.Item1; CMatrixIn_Im = tup.Item2;
            int i, j, k;
            //int l, u, v, w;
            double p, q, s, t, d, b;

            // 分配内存
            int[] pnRow = new int[M];
            int[] pnCol = new int[M];

            // 消元
            for (k = 0; k <= M - 1; k++)
            {
                d = 0.0;
                for (i = k; i <= M - 1; i++)
                {
                    for (j = k; j <= M - 1; j++)
                    {
                        //u = i * M + j;
                        //CMatrixIn_Re[i, j]对应elements[u]
                        //CMatrixIn_Im[i, j]对应 mtxImag.elements[u]
                        p = CMatrixIn_Re[i, j] * CMatrixIn_Re[i, j] + CMatrixIn_Im[i, j] * CMatrixIn_Im[i, j];
                        if (p > d)
                        {
                            d = p;
                            pnRow[k] = i;
                            pnCol[k] = j;
                        }
                    }
                }

                // 失败
                if (d == 0.0)
                {
                    return CMatrixOut;
                }

                if (pnRow[k] != k)
                {
                    for (j = 0; j <= M - 1; j++)
                    {
                        //u = k * M + j;
                        //CMatrixIn_Re[k, j]对应elements[u]
                        //CMatrixIn_Im[k, j]对应 mtxImag.elements[u]
                        //v = pnRow[k] * M + j;
                        //CMatrixIn_Re[pnRow[k], j]对应elements[v]
                        //CMatrixIn_Im[pnRow[k], j]对应 mtxImag.elements[v]

                        t = CMatrixIn_Re[k, j];
                        CMatrixIn_Re[k, j] = CMatrixIn_Re[pnRow[k], j];
                        CMatrixIn_Re[pnRow[k], j] = t;
                        t = CMatrixIn_Im[k, j];
                        CMatrixIn_Im[k, j] = CMatrixIn_Im[pnRow[k], j];
                        CMatrixIn_Im[pnRow[k], j] = t;
                    }
                }

                if (pnCol[k] != k)
                {
                    for (i = 0; i <= M - 1; i++)
                    {
                        //u = i * M + k;
                        //CMatrixIn_Re[i, k]对应elements[u]
                        //CMatrixIn_Im[i, k]对应 mtxImag.elements[u]
                        //v = i * M + pnCol[k];
                        //CMatrixIn_Re[i, pnCol[k]]对应elements[v]
                        //CMatrixIn_Im[i, pnCol[k]]对应 mtxImag.elements[v]

                        t = CMatrixIn_Re[i, k];
                        CMatrixIn_Re[i, k] = CMatrixIn_Re[i, pnCol[k]];
                        CMatrixIn_Re[i, pnCol[k]] = t;
                        t = CMatrixIn_Im[i, k];
                        CMatrixIn_Im[i, k] = CMatrixIn_Im[i, pnCol[k]];
                        CMatrixIn_Im[i, pnCol[k]] = t;
                    }
                }

                //l = k * M + k;
                //CMatrixIn_Re[k, k]对应elements[l]
                //CMatrixIn_Im[k, k]对应 mtxImag.elements[l]
                CMatrixIn_Re[k, k] = CMatrixIn_Re[k, k] / d; CMatrixIn_Im[k, k] = -CMatrixIn_Im[k, k] / d;
                for (j = 0; j <= M - 1; j++)
                {
                    if (j != k)
                    {
                        //u = k * M + j;
                        //CMatrixIn_Re[k, j]对应elements[u]
                        //CMatrixIn_Im[k, j]对应 mtxImag.elements[u]
                        p = CMatrixIn_Re[k, j] * CMatrixIn_Re[k, k];
                        q = CMatrixIn_Im[k, j] * CMatrixIn_Im[k, k];
                        s = (CMatrixIn_Re[k, j] + CMatrixIn_Im[k, j]) * (CMatrixIn_Re[k, k] + CMatrixIn_Im[k, k]);
                        CMatrixIn_Re[k, j] = p - q;
                        CMatrixIn_Im[k, j] = s - p - q;
                    }
                }

                for (i = 0; i <= M - 1; i++)
                {
                    if (i != k)
                    {
                        //v = i * M + k;
                        //CMatrixIn_Re[i, k]对应elements[v]
                        //CMatrixIn_Im[i, k]对应 mtxImag.elements[v]
                        for (j = 0; j <= M - 1; j++)
                        {
                            if (j != k)
                            {
                                //u = k * M + j;
                                //CMatrixIn_Re[k, j]对应elements[u]
                                //CMatrixIn_Im[k, j]对应 mtxImag.elements[u]
                                //w = i * M + j;
                                //CMatrixIn_Re[i, j]对应elements[w]
                                //CMatrixIn_Im[i, j]对应 mtxImag.elements[w]
                                p = CMatrixIn_Re[k, j] * CMatrixIn_Re[i, k];
                                q = CMatrixIn_Im[k, j] * CMatrixIn_Im[i, k];
                                s = (CMatrixIn_Re[k, j] + CMatrixIn_Im[k, j]) * (CMatrixIn_Re[i, k] + CMatrixIn_Im[i, k]);
                                t = p - q;
                                b = s - p - q;
                                CMatrixIn_Re[i, j] = CMatrixIn_Re[i, j] - t;
                                CMatrixIn_Im[i, j] = CMatrixIn_Im[i, j] - b;
                            }
                        }
                    }
                }

                for (i = 0; i <= M - 1; i++)
                {
                    if (i != k)
                    {
                        //u = i * M + k;
                        //CMatrixIn_Re[i, k]对应elements[u]
                        //CMatrixIn_Im[i, k]对应 mtxImag.elements[u]
                        p = CMatrixIn_Re[i, k] * CMatrixIn_Re[k, k];
                        q = CMatrixIn_Im[i, k] * CMatrixIn_Im[k, k];
                        s = (CMatrixIn_Re[i, k] + CMatrixIn_Im[i, k]) * (CMatrixIn_Re[k, k] + CMatrixIn_Im[k, k]);
                        CMatrixIn_Re[i, k] = q - p;
                        CMatrixIn_Im[i, k] = p + q - s;
                    }
                }
            }

            // 调整恢复行列次序
            for (k = M - 1; k >= 0; k--)
            {
                if (pnCol[k] != k)
                {
                    for (j = 0; j <= M - 1; j++)
                    {
                        //u = k * M + j;
                        //CMatrixIn_Re[k, j]对应elements[u]
                        //CMatrixIn_Im[k, j]对应 mtxImag.elements[u]
                        //v = pnCol[k] * M + j;
                        //CMatrixIn_Re[pnCol[k], j]对应elements[v]
                        //CMatrixIn_Im[pnCol[k], j]对应 mtxImag.elements[v]
                        t = CMatrixIn_Re[k, j];
                        CMatrixIn_Re[k, j] = CMatrixIn_Re[pnCol[k], j];
                        CMatrixIn_Re[pnCol[k], j] = t;
                        t = CMatrixIn_Im[k, j];
                        CMatrixIn_Im[k, j] = CMatrixIn_Im[pnCol[k], j];
                        CMatrixIn_Im[pnCol[k], j] = t;
                    }
                }

                if (pnRow[k] != k)
                {
                    for (i = 0; i <= M - 1; i++)
                    {
                        //u = i * M + k;
                        //CMatrixIn_Re[i, k]对应elements[u]
                        //CMatrixIn_Im[i, k]对应 mtxImag.elements[u]
                        //v = i * M + pnRow[k];
                        //CMatrixIn_Re[i, pnRow[k]]对应elements[v]
                        //CMatrixIn_Im[i, pnRow[k]]对应 mtxImag.elements[v]
                        t = CMatrixIn_Re[i, k];
                        CMatrixIn_Re[i, k] = CMatrixIn_Re[i, pnRow[k]];
                        CMatrixIn_Re[i, pnRow[k]] = t;
                        t = CMatrixIn_Im[i, k];
                        CMatrixIn_Im[i, k] = CMatrixIn_Im[i, pnRow[k]];
                        CMatrixIn_Im[i, pnRow[k]] = t;
                    }
                }
            }
            CMatrixOut = CMatrixMerge(CMatrixIn_Re, CMatrixIn_Im);
            // 成功返回
            return CMatrixOut;
        }

        /// <summary>
        /// 递归计算行列式的值
        /// </summary>
        /// <param name="MatrixEin">矩阵</param>
        /// <returns></returns>
        public static Complex Determinant(Complex[,] MatrixEin)
        {
            int N = MatrixEin.GetLength(0);
            //二阶及以下行列式直接计算
            if (N != MatrixEin.GetLength(1))
            {
                return new Complex();
            }
            else if (N == 0)
            {
                return new Complex();
            }
            else if (N == 1)
            {
                return MatrixEin[0, 0];
            }
            else if (N == 2)
            {

                return MatrixEin[0, 0] * MatrixEin[1, 1] - MatrixEin[0, 1] * MatrixEin[1, 0];
            }


            //对第一行使用“加边法”递归计算行列式的值
            double dSign = 1;
            Complex dSum = new Complex();
            for (int i = 0; i < N; i++)
            {
                Complex[,] matrixTemp = new Complex[N - 1, N - 1];

                for (int j = 0; j < N - 1; j++)
                {
                    for (int k = 0; k < N - 1; k++)
                    {
                        matrixTemp[j, k] = MatrixEin[j + 1, k >= i ? k + 1 : k];
                    }
                }

                dSum += MatrixEin[0, i] * Determinant(matrixTemp).MultiplyRe(dSign);
                dSign = dSign * -1;
            }

            return dSum;
        }
    }
}
