﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VelocitySpectral
{
    class SurferPlot
    {
        //一维排序测试
        //double[,] A = new double[10, 2] { { 1, 1 }, { 2, 2 }, { 3, 3 }, { 4, 3 }, { 5, 3 }, { 5, 1 }, { 6, 4 }, { 6, 1 }, { 6, 34 }, { 3, 1 } };
        //double[,]B= SurferPlot.Sort1D(A);
        //二维排序测试
        //double[,] A = new double[4, 3] { { 2, 22, 2 }, { 2, 3, 7 }, { 21, 4, 9 }, { -2, 8, 7 } };
        //SurferPlot.Sort2D(A);

        //一维拉格朗日插值测试
        //double[] A = new double[9] { 1, 2, 3, 4, 5, 6, 7, 8, 9 }, B = new double[9] { 1, 2, 3, 4, 5, 4, 3, 2, 1 };
        //SurferPlot.Lagrange1D(A,B,100);

        //拉格朗日二维插值验证代码
        //double[] A = new double[9] { 1, 2, 3, 4, 5, 6, 7, 8, 9 }, B = new double[9] { 1, 2, 3, 4, 5, 4, 3, 2, 1 };
        //SurferPlot.Lagrange1D(A, B, 100);
        //double[,] C = new double[9, 9];
        //for (int i = 0; i < 9; i++) { for (int j = 0; j < 9; j++) { C[i, j] = B[j]; } }
        //double[,] D = SurferPlot.Lagrange2D(81, 81, C,A,A);

        /// <summary>
        /// 拉格朗日插值，输入散点及插值X，输入插值后Y
        /// </summary>
        /// <param name="X"></插值散点X坐标>
        /// <param name="Y"></插值散点Y坐标>
        /// <param name="OutX"></需要计算的X坐标>
        /// <returns></returns>
        public static double Lagrange(double [] X,double [] Y,double OutX)
        {
            
            int N = X.Count();
            double  s, OutY=0;
            if (N!=Y.Count()||N<2)
            {
                MessageForm MBox = new MessageForm("输入点过少！", 0);
                MBox.ShowDialog();
                return -1;
            }
            else if (N==2)
            {
                OutY =1.0* Y[0] * (OutX - X[1]) - Y[1] * (OutX - X[0]) / (X[0] - X[1]);
            }
            else
            {
                OutY = 0;
                for (int i=0;i<N;i++)
                {
                    s = 1.0;
                    for (int j=0;j<N;j++)
                    {
                        if (i!=j)
                        {
                            s *= (OutX - X[j])*1.0 / (X[i] - X[j]);//l(i)
                        }
                    }
                    OutY += s * Y[i];//l(i)*y(i)
                }
            }
            return Math.Round(OutY,5);
        }
        /// <summary>
        /// 一维拉格朗日插值，默认的4点插值，首尾3点插值
        /// </summary>
        /// <param name="X"></散点X坐标>
        /// <param name="Y"></散点Y坐标>
        /// <param name="M"></插值后点数，不是插值间隔数>
        /// <returns></returns>
        public static double[] Lagrange1D(double[] X,double[] Y,int M )
        {
            double dx = (X.Last() - X.First()) / (M-1);
            double[] OutY = new double[M];
            int N = X.Count(),NTemp,m;
            double[] XIn3 = new double[3], YIn3 = new double[3], XIn4 = new double[4], YIn4 = new double[4];
            if (N!=Y.Count()||N<3)
            {
                MessageForm MBox = new MessageForm("输入散点长度过小！", 0);
                MBox.ShowDialog();
                return null;
            }
            //TempY.Add(Y[0]);
            m = 0;
            OutY[m] = Y[0];
            m++;
            NTemp = (int)((X[1] - X[0]) / dx);
            XIn3 = new double[3] { X[0], X[1], X[2] };
            YIn3 = new double[3] { Y[0], Y[1], Y[2] };
            for (int j=0;j<NTemp;j++)
            {
                OutY[m] = Lagrange(XIn3, YIn3, X[0] + dx * m);//第一个区间和最后一个区间是3点，分开
                m++;
            }
            for (int i=1;i<N-2;i++)
            {
                NTemp= (int)((X[i+1] - X[0]) / dx-m+1);
                //NTemp = (int)((X[1] - X[0]) / dx);
                XIn4 = new double[4] { X[i-1], X[i], X[i+1],X[i+2] };
                YIn4 = new double[4] { Y[i-1], Y[i], Y[i+1],Y[i+2] };
                for (int j = 0; j < NTemp; j++)
                {
                    OutY[m] = Lagrange(XIn4, YIn4, X[0] + dx * m);//中间区间为4点
                    m++;
                }
            }
            NTemp = (int)((X[N - 1] - X[0]) / dx - m+1);
            XIn3 = new double[3] { X[N-3], X[N-2], X[N-1] };
            YIn3 = new double[3] { Y[N-3], Y[N-2], Y[N-1] };
            for (int j = 0; j < NTemp; j++)
            {
                OutY[m] = Lagrange(XIn3, YIn3, X[0] + dx * m);//第一个区间和最后一个区间是3点，分开
                m++;
            }
            return OutY;
        }
        /// <summary>
        /// 二维拉格朗日变换,只能处理规格的二维散点图
        /// </summary>
        /// <param name="M"></param>
        /// <param name="N"></param>
        /// <param name="DataIn"></param>
        /// <param name="X"></param>
        /// <param name="Y"></param>
        /// <param name="Type"></0DataIn就是网格化后的异常值，1DataIn是N行3列的dat数据>
        /// <returns></returns>
        public static double[,] Lagrange2D(int M, int N, double[,] DataIn, double[] X, double[] Y)
        {
            double[,] Z= DataIn;
            if (X.Count() < 3|| Y.Count() < 3)
            {
                MessageForm MBox = new MessageForm("二维数据行数过小！", 0);
                MBox.ShowDialog();
                return null;
            }
            int m = Y.Count(), n = X.Count();//m,n是原数据的行列
            //M是行，N是列
            double dx = (X.Last() - X.First()) / (N - 1);
            double dy = (Y.Last() - Y.First()) / (M - 1);
            double[,] OutZ = new double[M, N];
            double[][]  OutZTemp1 = new double[m][], OutZTemp2 = new double[N][];
            double[] ZColtemp=new double[m],ZRowTemp=new double[n];
            
            for (int i=0;i<m;i++)//先对每行作列变换
            {
                for(int j=0;j<n;j++)
                {
                    ZRowTemp[j] = Z[i, j];
                }
                OutZTemp1[i] = new double[N];
                OutZTemp1[i] = Lagrange1D(X, ZRowTemp, N);
            }
            for (int j = 0; j < N; j++)
            {
                for (int i = 0; i < m; i++)
                {
                    ZColtemp[i] = OutZTemp1[i][j];
                }
                OutZTemp2[j] = new double[M];
                OutZTemp2[j] = Lagrange1D(Y, ZColtemp, M);
            }
            for(int i=0;i<M;i++)
            {
                for (int j=0;j<N;j++)
                {
                    OutZ[i,j] = OutZTemp2[j][i];
                }
            }
            return OutZ;
        }
        /// <summary>
        /// 一维排序，默认的从小到大,注意X中元素不可相同
        /// </summary>
        /// <param name="DataIn"></param>
        /// <returns></returns>
        public static double[,] Sort1D(double[,] DataIn)
        {
            if(DataIn.GetLength(1)!=2)
            {
                MessageForm MBox = new MessageForm("一维排序只能对两列数据进行！", 0);
                MBox.ShowDialog();
                return null;
            }
            int M = DataIn.GetLength(0);
            double[] X = new double[M], Y = new double[M];
            for(int i=0;i<M;i++)
            {
                X[i] = DataIn[i, 0];
                Y[i] = DataIn[i, 1];
            }
            List<double> XTemp = X.ToList();
            XTemp.Sort();
            double[,] DataOut = new double[M,2];
            HashSet<double> XH = new HashSet<double>(XTemp);
            if(XH.Count()== XTemp.Count())//如果没有重复项就按下面进行
            {
                for (int i = 0; i < M; i++)
                {
                    DataOut[i, 0] = XTemp[i];
                    DataOut[i, 1] = Y[Array.LastIndexOf(X, XTemp[i])];
                }
            }
            else
            {
                List<double> XListTemp = X.ToList();
                for (int i = 0; i < M; i++)
                {
                    DataOut[i, 0] = XTemp[i];
                    if (i > 0 && XTemp[i] == XTemp[i - 1]) //如果存在与上一个X相同时
                    {
                        XListTemp.RemoveAt(XListTemp.LastIndexOf(XTemp[i - 1]));//先删除上一个
                        DataOut[i, 1] = Y[XListTemp.LastIndexOf(XTemp[i])];//再取最后一个
                    }
                    else
                    {
                        DataOut[i, 1] = Y[Array.LastIndexOf(X, XTemp[i])];
                        XListTemp = X.ToList();//为了不影响其他数据的顺序，结束重复项排序之后须对XListTemp初始化
                    }
                }
            } 
            return DataOut;
        }
        /// <summary>
        /// 分别返回X(m)数组，Y(n)数组，排序后的XYZ3列数组，绘制等值线二维Z(m*n)数组
        /// </summary>
        /// <param name="DataIn"></param>
        /// <returns></returns>
        public static Tuple<double[], double[], double[,],double[,]> Sort2D(double[,] DataIn)
        {
            if (DataIn.GetLength(1) != 3)
            {
                MessageForm MBox = new MessageForm("二维排序只能对三列数据进行！", 0);
                MBox.ShowDialog();
                return null;
            }
            int M = DataIn.GetLength(0);
            double[,] DataOut = new double[M,3];
            double[] X = new double[M], Y = new double[M],Z=new double[M];
            List<double> XList = new List<double>(), YList = new List<double>(), ZList = new List<double>(), XListSort = new List<double>(), YListSort = new List<double>(),XListTemp;
            for (int i = 0; i < M; i++)
            {
                X[i] = DataIn[i, 0];
                Y[i] = DataIn[i, 1];
                Z[i] = DataIn[i, 2];
            }
            XList = X.ToList();
            YList = Y.ToList();
            ZList = Z.ToList();
            HashSet<double> XH = new HashSet<double>(XList);
            XListSort = XH.ToList();
            XListSort.Sort();
            HashSet<double> YH = new HashSet<double>(YList);
            YListSort = YH.ToList();
            YListSort.Sort();
            int m = XListSort.Count;
            List<int> XIndex=new List<int>();
            int i_All = 0;
            for(int i=0;i<m;i++)
            {
                XIndex = new List<int>();
                XListTemp = X.ToList();
                while (XListTemp.Count > 0 && XListTemp.LastIndexOf(XListSort[i]) != -1) 
                {
                    int temp = XListTemp.LastIndexOf(XListSort[i]);
                    XIndex.Add(temp);
                    XListTemp.RemoveAt(temp);
                }
                int mtemp = XIndex.Count;
                double[,] tempIn = new double[mtemp, 2], tempOut = new double[mtemp, 2];
                for (int ii = 0; ii < mtemp; ii++) 
                {
                    tempIn[ii, 0] = Y[XIndex[ii]];
                    tempIn[ii, 1] = Z[XIndex[ii]];
                }
                if(tempIn.GetLength(0)>1)
                {
                    tempOut = Sort1D(tempIn);
                }
                else
                {
                    tempOut = tempIn;
                }
                for (int ii=0; ii < mtemp; ii++)
                {
                    DataOut[i_All, 0] = XListSort[i];
                    DataOut[i_All, 1] = tempOut[ii, 0];
                    DataOut[i_All, 2] = tempOut[ii, 1];
                    i_All++;
                }
            }
            int n = DataOut.GetLength(0) / m;
            double[,] DataOut2 = new double[m, n];
            
            for(int i=0;i<m;i++)
            {
                for(int j=0;j<n;j++)
                {
                    DataOut2[i, j] = DataOut[i * n + j, 2];
                }
            }
           
            return new Tuple<double[], double[], double[,],double[,]>(XListSort.ToArray(), YListSort.ToArray(), DataOut,DataOut2);
        }
        public static double[,] KrigingInterpolation(double[,] DataIn, double[] X, double[] Y)
        {
            
            List<double[]> TempList = new List<double[]>();
            double tempXmin=X[0], tempXmax=X.Last(), tempYmin=Y[0],tempYmax=Y.Last();
            int nDataRaw = DataIn.GetLength(0);
            for (int i=0;i<nDataRaw;i++)
            {
                if(DataIn[i,0]>=tempXmin&& DataIn[i, 0] <= tempXmax && DataIn[i, 1] >= tempYmin && DataIn[i, 1] <= tempYmax)//去除超出边界的数据
                {
                    TempList.Add(new double[3] { DataIn[i, 0], DataIn[i, 1], DataIn[i, 2] });
                }
            }
            int cnt = TempList.Count;

            int rows = Y.Count(), cols = X.Count();
            int mode = 1;
            double c0 = 0.0001f;
            double c1 = 1.3f;
            double a = 9f;
            
            double[] values = new double[cnt];
            double[] pos = new double[cnt * 2];
            for(int i=0;i<cnt;i++)
            {
                pos[2 * i] = TempList[i][0];
                pos[2 * i + 1] = TempList[i][1];
                values[i] = TempList[i][2];
            }
            double[,] resNode =doKriging(mode, values, pos, Y, X, c0, c1, a);
            return resNode;
        }
        
        public static double[,] doKriging(int mode, double[] ValuesRaw,  double[] posRaw, double[] RowsValue, double[] ColsValue, double c0, double c1, double a)
        {
            int  i, j;
            double i_f, j_f;
            
            int resol_x= RowsValue.Count(), resol_y= ColsValue.Count();
            double[,] resNode = new double[resol_x, resol_y];
            double[] result = new double[2];
            double dx =3*( ColsValue[1] - ColsValue[0]), dy =10*( RowsValue[1] - RowsValue[0]);
            int NRaw = ValuesRaw.Count();
            for (j = 0; j < resol_y; j++)
            {
                j_f = ColsValue[j];
                for (i = 0; i < resol_x; i++)
                {
                    i_f = RowsValue[i];
                    Tuple<double[], double[]> tup = NearPosChoose(i_f, j_f, ValuesRaw, posRaw, dx, dy);
                    double[] Values = tup.Item1;
                    double[] pos = tup.Item2;
                    double[] VInverse = VInverseCal(pos, Values, mode, a, c0, c1);
                    result = onceKriging(VInverse, i_f, j_f, pos, Values, mode, a, c0, c1);
                    resNode[i, j] = result[0];

                }
            }
            return resNode;
        }
        public static Tuple<double [],double[]> NearPosChoose(double i_f,double j_f,double[] ValuesRaw,double[] PosRaw,double dx,double dy)
        {
            int item = 50;
            int N = ValuesRaw.Count();
            List<int> tempIndex=new List<int>();
            List<double> tempDistance = new List<double>();
            for (int i=0;i<N;i++)
            {
                double Xtemp = PosRaw[2 * i];
                double Ytemp = PosRaw[2 * i+1];

                if (i_f > Ytemp - dy && i_f < Ytemp + dy && j_f > Xtemp - dx && j_f < Xtemp + dx)
                {
                    double dis = (Xtemp - j_f) * (Xtemp - j_f) + (Ytemp - i_f) * (Ytemp - i_f);
                    tempIndex.Add(i);
                    tempDistance.Add(dis);
                }
            }
            while(tempIndex.Count<item)
            {
                tempIndex = new List<int>();
                tempDistance = new List<double>();
                dx *= 1.5;dy *= 1.5;
                for (int i = 0; i < N; i++)
                {
                    double Xtemp = PosRaw[2 * i];
                    double Ytemp = PosRaw[2 * i + 1];

                    if (i_f > Ytemp - dy && i_f < Ytemp + dy && j_f > Xtemp - dx && j_f < Xtemp + dx)
                    {
                        double dis = (Xtemp - j_f) * (Xtemp - j_f) + (Ytemp - i_f) * (Ytemp - i_f);
                        tempIndex.Add(i);
                        tempDistance.Add(dis);
                    }
                }
            }
            List<int> Choose = new List<int>();
            for(int i=0;i<item;i++)
            {
                int A=tempDistance.IndexOf(tempDistance.Min());//原本选择最近的10个点进行插值，逻辑上台混乱，不写了
                Choose.Add(tempIndex[A]);
                tempDistance.RemoveAt(A);
                tempIndex.RemoveAt(A);
            }
            double[] Values = new double[item], Pos = new double[item * 2];
            for (int i=0;i<item;i++)
            {
                int B = Choose[i];
                Values[i] = ValuesRaw[B];
                Pos[2 * i] = PosRaw[2 * B];
                Pos[2 * i+1] = PosRaw[2 * B+1];
            }
            return new Tuple<double[], double[]>(Values, Pos);
        }
        public static double[]VInverseCal(double [] pos,double[] Values,int mode,double a,double c0,double c1)
        {
            int dim = Values.Count() + 1;
            double[] V;
            double[] VInverse;
            double[] Cd;
            double test_t;
            /* allocate V array */
            V = new double[dim * dim];
            /* allocate Cd array */
            Cd = new double[dim * dim];
            int i,j;
            /* caculate the distance between sample datas put into Cd array*/
            for (i = 0; i < dim - 1; i++)
            {
                for (j = i; j < dim - 1; j++)
                {
                    test_t = (pos[i * 2] - pos[j * 2]) * (pos[i * 2] - pos[j * 2]) + (pos[i * 2 + 1] - pos[j * 2 + 1]) * (pos[i * 2 + 1] - pos[j * 2 + 1]);
                    Cd[i * dim + j] = (double)Math.Sqrt(test_t);
                }
            }
            for (i = 0; i < dim - 1; i++)
            {
                V[i * dim + dim - 1] = 1;
                V[(dim - 1) * (dim) + i] = 1;
            }
            V[(dim - 1) * (dim) + i] = 0;

            /* caculate the variogram of sample datas and put into  V array */
            for (i = 0; i < dim - 1; i++)
                for (j = i; j < dim - 1; j++)
                {
                    switch (mode)
                    {
                        case 1: /* Spher mode */
                            if (Cd[i * dim + j] < a)
                                V[i * dim + j] = V[j * dim + i] = c0 + c1 * (1.5f * Cd[i * dim + j] / a - 0.5f * (Cd[i * dim + j] / a) * (Cd[i * dim + j] / a) * (Cd[i * dim + j] / a));
                            else
                                V[i * dim + j] = V[j * dim + i] = c0 + c1;
                            break;
                        case 2: /* Expon mode */
                            V[i * dim + j] = V[j * dim + i] = c0 + c1 * (1 - (double)Math.Exp(-3 * Cd[i * dim + j] / a));
                            break;
                        case 3: /* Gauss mode */
                            V[i * dim + j] = V[j * dim + i] = c0 + c1 * (1 - (double)Math.Exp(-3 * Cd[i * dim + j] * Cd[i * dim + j] / a / a));
                            break;
                        default:
                            //System.Console.Out.WriteLine("Wrong mode.");
                            break;
                    }
                    V[i * dim + j] = V[j * dim + i] = c1 - V[i * dim + j];//计算Cij=c1-r(hij),原代码中没有这一步，lez添加
                }
            VInverse = converse2to1(inverseMatrix(converse1to2(V, dim), dim), dim);
            return VInverse;
        }
        public static double[,] converse1to2(double[] v, int dim)
        {
            double[,] res = new double[dim, dim];
            for (int i = 0; i < dim; i++)
                for (int j = 0; j < dim; j++)
                    res[i, j] = v[i * dim + j];
            return res;
        }
        public static double[] converse2to1(double[,] v, int dim)
        {
            double[] res = new double[dim * dim];
            int c = 0;
            for (int i = 0; i < dim; i++)
                for (int j = 0; j < dim; j++)
                    res[c++] = v[i, j];
            return res;
        }
        public static double[,] inverseMatrix(double[,] matrix, int level)
        {
            double[,] dInverseMatrix = new double[level, level * 2];
            double x, c;
            for (int i = 0; i < level; i++)
            {
                for (int j = 0; j < 2 * level; j++)
                {
                    if (j < level)
                        dInverseMatrix[i, j] = matrix[i, j];
                    else
                        dInverseMatrix[i, j] = 0;
                }
                dInverseMatrix[i, level + i] = 1;
            }
            for (int i = 0, j = 0; i < level && j < level; i++, j++)
            {
                if (dInverseMatrix[i, j] == 0)
                {
                    int m = i;
                    for (; matrix[m, j] == 0; m++);
                    if (m == level)
                        return null;
                    else
                    {
                        for (int n = 0; n < 2 * level; n++)
                        {
                            dInverseMatrix[i, n] += dInverseMatrix[m, n];
                        }
                    }
                }
                x = dInverseMatrix[i, j];
                if (x != 1)
                {
                    for (int n = j; n < 2 * level; n++)
                    {
                        if (dInverseMatrix[i, n] != 0)
                            dInverseMatrix[i, n] /= x;
                    }
                }
                for (int s = level - 1; s > i; s--)
                {
                    x = dInverseMatrix[s, j];
                    for (int t = j; t < 2 * level; t++)
                    {
                        dInverseMatrix[s, t] -= (dInverseMatrix[i, t] * x);
                    }
                }
            }
            for (int i = level - 2; i >= 0; i--)
            {
                for (int j = i + 1; j < level; j++)
                    if (dInverseMatrix[i, j] != 0)
                    {
                        c = dInverseMatrix[i, j];
                        for (int n = j; n < 2 * level; n++)
                            dInverseMatrix[i, n] -= (c * dInverseMatrix[j, n]);
                    }
            }
            double[,] dReturn = new double[level, level];
            for (int i = 0; i < level; i++)
            {
                for (int j = 0; j < level; j++)
                    dReturn[i, j] = dInverseMatrix[i, j + level];
            }
            return dReturn;
        }
        public static double[] onceKriging(double[] V, double i_f, double j_f,  double[] pos, double[] Z_s, int mode, double a, double c0, double c1)
        {

            int i, j,dim=Z_s.Count()+1;
            double h;
            double [] D = new double[dim];
            double [] weight = new double[dim];
            /* caculate the distance between estimated point and sample datas */
            /* and caculate the variogram of estimated point and sample datas and put into D array */
            for (i = 0; i < dim - 1; i++)
            {
                h = (double)Math.Sqrt((pos[i * 2] - i_f) * (pos[i * 2] - i_f) + (pos[i * 2 + 1] - j_f) * (pos[i * 2 + 1] - j_f));
                switch (mode)
                {
                    case 1: /* Spher mode */
                        if (h < a)
                            D[i] = c0 + c1 * (1.5f * h / a - 0.5f * (h / a) * (h / a) * (h / a));
                        else
                            D[i] = c0 + c1;
                        break;
                    case 2: /* Expon mode */
                        D[i] = c0 + c1 * (1 - (double)Math.Exp(-3 * h / a));
                        break;
                    case 3: /* Gauss mode */
                        D[i] = c0 + c1 * (1 - (double)Math.Exp(-3 * h * h / a / a));
                        break;
                    default:
                        //System.Console.Out.WriteLine("Wrong mode.");
                        break;
                }
            }
            D[i] = 1;

            /* caculate the weights */

            for (i = 0; i < dim; i++)
            {
                weight[i] = 0;
                for (j = 0; j < dim; j++)
                    weight[i] += V[i * dim + j] * D[j];
            }
            /* caculate and return the estimated value */
            double[] result = new double[2];
            result[0] = 0;
            for (i = 0; i < dim - 1; i++)
            {
                result[0] += weight[i] * Z_s[i];
            }
            /* result[0] : kriging result *///克里金插值结果
            /* result[1] : error variance result *///误差方差结果
            result[0] = (result[0] >= 0) ? result[0] : 0;
            result[1] = 0;
            for (i = 0; i < dim - 1; i++)
            {
                result[1] += weight[i] * D[i];
            }
            result[1] += weight[dim - 1];
            result[1] = (double)Math.Sqrt(result[1]);
            return result;
        }
        
        public static Bitmap DrawImageMap(int PWidth, int PHeight, double[,] DataImage)
        {
            Bitmap colorRamp = Properties.Resources.Rainbow;
            Bitmap bit = new Bitmap(PWidth, PHeight);
            Graphics g = Graphics.FromImage(bit);
            g.Clear(Color.White);
            PointF point1 = new PointF();//用于存放单个数据点
            PointF point2 = new PointF();//用于存放单个数据点
            Pen p = new Pen(Color.Black);

            int M = DataImage.GetLength(0), N = DataImage.GetLength(1);
            float dx = (float)(PWidth - 2) / N, dy = (float)(PHeight - 2) / M;
            //Rectangle srcRect;

            point1.X = 1; point1.Y = 1;
            point2.X = PWidth - 1; point2.Y = 1;
            g.DrawLine(p, point1, point2);//上边界线
            point2.X = 1; point2.Y = PHeight - 1;
            g.DrawLine(p, point1, point2);//左边界线
            point1.X = PWidth - 1; point1.Y = PHeight - 1;
            g.DrawLine(p, point1, point2);//下边界线
            point2.X = PWidth - 1; point2.Y = 1;
            g.DrawLine(p, point1, point2);//右边界线

            double[] ArrayTemp = new double[M * N];
            for (int i = 0; i < ArrayTemp.Length; i++)
            {
                ArrayTemp[i] = DataImage[i / N, i % N];
            }

            double dataMin = ArrayTemp.Min(), dataMax = ArrayTemp.Max();
            for (int i = 0; i < M; i++)
            {
                for (int j = 0; j < N; j++)
                {
                    point1.X = 1 + j * dx;
                    point1.Y = PHeight - 1 - (i + 1) * dy;
                    int length = (int)((colorRamp.Width - 1) * (dataMax - DataImage[i, j]) / (dataMax - dataMin));
                    Color color = colorRamp.GetPixel(colorRamp.Width - length - 1, 1);
                    Brush brush = new SolidBrush(color);
                    g.FillRectangle(brush, point1.X, point1.Y, dx, dy);
                }
            }


            return bit;
        }


    }
}
