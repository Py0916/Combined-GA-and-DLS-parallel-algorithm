﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VelocitySpectral
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();

            cmb_Temp.Visible = false;
            cmb_Temp.SelectedIndexChanged += new EventHandler(cmb_Temp_SelectedIndexChanged);
            dataGridView1.Controls.Add(cmb_Temp);
        }
        //public double[][] FVPlot;
        int NumCurrent;
        double[] VsSave, DepthSave, RmsMin;
        public List<double[][]> FVPlotSave;
        public List<double[]> VsInvSave, ThkInvSave;
        public int PopNum = Properties.Settings.Default.PopNum, IterTimeMax = Properties.Settings.Default.InvNum, InvType = Properties.Settings.Default.InvType, type = 1;//Invtype(0,1,2)分别定深，定速，深速模式，type=0,1，chen和QSM算法
        double[][] Multi_VsTest;
        MyComboBox cmb_Temp = new MyComboBox(20);
        int EditError = -1;
        bool AutoCalculate = true;
        double[][] ParaMod;//初始模型参数
        PlotGDI PGDI = new PlotGDI();
        double[][][] FVPlot_Multi;
        double[] Freq;
        MessageForm MBox;

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            DataGridviewAddRow();
        }
        private void DataGridviewAddRow()
        {
            if (dataGridView1.CurrentRow == null)
            {
                dataGridView1.Rows.Add();
                dataGridView1.Rows[0].HeaderCell.Value = "1";
                dataGridView1.Rows[0].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dataGridView1.Rows[0].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dataGridView1[1, 0].Value = "∞";
                dataGridView1[1, 0].ReadOnly = true;
                dataGridView1[1, 0].Style.BackColor = Color.Gainsboro;

                dataGridView1[4, 0].Style.BackColor = MyComboBox.GetColor(0, cmb_Temp.Items.Count);
                dataGridView1[4, 0].Tag = "1";//注：Tag是从1开始的，Tag=Index+1
            }
            else
            {
                if (dataGridView1[1, 0].Value.ToString() == "∞")
                {
                    dataGridView1[1, 0].Value = "";
                }
                dataGridView1.Rows.Insert(dataGridView1.CurrentRow.Index + 1, new object[] { " ", " ", " ", " " });
                dataGridView1[4, dataGridView1.CurrentRow.Index + 1].Style.BackColor = MyComboBox.GetColor(0, cmb_Temp.Items.Count);
                dataGridView1[4, dataGridView1.CurrentRow.Index + 1].Tag = "1";//注：Tag是从1开始的，Tag=Index+1
                for (int i = 0; i < dataGridView1.Rows.Count; i++)
                {
                    dataGridView1.Rows[i].HeaderCell.Value = (i + 1).ToString();
                    dataGridView1.Rows[i].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                    dataGridView1.Rows[i].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                    if (i == dataGridView1.Rows.Count - 1)
                    {
                        dataGridView1[1, i].Value = "∞";
                        dataGridView1[1, i].ReadOnly = true;
                        dataGridView1[1, i].Style.BackColor = Color.Gainsboro;
                    }
                    else
                    {
                        dataGridView1[1, i].ReadOnly = false;
                        dataGridView1[1, i].Style.BackColor = Color.White;
                    }
                }
            }
        }
        private void DataGridviewRemoveRow()
        {
            foreach (DataGridViewRow r in dataGridView1.SelectedRows)
            {
                if (!r.IsNewRow)
                {
                    dataGridView1.Rows.Remove(r);
                    for (int i = 0; i < dataGridView1.Rows.Count; i++)
                    {
                        dataGridView1.Rows[i].HeaderCell.Value = (i + 1).ToString();
                        dataGridView1.Rows[i].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                        dataGridView1.Rows[i].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                    }
                }
            }
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            DataGridviewRemoveRow();
        }
        private void cmb_Temp_SelectedIndexChanged(object sender, EventArgs e)
        {
            dataGridView1.CurrentCell.Tag = ((ComboBox)sender).Text;//注：Tag是从1开始的，Index需要-1
            dataGridView1.CurrentCell.Style.BackColor = MyComboBox.GetColor(Convert.ToInt32(((ComboBox)sender).Text) - 1, ((ComboBox)sender).Items.Count);
        }

        private void dataGridView1_Scroll(object sender, ScrollEventArgs e)
        {
            this.cmb_Temp.Visible = false;
        }

        private void dataGridView1_ColumnWidthChanged(object sender, DataGridViewColumnEventArgs e)
        {
            this.cmb_Temp.Visible = false;
        }
        private void dataGridView1_CurrentCellChanged(object sender, EventArgs e)
        {
            try
            {
                if (dataGridView1.CurrentCell != null && dataGridView1.CurrentCell.ColumnIndex == 4)
                {
                    Rectangle rect = dataGridView1.GetCellDisplayRectangle(dataGridView1.CurrentCell.ColumnIndex, dataGridView1.CurrentCell.RowIndex, false);
                    cmb_Temp.SelectedIndex = Convert.ToInt32(dataGridView1.CurrentCell.Tag) - 1;//注：Tag是从1开始的，Index需要-1
                    cmb_Temp.Left = rect.Left;
                    cmb_Temp.Top = rect.Top;
                    cmb_Temp.Width = rect.Width;
                    cmb_Temp.Height = rect.Height;
                    cmb_Temp.Visible = true;
                }
                else
                {
                    cmb_Temp.Visible = false;
                }
            }
            catch
            {
            }
        }
        private double[][] ParaGenerate()
        {
            int RowsNum = dataGridView1.Rows.Count;
            if (RowsNum == 0) return null;
            double[][] DataGrid = new double[RowsNum][];
            try
            {
                for (int i = 0; i < RowsNum; i++)
                {
                    DataGrid[i] = new double[5];
                    for (int j = 0; j < 4; j++)
                    {
                        if (i == RowsNum - 1 && j == 1)
                        {
                            DataGrid[i][j] = 0;
                        }
                        else
                        {
                            DataGrid[i][j] = Convert.ToDouble(dataGridView1[j, i].Value);//前面是行后面是列
                        }
                    }
                    DataGrid[i][4] = Convert.ToDouble(dataGridView1[4, i].Tag) - 1;//前面是行后面是列
                }
                return DataGrid;
            }
            catch
            {
                MBox = new MessageForm("数据不可为空！");
                MBox.ShowDialog();
                return null;
            }
        }


        private void dataGridView1_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                double A = Convert.ToDouble(dataGridView1.CurrentCell.Value);
                if (A <= 0 || A > 1000)
                {
                    EditError = dataGridView1.CurrentCell.RowIndex * dataGridView1.Columns.Count + dataGridView1.CurrentCell.ColumnIndex;
                    MBox = new MessageForm("数据大小错误", 0);
                    MBox.ShowDialog();
                    return;
                }
                EditError = -1;
                if (AutoCalculate && dataGridView1.CurrentCell.ColumnIndex == 0)
                {
                    int R = dataGridView1.CurrentCell.RowIndex;
                    double[] DnsP = DnsPCalculate(A);
                    dataGridView1[2, R].Value = DnsP[0].ToString();
                    dataGridView1[3, R].Value = DnsP[1].ToString();
                }
            }
            catch
            {
                EditError = dataGridView1.CurrentCell.RowIndex * dataGridView1.Columns.Count + dataGridView1.CurrentCell.ColumnIndex;
                MBox = new MessageForm("数据格式错误", 0);
                MBox.ShowDialog();
                return;
            }
        }
        private double[] DnsPCalculate(double Vs)
        {
            double Vp, Dns, Poisson;
            if (Vs <= 200)
            {
                Poisson = 0.45;
            }
            else if (Vs <= 300)
            {
                Poisson = 0.4;
            }
            else if (Vs <= 400)
            {
                Poisson = 0.35;
            }
            else if (Vs <= 500)
            {
                Poisson = 0.3;
            }
            else if (Vs <= 600)
            {
                Poisson = 0.25;
            }
            else
            {
                Poisson = 0.2;
            }
            Vp = Math.Sqrt(2 * (1 - Poisson) / (1 - 2 * Poisson)) * Vs;
            Dns = Math.Round(0.31 * Math.Pow(Vp, 0.25), 2);
            return new double[2] { Dns, Poisson };
        }


        private void dataGridView1_Paint(object sender, PaintEventArgs e)
        {
            if (EditError != -1)
            {
                dataGridView1.CurrentCell = dataGridView1[EditError % dataGridView1.Columns.Count, EditError / dataGridView1.Columns.Count];//前面是列后面是行
            }
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            AutoModel();
        }
        void AutoModel()
        {
            double[,] AutoMod;
            AutoMod = AutoModCalculate();
            GridViewFill(AutoMod);
        }
        private double[,] AutoModCalculate()
        {
            double[,] AutoMod = new double[4, 5];
            AutoMod[0, 0] = 200; AutoMod[0, 1] = 5; AutoMod[0, 2] = DnsPCalculate(AutoMod[0, 0])[0]; AutoMod[0, 3] = DnsPCalculate(AutoMod[0, 0])[1]; AutoMod[0, 4] = 0;
            AutoMod[1, 0] = 300; AutoMod[1, 1] = 5; AutoMod[1, 2] = DnsPCalculate(AutoMod[1, 0])[0]; AutoMod[1, 3] = DnsPCalculate(AutoMod[1, 0])[1]; AutoMod[1, 4] = 1;
            AutoMod[2, 0] = 400; AutoMod[2, 1] = 10; AutoMod[2, 2] = DnsPCalculate(AutoMod[2, 0])[0]; AutoMod[2, 3] = DnsPCalculate(AutoMod[2, 0])[1]; AutoMod[2, 4] = 2;
            AutoMod[3, 0] = 500; AutoMod[3, 1] = 0; AutoMod[3, 2] = DnsPCalculate(AutoMod[3, 0])[0]; AutoMod[3, 3] = DnsPCalculate(AutoMod[3, 0])[1]; AutoMod[3, 4] = 3;
            return AutoMod;
        }
        private void GridViewFill(double[,] AutoMod, int GridNum = 0)
        {
            DataGridView DGVCurrent = new DataGridView();
            if (GridNum == 0)
            {
                DGVCurrent = dataGridView1;
            }
            int M = AutoMod.GetLength(0);
            DGVCurrent.Rows.Clear();
            for (int i = 0; i < M; i++)
            {
                DGVCurrent.Rows.Add();
                DGVCurrent.Rows[i].HeaderCell.Value = (i + 1).ToString();
                DGVCurrent.Rows[i].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                for (int j = 0; j < 4; j++)
                {
                    if (j == 0)
                    {
                        DGVCurrent[j, i].Value = AutoMod[i, j].ToString("0");
                    }
                    else if (j == 1)
                    {
                        DGVCurrent[j, i].Value = AutoMod[i, j].ToString("0.#");
                    }
                    else
                    {
                        DGVCurrent[j, i].Value = AutoMod[i, j].ToString();
                    }
                }
                DGVCurrent[4, i].Style.BackColor = MyComboBox.GetColor((int)AutoMod[i, 4], cmb_Temp.Items.Count);
                DGVCurrent[4, i].Tag = ((int)AutoMod[i, 4] + 1).ToString();//注：Tag是从1开始的，Tag=Index+1
            }

            DGVCurrent[1, M - 1].Value = "∞";
            DGVCurrent[1, M - 1].ReadOnly = true;
            DGVCurrent[1, M - 1].Style.BackColor = Color.Gainsboro;

            DGVCurrent.Visible = true;
        }

        private void toolStripButton5_Click(object sender, EventArgs e)
        {
            ModelCalculate();
        }
        void ModelCalculate()
        {
            ParaMod = ParaGenerate();//模型参数

            //获取用于正演的参数，只计算前4列就行，第5列是层颜色，不参与正演计算
            int NVs = ParaMod.GetLength(0);
            double[] VsMod0 = new double[NVs];
            double[] ThkMod0 = new double[NVs - 1];
            double[] Dns = new double[NVs];
            double[] Poisson = new double[NVs];
            for (int i = 0; i < NVs; i++)
            {
                VsMod0[i] = ParaMod[i][0];
                if (i < NVs - 1)
                {
                    ThkMod0[i] = ParaMod[i][1];
                }
                Dns[i] = ParaMod[i][2];
                Poisson[i] = ParaMod[i][3];
            }
            Freq = new double[] { 1, 1.4, 2, 2.8, 3.8, 5, 6.4, 8, 9.8, 11.8, 14, 16.4, 19, 21.8, 24.8, 28, 31.4, 35, 38.8, 42.8, 47, 51.4, 56, 60.8, 65.8, 71, 76.4, 82, 87.8, 93.8, 100 };

            double[] Vr = new double[100];

            for (int i = 0; i < 100; i++)
            {
                Vr[i] = 10 * (100 - i);
            }

            string ImageFile = "";

            Multi_VsTest = SurfaceWave.FV_Multi(VsMod0, ThkMod0, Freq, Dns, Poisson, 3);//将正演的保存

            FVPlot_Multi = new double[Multi_VsTest.Count()][][];
            for (int i = 0; i < Multi_VsTest.Count(); i++)
            {
                FVPlot_Multi[i] = new double[][] { Freq, Multi_VsTest[i] };
            }
            Bitmap bit2 = PGDI.DrawImageGDI_New(ImageFile, panel2.Width, panel2.Height, FVPlot_Multi);

            panel2.BackgroundImage = bit2;



        }

        private void toolStripButton8_Click(object sender, EventArgs e)
        {
            LoadInitialMod();
        }
        void LoadInitialMod()
        {
            OpenFileDialog file = new OpenFileDialog()
            {
                RestoreDirectory = true,
                Title = "导入模型参数文件",
                Filter = "模型参数文件|*.ParaMod",

            };

            if (file.ShowDialog() == DialogResult.OK)
            {
                System.IO.StreamReader sr = new System.IO.StreamReader(file.FileName);
                List<string> line = new List<string>();
                string temp;
                string[] linetemp = new string[5];
                while ((temp = sr.ReadLine()) != null)
                {
                    line.Add(temp.ToString());
                }
                sr.Close();

                int M = line.Count;
                double[,] AutoMod = new double[M, 5];
                for (int i = 0; i < M; i++)
                {
                    linetemp = line[i].Split().Where(s => !string.IsNullOrEmpty(s)).ToArray();
                    AutoMod[i, 0] = Convert.ToDouble(linetemp[0]);
                    AutoMod[i, 1] = Convert.ToDouble(linetemp[1]);
                    AutoMod[i, 2] = Convert.ToDouble(linetemp[2]);
                    AutoMod[i, 3] = Convert.ToDouble(linetemp[3]);

                    AutoMod[i, 4] = Convert.ToDouble(linetemp[4]);
                    if (AutoMod[i, 4] > 19)
                        AutoMod[i, 4] = 19;
                }
                GridViewFill(AutoMod);

            }
        }

        private void toolStripButton9_Click(object sender, EventArgs e)
        {
            SaveInitialMod();
        }

        private void toolStripButton12_Click(object sender, EventArgs e)
        {
            DLS_Inv();
        }

        void SaveInitialMod()
        {
            double[][] ParaMod = ParaGenerate();//模型参数
            if (ParaMod != null)
            {
                SaveFileDialog file = new SaveFileDialog()
                {
                    RestoreDirectory = true,
                    Title = "导出模型参数文件",
                    Filter = "模型参数文件|*.ParaMod",

                };

                if (file.ShowDialog() == DialogResult.OK)
                {
                    System.IO.StreamWriter sw = System.IO.File.CreateText(file.FileName);
                    string Data;
                    for (int i = 0; i < ParaMod.Count(); i++)
                    {
                        Data = string.Format("{0:f0}", ParaMod[i][0]) + string.Format("{0,10:f1}", ParaMod[i][1])
                            + string.Format("{0,10:f2}", ParaMod[i][2]) + string.Format("{0,10:f2}", ParaMod[i][3])
                            + string.Format("{0,10:f2}", ParaMod[i][4]);
                        sw.WriteLine(Data);
                    }
                    sw.Close();
                    MBox = new MessageForm("模型参数保存成功！");
                    MBox.ShowDialog();
                }
            }
            else
            {
                MBox = new MessageForm("模型参数不可为空！");
                MBox.ShowDialog();
            }
        }



        private void toolStripButton13_Click(object sender, EventArgs e)
        {

            GA_DLS_Inv();

        }
        private async void GA_DLS_Inv()
        {
            DateTime dt1, dt2;
            dt1 = DateTime.Now;
            toolStripStatusLabel1.Text = dt1.ToString("t");


            VsInvSave = new List<double[]>();
            ThkInvSave = new List<double[]>();
            FVPlotSave = new List<double[][]>();
            int N = PopNum;
            double[][] Multi_V;
            int IterNum, MinIndex;
            int FreNum = Freq.Count();

            double[] VsMod0, ThkMod0, Dns, Poisson, VsInv = new double[FreNum], ThkInv = new double[FreNum], RmsError = new double[N], f_RmsError = new double[N];
            double[][] Multi_Rms = new double[IterTimeMax][];
            RmsMin = new double[IterTimeMax];
            string[] Pop = new string[N], PopNew = new string[N];
            double[][] VsTrail = new double[N][], ThkTrail = new double[N][];
            double[][][] VrTrail = new double[N][][];
            Tuple<double[][], double[][]> tup;

            ParaMod = ParaGenerate();//可能已经手动修改了，重新获取模型参数
            int NVs = ParaMod.GetLength(0);
            VsMod0 = new double[NVs];
            ThkMod0 = new double[NVs - 1];
            Dns = new double[NVs];
            Poisson = new double[NVs];
            for (int i = 0; i < NVs; i++)
            {
                VsMod0[i] = ParaMod[i][0];
                if (i < NVs - 1)
                {
                    ThkMod0[i] = ParaMod[i][1];
                }
                Dns[i] = ParaMod[i][2];
                Poisson[i] = ParaMod[i][3];
            }
            int ErrorLevel = 1;

            FVPlotSave.Add(DataClone(Multi_VsTest));
            VsInvSave.Add(VsMod0);
            ThkInvSave.Add(ThkMod0);

            //第一步先用遗传算法迭代IterTime_Step1次
            int IterTime_Step1 = 5;
            //IterTimeMax = 3;
            //第一次遗传迭代即为IterNum = 1;
            IterNum = 0;
            Pop = GAInversion.ModelToBinary(N, VsMod0, ThkMod0, InvType);//产生N个父代

            //第二步选取误差最小的10组模型
            //第一步达到IterNum == IterTime_Step1 - 1条件就终止了，后续代码没有执行，故不需要改动代码。

            if (Properties.Settings.Default.DLSChooseNum_GA > Properties.Settings.Default.PopNum)
            {
                Properties.Settings.Default.DLSChooseNum_GA = Properties.Settings.Default.PopNum;
                Properties.Settings.Default.Save();
            }
            int NumChoose = Properties.Settings.Default.DLSChooseNum_GA;
            Tuple<double[][], double[][], int[]> tup2;
            //Tuple<List<double[]>, List<double[]>, List<double[][]>, List<double>> ttup;
            double[] Vs_Result = new double[NVs], Thk_Result = new double[NVs - 1];
            Task<int>[] TaskArray = new Task<int>[NumChoose];
            //Task<int> TastTmp;
            int[] TaskResult = new int[NumChoose];
            double[] VS_tmp, Thk_tmp;
            int Pos_tmp;
            while (IterNum < IterTimeMax)
            {
                tup = GAInversion.BinaryToModel(Pop, VsMod0, ThkMod0, InvType);
                VsTrail = tup.Item1;
                ThkTrail = tup.Item2;
                for (int i = 0; i < N; i++)
                {
                    VrTrail[i] = SurfaceWave.FV_Multi(VsTrail[i], ThkTrail[i], Freq, null, null, Properties.Settings.Default.ModeNum);//type=0，Chen方法，type=1，QSM方法
                    RmsError[i] = GAInversion.Multi_RmsErrorCalculate(VrTrail[i], Multi_VsTest);
                }


                double[] errortmp = DataClone(RmsError);//用于测试，无意义
                if (IterNum > IterTime_Step1)//进入第二阶段开始用DLS内嵌算法改造Pop
                {

                    tup2 = GetChoosedMod(VsTrail, ThkTrail, RmsError, NumChoose);//选取误差最小的10个进行DLS计算
                    for (int i = 0; i < NumChoose; i++)
                    {
                        VS_tmp = tup2.Item1[i];
                        Thk_tmp = tup2.Item2[i];
                        Pos_tmp = tup2.Item3[i];
                        TaskArray[i] = Task.Run(() => GetDLSResult(VS_tmp, Thk_tmp, Freq, Multi_VsTest, Properties.Settings.Default.ModeNum, Properties.Settings.Default.DLSInvNum_GA, Properties.Settings.Default.InvType, Pos_tmp, RmsError, VrTrail, VsTrail, ThkTrail, Pop));
                        await Task.Delay(5);
                    }
                    TaskResult = await Task.WhenAll(TaskArray);

                }
                if (errortmp.Min() < RmsError.Min())
                    Console.WriteLine("cuowu!");

                Multi_Rms[IterNum] = DataClone(RmsError);
                if (RmsError.Min() < ErrorLevel)//如单次均方根足够小，退出迭代
                {
                    MinIndex = Array.IndexOf(RmsError, RmsError.Min());
                    Multi_V = VrTrail[MinIndex];
                    FVPlotSave.Add(DataClone(Multi_V));
                    VsInvSave.Add(DataClone(VsTrail[MinIndex]));
                    ThkInvSave.Add(DataClone(ThkTrail[MinIndex]));
                    break;
                }
                RmsMin[IterNum] = RmsError.Min();
                if (IterNum > 1 && RmsMin[IterNum] > RmsMin[IterNum - 1])
                    Console.WriteLine("false");
                if (IterNum == IterTimeMax - 1)//如迭代次数达到上限，退出迭代
                {
                    MinIndex = Array.IndexOf(RmsError, RmsError.Min());
                    Multi_V = VrTrail[MinIndex];
                    FVPlotSave.Add(DataClone(Multi_V));
                    VsInvSave.Add(DataClone(VsTrail[MinIndex]));
                    ThkInvSave.Add(DataClone(ThkTrail[MinIndex]));
                    break;
                }
                //Console.WriteLine(Array.IndexOf(RmsError, RmsError.Min()).ToString());
                f_RmsError = GAInversion.WeightCalculate(RmsError, IterNum + 1);

                //Console.WriteLine(Array.IndexOf(f_RmsError, f_RmsError.Max()).ToString());
                int A = Array.IndexOf(RmsError, RmsError.Min());
                string B = Pop[A];
                PopNew = DataClone(GAInversion.HeredityMatrix(Pop, f_RmsError));
                Pop = PopNew;
                string C = Pop[0];
                if (B == C)
                    Console.WriteLine("true");
                else
                    Console.WriteLine("false");
                MinIndex = Array.IndexOf(RmsError, RmsError.Min());
                //FVPlot2[0] = Freq;
                Multi_V = VrTrail[MinIndex];
                FVPlotSave.Add(DataClone(Multi_V));
                VsInvSave.Add(DataClone(VsTrail[MinIndex]));
                ThkInvSave.Add(DataClone(ThkTrail[MinIndex]));
                IterNum++;
                Console.WriteLine("GA_" + IterNum);
                toolStripStatusLabel2.Text = "GA_" + IterNum;
            }
            foreach (var item in RmsMin)
            {
                Console.WriteLine(item);
            }
            toolStripStatusLabel3.Text = (DateTime.Now - dt1).ToString(@"hh\:mm\:ss");
            Console.WriteLine("GA_DLS Is Over");
            SaveGAMultiInvResult(Freq, FVPlotSave, VsInvSave, ThkInvSave, Multi_Rms, 1);
        }
        int GetDLSResult(double[] Vs, double[] Thk, double[] Freq, double[][] V_m, int MaxRoot, int MaxTimes, int InvType, int PosIndex, double[] RmsError, double[][][] Vr, double[][] VsTry, double[][] ThkThy, string[] Pop)
        {
            Tuple<List<double[]>, List<double[]>, List<double[][]>, List<double>> ttup = LeastSquare.M_LeastSqrInv(Vs, Thk, Freq, V_m, MaxRoot, MaxTimes, InvType);
            double Rms = ttup.Item4.Min();//因DLS计算中保存了初始模型，故可保证其误差<=遗传算法得到的模型

            if (RmsError[PosIndex] > Rms)
            {
                int Choose = ttup.Item4.IndexOf(Rms);
                Vr[PosIndex] = ttup.Item3[Choose];//将DLS计算结果，覆盖到原遗传算法模型对应位置
                RmsError[PosIndex] = Rms;
                VsTry[PosIndex] = ttup.Item1[Choose];
                ThkThy[PosIndex] = ttup.Item2[Choose];
                Pop[PosIndex] = GAInversion.ModelToBinary_OneMod(ttup.Item1[Choose], ttup.Item2[Choose]);
            }

            return 1;
        }
        Tuple<double[][], double[][], int[]> GetChoosedMod(double[][] VsMod, double[][] ThkMod, double[] Rms, int NumChoosed = 10)
        {
            int M = Rms.Count();
            List<double> RmsSort = Rms.ToList();
            int[] Pos = new int[NumChoosed];//记录选择点的位置，用于后续替换pop中的模型
            double[][] VsChoosed = new double[NumChoosed][], ThkChoosed = new double[NumChoosed][];
            //int[] NumChoose = new int[M];
            RmsSort.Sort();
            //RmsSort.Reverse();
            for (int i = 0; i < NumChoosed; i++)
            {
                Pos[i] = Array.IndexOf(Rms, RmsSort[i]);

                VsChoosed[i] = VsMod[Pos[i]];
                ThkChoosed[i] = ThkMod[Pos[i]];
            }
            return new Tuple<double[][], double[][], int[]>(VsChoosed, ThkChoosed, Pos);
        }

        private void toolStripButton14_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog()
            {
                RestoreDirectory = true,
                //  InitialDirectory = Application.StartupPath,
                Title = "打开文件夹",
                Filter = "Multi-Dispersion File|*.M_Dispersion",
                Multiselect = false
            };

            DialogResult result = ofd.ShowDialog();
            if (result == DialogResult.OK)
            {
                Tuple<double[][], double[]> A = GetM_Dispersion(ofd.FileName);
                Multi_VsTest = A.Item1;
                Freq = A.Item2;
                if (Multi_VsTest.Count() < Properties.Settings.Default.ModeNum)
                    Properties.Settings.Default.ModeNum = Multi_VsTest.Count();
                FVPlot_Multi = new double[Properties.Settings.Default.ModeNum][][];
                for (int i = 0; i < Properties.Settings.Default.ModeNum; i++)
                {
                    FVPlot_Multi[i] = new double[][] { Freq, Multi_VsTest[i] };
                }
                panel2.BackgroundImage = PGDI.DrawImageGDI_New("", panel2.Width, panel2.Height, FVPlot_Multi);
            }
        }

        Tuple<double[][], double[]> GetM_Dispersion(string filename)
        {
            System.IO.StreamReader sr = new System.IO.StreamReader(filename);
            List<string> line = new List<string>();
            string temp;
            string[] linetemp;

            while ((temp = sr.ReadLine()) != null)
            {
                line.Add(temp.ToString());
            }
            sr.Close();
            linetemp = line[0].Split().Where(s => !string.IsNullOrEmpty(s)).ToArray();
            int M, N;
            M = Convert.ToInt32(linetemp[0]);//modeNum
            N = Convert.ToInt32(linetemp[1]);//freqNum
            double[][] DataOut = new double[M][];
            double[] FreqOut = new double[N];
            for (int i = 0; i < M; i++)
            {
                DataOut[i] = new double[N];
            }
            for (int j = 0; j < N; j++)
            {
                
                linetemp = line[j+1].Split().Where(s => !string.IsNullOrEmpty(s)).ToArray();
                FreqOut[j] = Convert.ToDouble(linetemp[0]);
                for (int i = 0; i < M; i++)
                {
                    DataOut[i][j] = Convert.ToDouble(linetemp[i + 1]);
                }
            }
            return new Tuple<double[][], double[]>(DataOut, FreqOut);
        }



        private void toolStripButton4_Click_1(object sender, EventArgs e)
        {
            SaveM_Dispersion();
        }
        void SaveM_Dispersion()
        {
            SaveFileDialog file = new SaveFileDialog()
            {
                RestoreDirectory = true,
                //  InitialDirectory = Application.StartupPath,
                Title = "导出频散文件",
                Filter = "频散文件|*.M_Dispersion",

            };

            if (file.ShowDialog() == DialogResult.OK)
            {
                System.IO.StreamWriter sw = System.IO.File.CreateText(file.FileName);
                string Data;
                Data = FVPlot_Multi.Count().ToString() + string.Format("{0,10:f0}", FVPlot_Multi[0][0].Count());
                sw.WriteLine(Data);

                for (int j = 0; j < FVPlot_Multi[0][0].Count(); j++)
                {
                    Data = string.Format("{0:f1}", FVPlot_Multi[0][0][j]);
                    for (int i = 0; i < FVPlot_Multi.Count(); i++)
                    {
                        Data += string.Format("{0,10:f1}", FVPlot_Multi[i][1][j]);
                    }
                    sw.WriteLine(Data);
                }


                sw.Close();
                MBox = new MessageForm("频散文件保存成功！");
                MBox.ShowDialog();
            }
        }
        private async void toolStripButton11_Click(object sender, EventArgs e)
        {
            //耗时巨大的代码
            //Task Th1;

            //    Th1 = new Task(GA_Inv);//遗传算法

            //Control.CheckForIllegalCrossThreadCalls = false;
            //Th1.Start();
            //await Th1;
            GA_Inv();
        }
        public void DLS_Inv()
        {
            //测试最小二乘反演
            ParaMod = ParaGenerate();//可能已经手动修改了，重新获取模型参数
            int NVs = ParaMod.GetLength(0);
            double[] VsMod0 = new double[NVs];
            double[] ThkMod0 = new double[NVs - 1];
            double[] Dns = new double[NVs];
            double[] Poisson = new double[NVs];
            for (int i = 0; i < NVs; i++)
            {
                VsMod0[i] = ParaMod[i][0];
                if (i < NVs - 1)
                {
                    ThkMod0[i] = ParaMod[i][1];
                }
                Dns[i] = ParaMod[i][2];
                Poisson[i] = ParaMod[i][3];
            }

            Tuple<List<double[]>, List<double[]>, List<double[][]>, List<double>> ttup = LeastSquare.M_LeastSqrInv(VsMod0, ThkMod0, Freq, Multi_VsTest, 3, Properties.Settings.Default.InvNum, Properties.Settings.Default.InvType, Dns, Poisson);

            //测试最小二乘结束
            VsInvSave = new List<double[]>();
            ThkInvSave = new List<double[]>();
            FVPlotSave = new List<double[][]>();

            VsInvSave = ttup.Item1;
            ThkInvSave = ttup.Item2;
            FVPlotSave = ttup.Item3;
            RmsMin = ttup.Item4.ToArray();
            NumCurrent = VsInvSave.Count() - 1;
            //将初始模型和VsTest保存进结果
            //VsInvSave.Insert(0, VsMod0);
            //ThkInvSave.Insert(0, ThkMod0);
            FVPlotSave.Insert(0, Multi_VsTest);
            SaveDLSMultiInvResult(Freq, FVPlotSave, VsInvSave, ThkInvSave, RmsMin);
        }
        public void GA_Inv()
        {
            VsInvSave = new List<double[]>();
            ThkInvSave = new List<double[]>();
            FVPlotSave = new List<double[][]>();
            int N = PopNum;
            //double[][] FVPlot2 = new double[2][];
            double[][] Multi_V;
            int IterNum, MinIndex;
            //double[] Freq = FVPlot[0];
            int FreNum = Freq.Count();

            double[] VsMod0, ThkMod0, Dns, Poisson, VsInv = new double[FreNum], ThkInv = new double[FreNum], RmsError = new double[N], f_RmsError = new double[N];
            double[][] VrInv;
            double[][] Multi_Rms = new double[IterTimeMax][];
            RmsMin = new double[IterTimeMax];
            //double[][] VrTest = FVPlot[1];//只取基阶 
            string[] Pop = new string[N];//, PopNew = new string[N];
            string PopChoosed;
            double[][] VsTrail = new double[N][], ThkTrail = new double[N][];
            double[][][] VrTrail = new double[N][][];
            Tuple<double[][], double[][]> tup;

            //VsMod0 = new double[4] { 200, 300, 400, 500 };
            //ThkMod0 = new double[3] { 5, 10, 10 };
            ParaMod = ParaGenerate();//可能已经手动修改了，重新获取模型参数
            int NVs = ParaMod.GetLength(0);
            VsMod0 = new double[NVs];
            ThkMod0 = new double[NVs - 1];
            Dns = new double[NVs];
            Poisson = new double[NVs];
            for (int i = 0; i < NVs; i++)
            {
                VsMod0[i] = ParaMod[i][0];
                if (i < NVs - 1)
                {
                    ThkMod0[i] = ParaMod[i][1];
                }
                Dns[i] = ParaMod[i][2];
                Poisson[i] = ParaMod[i][3];
            }
            int ErrorLevel = 1;
            //初始模型直接计入第一次结果
            //FVPlot2[0] = Freq;
            //Multi_V = SurfaceWave.FV_Multi(VsMod0, ThkMod0, Freq, Dns, Poisson, 3);
            //RmsMin[0] = GAInversion.Multi_RmsErrorCalculate(Multi_V, Multi_VsTest);
            //for (int i = 0; i < N; i++)
            //{
            //    RmsError[i] = RmsMin[0];
            //}
            //Multi_Rms[0] = DataClone(RmsError);
            FVPlotSave.Add(DataClone(Multi_VsTest));
            VsInvSave.Add(VsMod0);
            ThkInvSave.Add(ThkMod0);

            //第一次遗传迭代即为IterNum = 1;
            IterNum = 0;
            Pop = GAInversion.ModelToBinary(N, VsMod0, ThkMod0, InvType);//产生N个父代
            while (IterNum < IterTimeMax)
            {
                tup = GAInversion.BinaryToModel(Pop, VsMod0, ThkMod0, InvType);
                VsTrail = tup.Item1;
                ThkTrail = tup.Item2;
                for (int i = 0; i < N; i++)
                {
                    VrTrail[i] = SurfaceWave.FV_Multi(VsTrail[i], ThkTrail[i], Freq, Dns, Poisson, 3);//type=0，Chen方法，type=1，QSM方法
                    RmsError[i] = GAInversion.Multi_RmsErrorCalculate(VrTrail[i], Multi_VsTest);
                }

                Multi_Rms[IterNum] = DataClone(RmsError);
                if (RmsError.Min() < ErrorLevel)//如单次均方根足够小，退出迭代
                {
                    MinIndex = Array.IndexOf(RmsError, RmsError.Min());
                    Multi_V = VrTrail[MinIndex];
                    FVPlotSave.Add(DataClone(Multi_V));
                    VsInvSave.Add(DataClone(VsTrail[MinIndex]));
                    ThkInvSave.Add(DataClone(ThkTrail[MinIndex]));
                    break;
                }
                RmsMin[IterNum] = RmsError.Min();
                if (IterNum == IterTimeMax - 1)//如迭代次数达到上限，退出迭代
                {
                    MinIndex = Array.IndexOf(RmsError, RmsError.Min());
                    Multi_V = VrTrail[MinIndex];
                    FVPlotSave.Add(DataClone(Multi_V));
                    VsInvSave.Add(DataClone(VsTrail[MinIndex]));
                    ThkInvSave.Add(DataClone(ThkTrail[MinIndex]));
                    break;
                }
                //Console.WriteLine(Array.IndexOf(RmsError, RmsError.Min()).ToString());
                f_RmsError = GAInversion.WeightCalculate(RmsError, IterNum + 1);

                //Console.WriteLine(Array.IndexOf(f_RmsError, f_RmsError.Max()).ToString());
                Pop = DataClone(GAInversion.HeredityMatrix(Pop, f_RmsError));

                MinIndex = Array.IndexOf(RmsError, RmsError.Min());
                //FVPlot2[0] = Freq;
                Multi_V = VrTrail[MinIndex];
                FVPlotSave.Add(DataClone(Multi_V));
                VsInvSave.Add(DataClone(VsTrail[MinIndex]));
                ThkInvSave.Add(DataClone(ThkTrail[MinIndex]));
                IterNum++;
                Console.WriteLine(IterNum);
            }
            NumCurrent = IterNum - 1;
            SaveGAMultiInvResult(Freq, FVPlotSave, VsInvSave, ThkInvSave, Multi_Rms);
        }
        private void SaveDLSMultiInvResult(double[] Freq, List<double[][]> Multi_V, List<double[]> VsSave, List<double[]> ThkSave, double[] Rms)
        {
            SaveFileDialog file = new SaveFileDialog()
            {
                RestoreDirectory = true,
                //  InitialDirectory = Application.StartupPath,
                Title = "导出DLS多模式反演文件",
                Filter = "DLS多模式反演文件|*.DLS_M_R",

            };

            if (file.ShowDialog() == DialogResult.OK)
            {
                int M = Rms.Count();//反演次数
                int N = Freq.Count();//频点数
                System.IO.StreamWriter sw = System.IO.File.CreateText(file.FileName);
                string Data;
                Data = string.Format("{0,10:f0}", N) + string.Format("{0,10:f0}", M) + string.Format("{0,10:f0}", VsSave[0].Count()) + string.Format("{0,10:f0}", Multi_V[0].Count());
                sw.WriteLine(Data);//头文件：频点数，反演次数，模型层数，模式阶数

                Data = "";
                for (int i = 0; i < N; i++)
                {
                    Data += string.Format("{0,10:f0}", Freq[i]);
                }
                sw.WriteLine(Data);//频率信息，一行
                for (int i = 0; i < M; i++)
                {
                    Data = "";
                    for (int j = 0; j < VsSave[0].Count(); j++)
                    {
                        Data += string.Format("{0,10:f0}", VsSave[i][j]);
                    }
                    sw.WriteLine(Data);//波速信息，一行（层数）个，M+1（代数+1）行，因第一个是初始模型
                }
                for (int i = 0; i < M; i++)
                {
                    Data = "";
                    for (int j = 0; j < ThkSave[0].Count(); j++)
                    {
                        Data += string.Format("{0,10:f1}", ThkSave[i][j]);
                    }
                    sw.WriteLine(Data);//层厚信息，一行（层数-1）个，M+1（代数+1）行,因第一个是初始模型
                }
                for (int i = 0; i < M + 1; i++)
                {
                    for (int j = 0; j < Multi_V[i].Count(); j++)
                    {
                        Data = "";
                        for (int k = 0; k < Multi_V[i][j].Count(); k++)
                        {
                            Data += string.Format("{0,10:f0}", Multi_V[i][j][k]);
                        }
                        sw.WriteLine(Data);//f-v信息，一行（频点）个，M+1（代数+1）*（模式数）行，因第一个是VsTest
                    }
                }
                Data = "";
                for (int i = 0; i < M; i++)
                {
                    Data += string.Format("{0,10:f3}", Rms[i]);//迭代次数均方根误差
                }
                sw.WriteLine(Data);//迭代次数均方根误差
                sw.Close();
                MBox = new MessageForm("DLS多模式反演结果保存成功！");
                MBox.ShowDialog();
            }
        }
        private void SaveGAMultiInvResult(double[] Freq, List<double[][]> Multi_V, List<double[]> VsSave, List<double[]> ThkSave, double[][] MultiRms, int type = 0)
        {
            SaveFileDialog file;
            if (type == 0)
            {
                file = new SaveFileDialog()
                {
                    RestoreDirectory = true,
                    Title = "导出GA多模式反演文件",
                    Filter = "GA多模式反演文件|*.GA_M_R",

                };
            }
            else
            {
                file = new SaveFileDialog()
                {
                    RestoreDirectory = true,
                    //  InitialDirectory = Application.StartupPath,
                    Title = "导出GA_DLS多模式反演文件",
                    Filter = "GA_DLS多模式反演文件|*.GA_DLS_M_R",

                };
            }


            if (file.ShowDialog() == DialogResult.OK)
            {
                int M = VsSave.Count() - 1;
                int N = MultiRms[0].Count();
                System.IO.StreamWriter sw = System.IO.File.CreateText(file.FileName);
                string Data;
                Data = string.Format("{0,10:f0}", Freq.Count()) + string.Format("{0,10:f0}", M) + string.Format("{0,10:f0}", MultiRms[0].Count()) + string.Format("{0,10:f0}", VsSave[0].Count()) + string.Format("{0,10:f0}", Multi_V[0].Count());
                sw.WriteLine(Data);//头文件：频点数，遗传代数，种群数，模型层数，模式阶数

                Data = "";
                for (int i = 0; i < Freq.Count(); i++)
                {
                    Data += string.Format("{0,10:f1}", Freq[i]);
                }
                sw.WriteLine(Data);//频率信息，一行
                for (int i = 0; i < M + 1; i++)
                {
                    Data = "";
                    for (int j = 0; j < VsSave[0].Count(); j++)
                    {
                        Data += string.Format("{0,10:f1}", VsSave[i][j]);
                    }
                    sw.WriteLine(Data);//波速信息，一行（层数）个，M+1（代数+1）行，因第一个是初始模型
                }
                for (int i = 0; i < M + 1; i++)
                {
                    Data = "";
                    for (int j = 0; j < ThkSave[0].Count(); j++)
                    {
                        Data += string.Format("{0,10:f2}", ThkSave[i][j]);
                    }
                    sw.WriteLine(Data);//层厚信息，一行（层数-1）个，M+1（代数+1）行,因第一个是初始模型
                }
                for (int i = 0; i < M + 1; i++)
                {
                    for (int j = 0; j < Multi_V[i].Count(); j++)
                    {
                        Data = "";
                        for (int k = 0; k < Multi_V[i][j].Count(); k++)
                        {
                            Data += string.Format("{0,10:f1}", Multi_V[i][j][k]);
                        }
                        sw.WriteLine(Data);//f-v信息，一行（频点）个，M+1（代数+1）*（模式数）行，因第一个是VsTest
                    }
                }
                for (int i = 0; i < M; i++)
                {
                    Data = "";
                    for (int j = 0; j < N; j++)
                    {
                        Data += string.Format("{0,10:f3}", MultiRms[i][j]);

                    }
                    sw.WriteLine(Data);
                }
                sw.Close();
                MBox = new MessageForm("GA多模式反演结果保存成功！");
                MBox.ShowDialog();
            }
        }
        private T DataClone<T>(T RealObject)
        {
            using (Stream objectStream = new MemoryStream())
            {
                //利用 System.Runtime.Serialization序列化与反序列化完成引用对象的复制
                System.Runtime.Serialization.IFormatter formatter = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();
                formatter.Serialize(objectStream, RealObject);
                objectStream.Seek(0, SeekOrigin.Begin);
                return (T)formatter.Deserialize(objectStream);
            }
        }
    }
}
