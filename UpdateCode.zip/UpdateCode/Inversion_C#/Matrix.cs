﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VelocitySpectral
{
    class Matrix
    {

        ///   <summary> 
        ///   矩阵的转置 
        ///   </summary> 
        ///   <param   name= "iMatrix "> </param> 
        public static double[,] Transpose(double[,] iMatrix)
        {
            int row = iMatrix.GetLength(0);
            int column = iMatrix.GetLength(1);
            //double[,] iMatrix = new double[column, row];
            double[,] TempMatrix = new double[row, column];
            double[,] iMatrixT = new double[column, row];
            for (int i = 0; i < row; i++)
            {
                for (int j = 0; j < column; j++)
                {
                    TempMatrix[i, j] = iMatrix[i, j];
                }
            }
            for (int i = 0; i < column; i++)
            {
                for (int j = 0; j < row; j++)
                {
                    iMatrixT[i, j] = TempMatrix[j, i];
                }
            }
            return iMatrixT;

        }
        /// <summary>
        /// 逆矩阵求法2
        /// </summary>
        /// <param name="dMatrix"></param>
        /// <param name="Level"></param>
        /// <returns></returns>
        public static double[,] ReverseMatrix(double[,] dMatrix)
        {
            int Level = dMatrix.GetLength(0);
            double dMatrixValue = Determinant(dMatrix);
            //if (dMatrixValue == 0) return null;

            double[,] dReverseMatrix = new double[Level, 2 * Level];
            double x, c;
            // Init Reverse matrix
            for (int i = 0; i < Level; i++)
            {
                for (int j = 0; j < 2 * Level; j++)
                {
                    if (j < Level)
                        dReverseMatrix[i, j] = dMatrix[i, j];
                    else
                        dReverseMatrix[i, j] = 0;
                }

                dReverseMatrix[i, Level + i] = 1;
            }

            for (int i = 0, j = 0; i < Level && j < Level; i++, j++)
            {
                if (dReverseMatrix[i, j] == 0)
                {
                    int m = i;
                    for (; dMatrix[m, j] == 0; m++) ;
                    if (m == Level)
                        return null;
                    else
                    {
                        // Add i-row with m-row
                        for (int n = j; n < 2 * Level; n++)
                            dReverseMatrix[i, n] += dReverseMatrix[m, n];
                    }
                }

                // Format the i-row with "1" start
                x = dReverseMatrix[i, j];
                if (x != 1)
                {
                    for (int n = j; n < 2 * Level; n++)
                        if (dReverseMatrix[i, n] != 0)
                            dReverseMatrix[i, n] /= x;
                }

                // Set 0 to the current column in the rows after current row
                for (int s = Level - 1; s > i; s--)
                {
                    x = dReverseMatrix[s, j];
                    for (int t = j; t < 2 * Level; t++)
                        dReverseMatrix[s, t] -= (dReverseMatrix[i, t] * x);
                }
            }

            // Format the first matrix into unit-matrix
            for (int i = Level - 2; i >= 0; i--)
            {
                for (int j = i + 1; j < Level; j++)
                    if (dReverseMatrix[i, j] != 0)
                    {
                        c = dReverseMatrix[i, j];
                        for (int n = j; n < 2 * Level; n++)
                            dReverseMatrix[i, n] -= (c * dReverseMatrix[j, n]);
                    }
            }

            double[,] dReturn = new double[Level, Level];
            for (int i = 0; i < Level; i++)
                for (int j = 0; j < Level; j++)
                    dReturn[i, j] = dReverseMatrix[i, j + Level];
            return dReturn;
        }
        ///   <summary> 
        ///   矩阵的逆矩阵 
        ///   </summary> 
        ///   <param   name= "iMatrix "> </param> 
        public static double[,] Athwart(double[,] iMatrix)
        {
            int row = iMatrix.GetLength(0);
            double[,] MatrixZwei = new double[row, row * 2];
            double[,] iMatrixInv = new double[row, row];
            for (int i = 0; i < row; i++)
            {
                for (int j = 0; j < row; j++)
                {
                    MatrixZwei[i, j] = iMatrix[i, j]*1.0;
                }
            }
            for (int i = 0; i < row; i++)
            {
                for (int j = row; j < row * 2; j++)
                {
                    MatrixZwei[i, j] = 0.0;
                    if (i + row == j)
                        MatrixZwei[i, j] = 1.0;
                }
            }

            for (int i = 0; i < row; i++)
            {
                if (MatrixZwei[i, i] != 0)
                {
                    double intTemp = MatrixZwei[i, i]*1.0;//乘以1.0保证不因整形丢失精度
                    for (int j = 0; j < row * 2; j++)
                    {
                        MatrixZwei[i, j] = MatrixZwei[i, j] / intTemp;
                    }
                }
                for (int j = 0; j < row; j++)
                {
                    if (j == i)
                        continue;
                    double intTemp = MatrixZwei[j, i]*1.0;
                    for (int k = 0; k < row * 2; k++)
                    {
                        MatrixZwei[j, k] = MatrixZwei[j, k] - MatrixZwei[i, k] * intTemp;
                    }
                }
            }

            for (int i = 0; i < row; i++)
            {
                for (int j = 0; j < row; j++)
                {
                    iMatrixInv[i, j] = MatrixZwei[i, j + row];
                }
            }
            return iMatrixInv;
        }

        ///   <summary> 
        ///   矩阵加法 
        ///   </summary> 
        ///   <param   name= "MatrixEin "> </param> 
        ///   <param   name= "MatrixZwei "> </param> 
        public static double[,] AddMatrix(double[,] MatrixEin, double[,] MatrixZwei)
        {
            double[,] MatrixResult = new double[MatrixEin.GetLength(0), MatrixZwei.GetLength(1)];
            int M = MatrixEin.GetLength(0),N= MatrixEin.GetLength(1);
            for (int i = 0; i < M; i++)
                for (int j = 0; j < N; j++)
                    MatrixResult[i, j] = MatrixEin[i, j] + MatrixZwei[i, j];
            return MatrixResult;
        }
        ///   <summary> 
         ///   一维矩阵加法 
         ///   </summary> 
         ///   <param   name= "MatrixEin "> </param> 
         ///   <param   name= "MatrixZwei "> </param> 
        public static double[] AddMatrix(double[] MatrixEin, double[] MatrixZwei)
        {
            if (MatrixEin.Count()!= MatrixZwei.Count())
            {
                return null;
            }
            int N = MatrixEin.Count();
            double[] MatrixResult = new double[N];
            for (int i = 0; i < N; i++)
                MatrixResult[i] = MatrixEin[i] + MatrixZwei[i];    
            return MatrixResult;
        }

        ///   <summary> 
        ///   矩阵减法 
        ///   </summary> 
        ///   <param   name= "MatrixEin "> </param> 
        ///   <param   name= "MatrixZwei "> </param> 
        public static double[,] SubMatrix(double[,] MatrixEin, double[,] MatrixZwei)
        {
            double[,] MatrixResult = new double[MatrixEin.GetLength(0), MatrixZwei.GetLength(1)];
            int M = MatrixEin.GetLength(0), N = MatrixEin.GetLength(1);
            for (int i = 0; i < M; i++)
                for (int j = 0; j < N; j++)
                    MatrixResult[i, j] = MatrixEin[i, j] - MatrixZwei[i, j];
            return MatrixResult;
        }

        ///   <summary> 
        ///   矩阵乘法 
        ///   </summary> 
        ///   <param   name= "MatrixEin "> </param> 
        ///   <param   name= "MatrixZwei "> </param> 
        public static double[,] MultiplyMatrix(double[,] MatrixEin, double[,] MatrixZwei)
        {
            double[,] MatrixResult = new double[MatrixEin.GetLength(0), MatrixZwei.GetLength(1)];
            for (int i = 0; i < MatrixEin.GetLength(0); i++)
            {
                for (int j = 0; j < MatrixZwei.GetLength(1); j++)
                {
                    for (int k = 0; k < MatrixEin.GetLength(1); k++)
                    {
                        MatrixResult[i, j] += MatrixEin[i, k] * MatrixZwei[k, j];
                    }
                }
            }
            return MatrixResult;
        }
        ///   <summary> 
        ///   二维矩阵和实数乘法 
        ///   </summary> 
        ///   <param   name= "MatrixEin "> </param> 
        ///   <param   name= "MatrixZwei "> </param> 
        public static double[,] MultiplyRe(double[,] MatrixEin, double A)
        {
            double[,] MatrixResult = new double[MatrixEin.GetLength(0), MatrixEin.GetLength(1)];
            for (int i = 0; i < MatrixEin.GetLength(0); i++)
            {
                for (int j = 0; j < MatrixEin.GetLength(1); j++)
                {
                    MatrixResult[i, j] = MatrixEin[i, j] * A;
                }
            }
            return MatrixResult;
        }
        ///   <summary> 
        ///   一维矩阵和实数乘法 
        ///   </summary> 
        ///   <param   name= "MatrixEin "> </param> 
        ///   <param   name= "MatrixZwei "> </param> 
        public static double[] MultiplyRe(double[] MatrixEin, double A)
        {
            int N = MatrixEin.Count();
            double[] MatrixResult = new double[N];
            for (int i = 0; i < N; i++)
            {
                MatrixResult[i] = MatrixEin[i] * A;
            }
            return MatrixResult;
        }

        /////   <summary> 
        /////   矩阵对应行列式的值 
        /////   </summary> 
        /////   <param   name= "MatrixEin "> </param> 
        /////   <returns> </returns> 
        //public static double ResultDeterminant(double[,] MatrixEin)
        //{
        //    return MatrixEin[0, 0] * MatrixEin[1, 1] * MatrixEin[2, 2] + MatrixEin[0, 1] * MatrixEin[1, 2] * MatrixEin[2, 0] + MatrixEin[0, 2] * MatrixEin[1, 0] * MatrixEin[2, 1]
        //    - MatrixEin[0, 2] * MatrixEin[1, 1] * MatrixEin[2, 0] - MatrixEin[0, 1] * MatrixEin[1, 0] * MatrixEin[2, 2] - MatrixEin[0, 0] * MatrixEin[1, 2] * MatrixEin[2, 1];

        //}

        /// <summary>
        /// 递归计算行列式的值
        /// </summary>
        /// <param name="MatrixEin">矩阵</param>
        /// <returns></returns>
        public static double Determinant(double[,] MatrixEin)
        {
            int N = MatrixEin.GetLength(0);
            //二阶及以下行列式直接计算
            if (N != MatrixEin.GetLength(1))
            {
                return 0;
            }
            else if (N == 0)
            {
                return 0;
            }
            else if (N == 1)
            {
                return MatrixEin[0, 0];
            }
            else if (N == 2)
            {
                return MatrixEin[0, 0] * MatrixEin[1, 1] - MatrixEin[0, 1] * MatrixEin[1, 0];
            }


            //对第一行使用“加边法”递归计算行列式的值
            double dSum = 0, dSign = 1;
            for (int i = 0; i < N; i++)
            {
                double[,] matrixTemp = new double[N - 1, N - 1];

                for (int j = 0; j < N - 1; j++)
                {
                    for (int k = 0; k < N - 1; k++)
                    {
                        matrixTemp[j, k] = MatrixEin[j + 1, k >= i ? k + 1 : k];
                    }
                }

                dSum += (MatrixEin[0, i] * dSign * Determinant(matrixTemp));
                dSign = dSign * -1;
            }

            return dSum;
        }



    }
}
