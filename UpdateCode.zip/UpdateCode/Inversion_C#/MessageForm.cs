﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VelocitySpectral
{
    public partial class MessageForm : Form
    {
        public MessageForm(string Txt="", int type = 0)
        {
            InitializeComponent();
            StartPosition = FormStartPosition.CenterParent;
            Information(Txt, type);
        }
        public void Information(string Txt, int type = 0)
        {
            if (type == 0)
            {
                LeftButton.Visible = false;
                RightButton.Visible = false;
                MiddleButton.Visible = true;
                ActiveControl = MiddleButton;
            }
            else if (type == 1)
            {
                LeftButton.Visible = true;
                RightButton.Visible = true;
                MiddleButton.Visible = false;
                ActiveControl = LeftButton;
            }
            string Txt2 = "";
            if (Txt.Length > 10)//当字符串长度大于7时换行
            {
                for (int i = 0; i < Txt.Length; i++)
                {
                    Txt2 += Txt[i];
                    if (Txt[i] == '，' || Txt[i] == ',')
                    {
                        Txt2 += "\r\n";
                    }
                }
            }
            else
            {
                Txt2 = Txt;
            }
            MessageDisp.Text = Txt2;

            SizeF sizeL = MessageDisp.Size;
            int WidthTemp = (int)(sizeL.Width * 1.2);
            if (WidthTemp > 320)
            {
                Width = WidthTemp;
            }
            else
            {
                Width = 320;
            }
            MessageDisp.Location = new Point((int)(this.Width / 2 - sizeL.Width / 2), (int)(this.Height * 0.2 - sizeL.Height / 2));
            this.Controls.Add(MessageDisp);
            MessageDisp.BringToFront();
        }
        private void LeftButton_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.OK;
        }

        private void MiddleButton_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
        }

        private void RightButton_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
        }
    }
}
