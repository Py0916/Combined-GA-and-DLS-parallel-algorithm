﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VelocitySpectral
{
    public class GAInversion
    {
        private static readonly double VsUpScale = 1.5, VsDownScale = 0.5;//Vs上下限比例，在
        private static readonly double ThkUpScale = 1.5, ThkDownScale = 0.5;//随机生成二进制编码函数ModelToBinary中用到
        private static readonly double WeightC = 1.5;//适应度系数，一般取1.2-2.0，在计算权重函数WeightCalculate中用到
        private static readonly double Pc1 = 0.95, Pc2 = 0.8, Pc3 = 0.6, Pm1 = 0.1, Pm2 = 0.09, Pm3 = 0.01;
        //2021-1109改
        //注：原本遗传算子速度占用7字节，厚度占用6字节，这样速度间隔和厚度间隔太大，使得DLS反演结果经遗传算法生成的基因失真太大
        //今将速度字节改为10，表示50~1023+50m/s，间隔1m/s
        //将厚度字节改为9，表示0.1~51.2m，间隔0.1m

        public static string ModelToBinary_OneMod(double[] Vs, double[] Thk)
        {
            string MatrixOut;
            Random Rand = new Random();
            double  ResizeVs,  ResizeThk;


            MatrixOut = "";//字符串初始化//默认基因长度13,7+6
            for (int j = 0; j < Vs.Count() - 1; j++)
            {
                ResizeVs = Vs[j] - 50;//2 ^ 7对应50~50 + 10 * (2 ^ 7 - 1) = 1320

                ResizeThk = (Thk[j] - 0.1)*10;//2 ^ 6对应0.5~0.5 + 0.5 * (2 ^ 6 - 1) = 31
                MatrixOut += BinaryFillBit(Convert.ToString((int)Math.Round(ResizeVs), 2), 10) + BinaryFillBit(Convert.ToString((int)Math.Round(ResizeThk), 2), 9);//进行补位操作
            }
            //最后一层没有thk故分开
            ResizeVs = Vs.Last() - 50;//2 ^ 7对应50~50 + 10 * (2 ^ 7 - 1) = 1320

            MatrixOut += BinaryFillBit(Convert.ToString((int)Math.Round(ResizeVs), 2), 10);

            return MatrixOut;
        }
        public static string[] ModelToBinary(int Popsize, double[] Vs, double[] Thk, int type = 2)
        {
            string[] MatrixOut = new string[Popsize];
            Random Rand = new Random();
            double RawVs, ResizeVs, RawThk, ResizeThk;
            string tempString;
            for (int i = 0; i < Popsize; i++)
            {
                tempString = "";//字符串初始化//默认基因长度13,7+6
                for (int j = 0; j < Vs.Count() - 1; j++)
                {
                    if (type == 0)
                    {
                        RawVs = Vs[j] * (VsDownScale + Rand.NextDouble() * (VsUpScale - VsDownScale));
                        RawThk = Thk[j];//type==0时定深度
                    }
                    else if (type == 1)
                    {
                        RawVs = Vs[j];//type==1时定速度
                        RawThk = Thk[j] * (ThkDownScale + Rand.NextDouble() * (ThkUpScale - ThkDownScale));
                    }
                    else
                    {
                        RawVs = Vs[j] * (VsDownScale + Rand.NextDouble() * (VsUpScale - VsDownScale));
                        RawThk = Thk[j] * (ThkDownScale + Rand.NextDouble() * (ThkUpScale - ThkDownScale));
                    }

                    ResizeVs = RawVs - 50;//2 ^ 7对应50~50 + 10 * (2 ^ 7 - 1) = 1320

                    ResizeThk = (RawThk - 0.1) * 10;//2 ^ 6对应0.5~0.5 + 0.5 * (2 ^ 6 - 1) = 31
                    tempString += BinaryFillBit(Convert.ToString((int)Math.Round(ResizeVs), 2), 10) + BinaryFillBit(Convert.ToString((int)Math.Round(ResizeThk), 2), 9);//进行补位操作
                }
                //最后一层没有thk故分开
                if (type == 1)
                {
                    RawVs = Vs[Vs.Count() - 1];
                }
                else
                {
                    RawVs = Vs[Vs.Count() - 1] * (VsDownScale + Rand.NextDouble() * (VsUpScale - VsDownScale));
                }

                ResizeVs = RawVs - 50;//2 ^ 7对应50~50 + 10 * (2 ^ 7 - 1) = 1320

                tempString += BinaryFillBit(Convert.ToString((int)Math.Round(ResizeVs), 2), 10);
                if (tempString == null)
                {
                    break;
                }
                MatrixOut[i] = tempString;
            }
            return MatrixOut;
        }
        public static string BinaryFillBit(string StrIn, int BitNum)
        {
            string StrOut = StrIn;
            if (StrIn.Count() < BitNum)
            {
                for (int i = 0; i < BitNum - StrIn.Count(); i++)
                {
                    StrOut = '0' + StrOut;
                }
            }
            return StrOut;
        }
        public static Tuple<double[][], double[][]> BinaryToModel(string[] MatrixIn, double[] VsMod, double[] ThkMod, int Type)
        {
            int M = MatrixIn.Count(), N = (MatrixIn[0].Count() + 9) / 19;//默认基因长度13,7+6
            double[][] Vs = new double[M][], Thk = new double[M][];
            for (int i = 0; i < M; i++)
            {
                Vs[i] = new double[N];
                Thk[i] = new double[N - 1];
                for (int j = 0; j < N - 1; j++)
                {

                    Vs[i][j] = Convert.ToInt32(MatrixIn[i].Substring(j * 19, 10), 2) + 50;
                    Thk[i][j] = (Convert.ToInt32(MatrixIn[i].Substring(j * 19 + 10, 9), 2)+1) * 0.1;
                    if (Type == 0)//定深
                    {
                        Thk[i][j] = ThkMod[j];
                    }
                    else if (Type == 1)//定速
                    {
                        Vs[i][j] = VsMod[j];
                    }
                }
                Vs[i][N - 1] = Convert.ToInt32(MatrixIn[i].Substring((N - 1) * 19, 10), 2) + 50;
                if (Type == 1)//定速
                {
                    Vs[i][N - 1] = VsMod[N - 1];
                }
            }
            return new Tuple<double[][], double[][]>(Vs, Thk);
        }
        public static double RmsErrorCalculate(double[] TheoryVs, double[] TestVs)
        {
            int N = TheoryVs.Count();
            double RmsError;
            double temp = 0;

            for (int j = 0; j < N; j++)
            {
                temp += Math.Pow(TheoryVs[j] - TestVs[j], 2);
            }
            RmsError = Math.Sqrt(temp / N);

            return RmsError;
        }
        public static double Multi_RmsErrorCalculate(double[][] TheoryVs, double[][] TestVs)
        {
            int M = TheoryVs.Count();
            int N = TheoryVs[0].Count();
            double RmsError;
            double temp = 0;
            int MM = 0;
            for (int i = 0; i < M; i++)
            {
                for (int j = 0; j < N; j++)
                {
                    if (TheoryVs[i][j] != 0 && TestVs[i][j] != 0)
                    {
                        temp += Math.Pow(TheoryVs[i][j] - TestVs[i][j], 2);
                        MM++;
                    }

                }
            }

            RmsError = Math.Sqrt(temp / MM);

            return RmsError;
        }
        public static double[] WeightCalculate(double[] RmsErrorIn, int InvTimes)
        {

            int M = RmsErrorIn.Count();
            double[] RmsError = new double[M];
            RmsError = DataClone(RmsErrorIn);
            //for (int i = 0; i < M; i++)
            //{
            //    RmsError[i] = RmsErrorIn[i];//保证数据是深拷贝，不影响原输入数据
            //}
            double[] f_RmsError = new double[M];
            double f_a, f_b, f_c, temp,temp2;
            temp = RmsError.Max();
            for (int i = 0; i < M; i++)
            {
                RmsError[i] = temp * 1.1 - RmsError[i];//因均方根误差为负向评价参数，此处反转一下，保证最小不为0，乘1.1
            }
            temp = RmsError.Sum();
            for (int i = 0; i < M; i++)
            {
                RmsError[i] = RmsError[i] / temp;//反转后的均方根误差作归一化
            }

            f_c = WeightC + InvTimes * 0.05;
            if (f_c > 2) f_c = 2;//f_c随着迭代次数增加逐渐增大，上限2.0
            f_a = (f_c - 1) * RmsError.Average() / (RmsError.Max() - RmsError.Min());//计算原理见公式2-8毛承英
            f_b = (RmsError.Max() - f_c * RmsError.Average()) * RmsError.Average() / (RmsError.Max() - RmsError.Average());
            if (f_a * RmsError.Min() + f_b < 0)
            {
                f_a = RmsError.Average() / (RmsError.Average() - RmsError.Min());
                f_b = -RmsError.Average() * RmsError.Min() / (RmsError.Average() - RmsError.Min());
            }
            for (int i = 0; i < M; i++)
            {
                f_RmsError[i] = f_a * RmsError[i] + f_b;
            }


            //if (Math.Abs(f_RmsError.Sum() - 1) > 0.01)
            //{
            //    temp = f_RmsError.Sum();
            //    for (int i = 0; i < M; i++)
            //    {
            //        f_RmsError[i] = f_RmsError[i] / temp;//因上一步可能出现负数改变总权重为1，此处重新归一化到1
            //    }
            //}
            //2021-1109采用下面的做法做归一化，上面的做法无法将负权重变为正数
            temp = 0.001-f_RmsError.Min();
            temp2 = f_RmsError.Sum()+temp*f_RmsError.Count();
            for (int i = 0; i < M; i++)
            {
                f_RmsError[i] = (f_RmsError[i] + temp)/temp2;//因上一步可能出现负数改变总权重为1，此处重新归一化到1
            }
            return f_RmsError;
        }
        public static string[] HeredityMatrix(string[] MatrixIn, double[] f_RmsError)//返回遗传后的矩阵，包含选择、交叉、变异
        {
            int M = MatrixIn.Count(), N = MatrixIn[0].Count(), NumSave;
            double RandTemp, Pc = 0.6, Pm = 0.1;
            Random Rand = new Random();
            string[] MatrixSort = new string[M], MatrixOut = new string[M];
            //均方根误差计算放在主程序里，方便程序跳出

            //直接保留上一次的最优结果
            //圆盘法先选择，每个选择的结果均经交叉和变异判断
            //选择结果如有重复，删除，重新选择，直到全部选完
            //交叉采用多点交叉，判断是否交叉，随机确定交叉点，交叉

            ////排序开始
            //以下排序太繁琐，采用List排序
            //int[] NumSort = new int[M];
            //Dictionary<int ,double> Dic = new Dictionary<int, double>();
            //for (int i=0;i<M;i++)
            //{
            //    Dic.Add(i, f_RmsError[i]);
            //}
            //Dic = Dic.OrderByDescending(o => o.Value).ToDictionary(p => p.Key, o => o.Value);
            //int j = 0;
            //foreach (var item in Dic)
            //{
            //    NumSort[j] = item.Key;
            //    j++;
            //}
            //    for (int i=0;i<M;i++)
            //{
            //    MatrixSort[i] = MatrixIn[NumSort[i]];
            //}
            ////排序结束

            List<double> f_RmsSort = f_RmsError.ToList();
            double[] f_RmsSum = new double[M];
            int ChooseTemp = -1, CrossTemp, CrossPoint1, CrossPoint2, tempInt;
            string SaveString = "";
            int[] NumChoose = new int[M];
            f_RmsSort.Sort();
            f_RmsSort.Reverse();
            for (int i = 0; i < M; i++)
            {
                MatrixSort[i] = MatrixIn[Array.IndexOf(f_RmsError, f_RmsSort[i])];
            }
            //f_RmsSort.RemoveAt(0);//去掉权重最大的数，因为这个数直接进入下一轮
            f_RmsSum[0] = f_RmsSort[0];
            for (int i = 1; i < M - 1; i++)
            {
                f_RmsSum[i] = f_RmsSort[i] + f_RmsSum[i - 1];
            }
            f_RmsSum[M - 1] = 1;//保证随机数选到1的时候不超出

            MatrixOut[0] = MatrixSort[0];//把上一次误差最小的结果直接保存进入下一次遗传
            NumSave = 1;
            while (NumSave < M)
            {
                RandTemp = Rand.NextDouble();//选择
                for (int j = 0; j < M; j++)
                {
                    if (RandTemp <= f_RmsSum[j])
                    {
                        ChooseTemp = j;
                        SaveString = MatrixSort[j];
                        break;
                    }
                }
                if (f_RmsSort[ChooseTemp] >= f_RmsSort.Average())
                {
                    Pc = (Pc2 * (f_RmsSort.Max() - f_RmsSort[ChooseTemp]) + Pc3 * (f_RmsSort[ChooseTemp] - f_RmsSort.Average())) / (f_RmsSort.Max() - f_RmsSort.Average());
                }
                else
                {
                    Pc = (Pc1 * (f_RmsSort.Average() - f_RmsSort[ChooseTemp]) + Pc2 * (f_RmsSort[ChooseTemp] - f_RmsSort.Min())) / (f_RmsSort.Average() - f_RmsSort.Min());
                }

                if (f_RmsSort[ChooseTemp] >= f_RmsSort.Average())
                {
                    Pm = (Pm2 * (f_RmsSort.Max() - f_RmsSort[ChooseTemp]) + Pm3 * (f_RmsSort[ChooseTemp] - f_RmsSort.Average())) / (f_RmsSort.Max() - f_RmsSort.Average());
                }
                else
                {
                    Pm = (Pm1 * (f_RmsSort.Average() - f_RmsSort[ChooseTemp]) + Pm2 * (f_RmsSort[ChooseTemp] - f_RmsSort.Min())) / (f_RmsSort.Average() - f_RmsSort.Min());
                }

                RandTemp = Rand.NextDouble();//交叉
                if (RandTemp < Pc)
                {
                    CrossTemp = (int)Math.Round(Rand.NextDouble() * (M - 1));//随机确定交叉对象
                    CrossPoint1 = (int)Math.Round(Rand.NextDouble() * (N - 2));//此处N-2保证交叉点不会选到最后一个
                    CrossPoint2 = (int)Math.Round(Rand.NextDouble() * (N - 2));
                    if (CrossPoint1 > CrossPoint2)//保证CrossPoint1在左，CrossPoint2在右
                    {
                        tempInt = CrossPoint1;
                        CrossPoint1 = CrossPoint2;
                        CrossPoint2 = tempInt;
                    }
                    else if (CrossPoint1 == CrossPoint2)
                    {
                        CrossPoint2 = CrossPoint2 + 1;//前面CrossPoint2不会是最后一个点，+1不会溢出
                    }
                    SaveString = MatrixSort[ChooseTemp].Substring(0, CrossPoint1) + MatrixSort[CrossTemp].Substring(CrossPoint1, CrossPoint2 - CrossPoint1) + MatrixSort[ChooseTemp].Substring(CrossPoint2);
                }
                RandTemp = Rand.NextDouble();//变异
                if (RandTemp < Pm)
                {
                    tempInt = (int)Math.Round(Rand.NextDouble() * (N - 1));

                    if (SaveString[tempInt] == '0')
                    {
                        SaveString = SaveString.Substring(0, tempInt) + '1' + SaveString.Substring(tempInt + 1);
                    }
                    else
                    {
                        SaveString = SaveString.Substring(0, tempInt) + '0' + SaveString.Substring(tempInt + 1);
                    }
                }
                if (!MatrixOut.Contains(SaveString))//判断遗传后的字符串是否在已经选择的列表里，如不在则存入
                {
                    MatrixOut[NumSave] = SaveString;
                    NumSave++;
                }
            }
            return MatrixOut;
        }
        private static T DataClone<T>(T RealObject)
        {
            using (System.IO.Stream objectStream = new System.IO.MemoryStream())
            {
                //利用 System.Runtime.Serialization序列化与反序列化完成引用对象的复制
                System.Runtime.Serialization.IFormatter formatter = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();
                formatter.Serialize(objectStream, RealObject);
                objectStream.Seek(0, System.IO.SeekOrigin.Begin);
                return (T)formatter.Deserialize(objectStream);
            }
        }
    }
}
