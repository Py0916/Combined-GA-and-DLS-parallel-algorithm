﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VelocitySpectral
{
    public class Complex
    {
        #region 字段

        //复数实部
        private double real = 0.0;

        //复数虚部
        private double imaginary = 0.0;

        #endregion

        #region 属性

        /// <summary>
        /// 获取或设置复数的实部
        /// </summary>
        public double Real
        {
            get
            {
                return real;
            }
            set
            {
                real = value;
            }
        }

        /// <summary>
        /// 获取或设置复数的虚部
        /// </summary>
        public double Imaginary
        {
            get
            {
                return imaginary;
            }
            set
            {
                imaginary = value;
            }
        }

        #endregion


        #region 构造函数

        /// <summary>
        /// 默认构造函数，得到的复数为0
        /// </summary>
        public Complex()
            : this(0, 0)
        {

        }

        /// <summary>
        /// 只给实部赋值的构造函数，虚部将取0
        /// </summary>
        /// <param name="dbreal">实部</param>
        public Complex(double dbreal)
            : this(dbreal, 0)
        {

        }

        /// <summary>
        /// 一般形式的构造函数
        /// </summary>
        /// <param name="dbreal">实部</param>
        /// <param name="dbImage">虚部</param>
        public Complex(double dbreal, double dbImage)
        {
            real = dbreal;
            imaginary = dbImage;
        }

        /// <summary>
        /// 以拷贝另一个复数的形式赋值的构造函数
        /// </summary>
        /// <param name="other">复数</param>
        public Complex(Complex other)
        {
            real = other.real;
            imaginary = other.imaginary;
        }

        #endregion

        #region 重载

        //加法的重载
        public static Complex operator +(Complex comp1, Complex comp2)
        {
            return comp1.Add(comp2);
        }

        //减法的重载
        public static Complex operator -(Complex comp1, Complex comp2)
        {
            return comp1.Substract(comp2);
        }

        //乘法的重载
        public static Complex operator *(Complex comp1, Complex comp2)
        {
            return comp1.Multiply(comp2);
        }

        //除法的重载
        public static Complex operator /(Complex comp1, Complex comp2)
        {
            return comp1.Divide(comp2);
        }

        //==的重载
        public static bool operator ==(Complex z1, Complex z2)
        {
            return ((z1.real == z2.real) && (z1.imaginary == z2.imaginary));
        }

        //!=的重载
        public static bool operator !=(Complex z1, Complex z2)
        {
            if (z1.real == z2.real)
            {
                return (z1.imaginary != z2.imaginary);
            }
            return true;
        }

        /// <summary>
        /// 重载ToString方法,打印复数字符串
        /// </summary>
        /// <returns>打印字符串</returns>
        public override string ToString()
        {
            if (Real == 0 && imaginary == 0)
            {
                return string.Format("{0}", 0);
            }
            if (Real == 0 && (imaginary != 1 && imaginary != -1))
            {
                return string.Format("{0} i", imaginary);
            }
            if (imaginary == 0)
            {
                return string.Format("{0}", Real);
            }
            if (imaginary == 1)
            {
                return string.Format("i");
            }
            if (imaginary == -1)
            {
                return string.Format("- i");
            }
            if (imaginary < 0)
            {
                return string.Format("{0} - {1} i", Real, -imaginary);
            }
            return string.Format("{0} + {1} i", Real, imaginary);
        }

        #endregion

        #region 公共方法

        /// <summary>
        /// 复数加法
        /// </summary>
        /// <param name="comp">待加复数</param>
        /// <returns>返回相加后的复数</returns>
        public Complex Add(Complex comp)
        {
            double x = real + comp.real;
            double y = imaginary + comp.imaginary;

            return new Complex(x, y);
        }

        /// <summary>
        /// 复数减法
        /// </summary>
        /// <param name="comp">待减复数</param>
        /// <returns>返回相减后的复数</returns>
        public Complex Substract(Complex comp)
        {
            double x = real - comp.real;
            double y = imaginary - comp.imaginary;

            return new Complex(x, y);
        }

        /// <summary>
        /// 复数乘法
        /// </summary>
        /// <param name="comp">待乘复数</param>
        /// <returns>返回相乘后的复数</returns>
        public Complex Multiply(Complex comp)
        {
            double x = real * comp.real - imaginary * comp.imaginary;
            double y = real * comp.imaginary + imaginary * comp.real;

            return new Complex(x, y);
        }

        /// <summary>
        /// 复数和实数乘法
        /// </summary>
        /// <param name="comp">待乘实数</param>
        /// <returns>返回相乘后的复数</returns>
        public Complex MultiplyRe(double comp)
        {
            double x = real * comp;
            double y = imaginary * comp;

            return new Complex(x, y);
        }
        /**
		 * 实现复数的除法
		 * 
		 * @param cpxX - 与指定复数相除的复数
		 * @return Complex型，指定复数除与cpxX之商
		 */
        //public Complex Divide(Complex cpxX)
        //{
        //    double e, f, x, y;

        //    if (Math.Abs(cpxX.real) >= Math.Abs(cpxX.imaginary))
        //    {
        //        e = cpxX.imaginary / cpxX.real;
        //        f = cpxX.real + e * cpxX.imaginary;

        //        x = (real + imaginary * e) / f;
        //        y = (imaginary - real * e) / f;
        //    }
        //    else
        //    {
        //        e = cpxX.real / cpxX.imaginary;
        //        f = cpxX.imaginary + e * cpxX.real;

        //        x = (real * e + imaginary) / f;
        //        y = (imaginary * e - real) / f;
        //    }

        //    return new Complex(x, y);
        //}
        /// <summary>
        /// 复数除法
        /// </summary>
        /// <param name="comp">A/B中的B</param>
        /// <returns>返回相除后的复数</returns>
        /// a+bi/c+di=(a+bi)(c-di)/(c^2+d^2)
        public Complex Divide(Complex comp)
        {
            double Denominator = Math.Pow(comp.Abs(), 2);
            Complex temp = new Complex(comp.Real, -comp.imaginary);
            //Multiply(temp).MultiplyRe(1 / Denominator);


            return Multiply(temp).MultiplyRe(1 / Denominator);
        }
        /// <summary>
        /// 获取复数的模/幅度
        /// </summary>
        /// <returns>返回复数的模</returns>
        public double Abs()
        {
            return Math.Sqrt(real * real + imaginary * imaginary);
        }

        /// <summary>
        /// 获取复数的相位角，取值范围（-π，π]
        /// </summary>
        /// <returns>返回复数的相角</returns>
        public double GetAngle()
        {
            #region 原先求相角的实现，后发现Math.Atan2已经封装好后注释
            ////实部和虚部都为0
            //if (real == 0 && imaginary == 0)
            //{
            //    return 0;
            //}
            //if (real == 0)
            //{
            //    if (imaginary > 0)
            //        return Math.PI / 2;
            //    else
            //        return -Math.PI / 2;
            //}
            //else
            //{
            //    if (real > 0)
            //    {
            //        return Math.Atan2(imaginary, real);
            //    }
            //    else
            //    {
            //        if (imaginary >= 0)
            //            return Math.Atan2(imaginary, real) + Math.PI;
            //        else
            //            return Math.Atan2(imaginary, real) - Math.PI;
            //    }
            //}
            #endregion

            return Math.Atan2(imaginary, real);
        }

        /// <summary>
        /// 获取复数的共轭复数
        /// </summary>
        /// <returns>返回共轭复数</returns>
        public Complex Conjugate()
        {
            return new Complex(this.real, -this.imaginary);
        }
        /// <summary>
        /// 将实数或复数赋值给复数
        /// </summary>
        /// <returns>返回共轭复数</returns>
        public Complex SetReAndIm(double Re = 0, double Im = 0)
        {


            return new Complex(Re, Im);
        }

        #endregion
        //     /**
        //* 计算复数的模
        //* 
        //* @return double型，指定复数的模
        //*/
        //     public double Abs()
        //     {
        //         // 求取实部和虚部的绝对值
        //         double x = Math.Abs(real);
        //         double y = Math.Abs(imaginary);

        //         if (real == 0)
        //             return y;
        //         if (imaginary == 0)
        //             return x;


        //         // 计算模
        //         if (x > y)
        //             return (x * Math.Sqrt(1 + (y / x) * (y / x)));

        //         return (y * Math.Sqrt(1 + (x / y) * (x / y)));
        //     }

        /**
		 * 计算复数的根
		 * 
		 * @param n - 待求根的根次
		 * @param cpxR - Complex型数组，长度为n，返回复数的所有根
		 */
        public void Root(int n, Complex[] cpxR)
        {
            if (n < 1)
                return;

            double q = Math.Atan2(imaginary, real);
            double r = Math.Sqrt(real * real + imaginary * imaginary);
            if (r != 0)
            {
                r = (1.0 / n) * Math.Log(r);
                r = Math.Exp(r);
            }

            for (int k = 0; k <= n - 1; k++)
            {
                double t = (2.0 * k * 3.1415926 + q) / n;
                cpxR[k] = new Complex(r * Math.Cos(t), r * Math.Sin(t));
            }
        }
        /**
		 * 计算复数的实幂指数
		 * 
		 * @param dblW - 待求实幂指数的幂次
		 * @return Complex型，复数的实幂指数值
		 */
        public Complex Pow(double dblW)
        {
            // 常量
            const double PI = 3.14159265358979;

            // 局部变量
            double r, t;

            // 特殊值处理
            if ((real == 0) && (imaginary == 0))
                return new Complex(0, 0);

            // 幂运算公式中的三角函数运算
            if (real == 0)
            {
                if (imaginary > 0)
                    t = 1.5707963268;
                else
                    t = -1.5707963268;
            }
            else
            {
                if (real > 0)
                    t = Math.Atan2(imaginary, real);
                else
                {
                    if (imaginary >= 0)
                        t = Math.Atan2(imaginary, real) + PI;
                    else
                        t = Math.Atan2(imaginary, real) - PI;
                }
            }

            // 模的幂
            r = Math.Exp(dblW * Math.Log(Math.Sqrt(real * real + imaginary * imaginary)));

            // 复数的实幂指数
            return new Complex(r * Math.Cos(dblW * t), r * Math.Sin(dblW * t));
        }
        /**
		 * 计算自然指数e的复幂指数
		 * 
		 * @param cpxW - 待求复幂指数的幂次
		 * @param n 
		 * @return Complex型，复数的复幂指数值
		 */
        //e^x=5→x=ln5;//所以：
        //e^(ix)=(e^x)^i=5^i=cos(ln5)+i* sin(ln5)
        //5^(3+i)=125*5^i
        //=125*(cos(ln5)+i* sin(ln5))
        //=125cos(ln5)+i*125*sin(ln5)
        public Complex ExpComplex()
        {
            double A = Math.Exp(real);
            Complex temp, ExpComplexOut;
            temp = new Complex(Math.Cos(imaginary), Math.Sin(imaginary));
            ExpComplexOut = temp.MultiplyRe(A);
            return ExpComplexOut;
        }
        /**
		 * 计算复数的复幂指数
		 * //验证该函数有误，后续在研究
		 * @param cpxW - 待求复幂指数的幂次
		 * @param n - 控制参数，默认值为0。当n=0时，求得的结果为复幂指数的主值
		 * @return Complex型，复数的复幂指数值
		 */
        public Complex PowError(Complex cpxW, int n = 0)
        {
            // 常量
            const double PI = 3.14159265358979;
            // 局部变量
            double r, s, u, v;

            // 特殊值处理
            if (real == 0)
            {
                if (imaginary == 0)
                    return new Complex(0, 0);

                s = 1.5707963268 * (Math.Abs(imaginary) / imaginary + 4 * n);
            }
            else
            {
                s = 2 * PI * n + Math.Atan2(imaginary, real);

                if (real < 0)
                {
                    if (imaginary > 0)
                        s = s + PI;
                    else
                        s = s - PI;
                }
            }

            // 求幂运算公式
            r = 0.5 * Math.Log(real * real + imaginary * imaginary);
            v = cpxW.real * r + cpxW.imaginary * s;
            u = Math.Exp(cpxW.real * r - cpxW.imaginary * s);

            return new Complex(u * Math.Cos(v), u * Math.Sin(v));
        }

        /**
		 * 计算复数的自然对数
		 * 
		 * @return Complex型，复数的自然对数值
		 */
        public Complex Log()
        {
            double p = Math.Log(Math.Sqrt(real * real + imaginary * imaginary));
            return new Complex(p, Math.Atan2(imaginary, real));
        }

        /**
		 * 计算复数的正弦
		 * 
		 * @return Complex型，复数的正弦值
		 */
        public Complex Sin()
        {
            Complex temp1 = new Complex(-imaginary, real), temp2 = new Complex(imaginary, -real);
            return (temp1.ExpComplex() - temp2.ExpComplex()) / new Complex(0, 2);
            //int i;
            //double x, y, y1, br, b1, b2;
            //double[] c = new double[6];

            //// 切比雪夫公式的常数系数
            //c[0] = 1.13031820798497;
            //c[1] = 0.04433684984866;
            //c[2] = 0.00054292631191;
            //c[3] = 0.00000319843646;
            //c[4] = 0.00000001103607;
            //c[5] = 0.00000000002498;

            //y1 = Math.Exp(imaginary);
            //x = 0.5 * (y1 + 1 / y1);
            //br = 0;
            //if (Math.Abs(imaginary) >= 1)
            //    y = 0.5 * (y1 - 1 / y1);
            //else
            //{
            //    b1 = 0;
            //    b2 = 0;
            //    y1 = 2 * (2 * imaginary * imaginary - 1);
            //    for (i = 5; i >= 0; --i)
            //    {
            //        br = y1 * b1 - b2 - c[i];
            //        if (i != 0)
            //        {
            //            b2 = b1;
            //            b1 = br;
            //        }
            //    }

            //    y = imaginary * (br - b1);
            //}

            //// 组合计算结果
            //x = x * Math.Sin(real);
            //y = y * Math.Cos(real);

            //return new Complex(x, y);
        }

        /**
		 * 计算复数的余弦
		 * 
		 * @return Complex型，复数的余弦值
		 */
        public Complex Cos()
        {
            Complex temp1 = new Complex(-imaginary, real), temp2 = new Complex(imaginary, -real);
            return (temp1.ExpComplex() + temp2.ExpComplex()) / new Complex(2);
            //int i;
            //double x, y, y1, br, b1, b2;
            //double[] c = new double[6];

            //// 切比雪夫公式的常数系数
            //c[0] = 1.13031820798497;
            //c[1] = 0.04433684984866;
            //c[2] = 0.00054292631191;
            //c[3] = 0.00000319843646;
            //c[4] = 0.00000001103607;
            //c[5] = 0.00000000002498;

            //y1 = Math.Exp(imaginary);
            //x = 0.5 * (y1 + 1 / y1);
            //br = 0;
            //if (Math.Abs(imaginary) >= 1)
            //    y = 0.5 * (y1 - 1 / y1);
            //else
            //{
            //    b1 = 0;
            //    b2 = 0;
            //    y1 = 2 * (2 * imaginary * imaginary - 1);
            //    for (i = 5; i >= 0; --i)
            //    {
            //        br = y1 * b1 - b2 - c[i];
            //        if (i != 0)
            //        {
            //            b2 = b1;
            //            b1 = br;
            //        }
            //    }

            //    y = imaginary * (br - b1);
            //}

            //// 组合计算结果
            //x = x * Math.Cos(real);
            //y = -y * Math.Sin(real);

            //return new Complex(x, y);
        }

        /**
		 * 计算复数的正切
		 * 
		 * @return Complex型，复数的正切值
		 */
        public Complex Tan()
        {
            return Sin().Divide(Cos());
        }
    }
}
