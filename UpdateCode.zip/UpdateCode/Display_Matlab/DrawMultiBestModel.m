clear;
clc;
close all;
% file='HardModel.mat';
% file='SoftModel.mat';
file='FieldModel.mat';
Cell1=struct2cell(load(file));
Data=Cell1{1,1};
% Vs=Data(1:6,:);
% Thk=Data(7:11,:);
% Rms=Data(12,:);

if(file(1)=='H')
    %Ӳ�в�
    V_True=[200;400;300;400;500;600];
    Thk_True=[2;2;2;4;4];
    M=9;
    N1=6;
    Vs=Data(1:6,:);
    Thk=Data(7:11,:);
    Rms=Data(12,:);
elseif(file(1)=='S')
    %���в�
    V_True=[200;300;400;200;500;600];
    Thk_True=[2;2;4;2;4];
    M=8;
    N1=6;
    Vs=Data(1:6,:);
    Thk=Data(7:11,:);
    Rms=Data(12,:);
elseif(file(1)=='F')
   %��ʵ�ز�
    V_True=[200;300;400;500];
    Thk_True=[5;5;5];
    Vs=Data(1:4,:);
    Thk=Data(5:7,:);
    M=10;
    N1=4;
end
[V_Layer0,H_Layer0]=GetLayerPoint(V_True,Thk_True);
M=10;
% Vs(:,5)=Vs(:,1);
% Thk(:,5)=Thk(:,1);
% Thk(:,8)=Thk(:,1);
% Thk(:,6)=Thk(:,1);
% Thk(:,7)=Thk(:,1);
for i=1:N1
V_m(i,1)=mean(Vs(i,1:M));
end
for i=1:N1-1
Thk_m(i,1)=mean(Thk(i,1:M));
end
[V_LayerM,H_LayerM]=GetLayerPoint(V_m,Thk_m);
figure;
plot(V_LayerM,H_LayerM,'r-','LineWidth',3);hold on;
Leg=["Average","Individual"];

for j=1:M
    [V_Layer,H_Layer]=GetLayerPoint(Vs(:,j),Thk(:,j));
    plot(V_Layer,H_Layer,'b-','LineWidth',1.5);hold on;
%     Leg=[Leg,num2str(j)];
end
plot(V_LayerM,H_LayerM,'r-','LineWidth',3);
legend(Leg);

%title(['True and best model of each time']);

xlabel('S-wave velocity(m/s)');
ylabel('Depth(m)');
axis([0 1000 0 30]);
set(gca,'YDir','reverse');
set(gcf,'position',[300 300 300 300]);

figure;
plot(V_LayerM,H_LayerM,'r-','LineWidth',1.5);hold on;
xlabel('S-wave velocity(m/s)');
ylabel('Depth(m)');
axis([0 1000 0 30]);
set(gca,'YDir','reverse');
set(gcf,'position',[300 300 300 300]);

figure;
plot(V_LayerM,H_LayerM,'ro-','LineWidth',1);hold on;
Leg=["Average","Individual"];

for j=1:M
    [V_Layer,H_Layer]=GetLayerPoint(Vs(:,j),Thk(:,j));
    plot(V_Layer,H_Layer,'b+','LineWidth',1);hold on;
%     Leg=[Leg,num2str(j)];
end
plot(V_LayerM,H_LayerM,'ro-','LineWidth',1);hold on;
legend(Leg);

%title(['True and best model of each time']);

xlabel('S-wave velocity(m/s)');
ylabel('Depth(m)');
axis([0 1000 0 30]);
set(gca,'YDir','reverse');
set(gcf,'position',[300 300 300 300]);

figure;
plot(V_Layer0,H_Layer0,'r-','LineWidth',2);hold on;
Leg="True";
V_error=zeros(12,1);
Thk_error=zeros(10,1);
for i=1:N1
V_m(i,1)=mean(Vs(i,1:M));
V_error(2*i-1,1)=min(Vs(i,1:M));
V_error(2*i,1)=max(Vs(i,1:M));
end
for i=1:N1-1
Thk_m(i,1)=mean(Thk(i,1:M));
Thk_error(2*i-1)=min(Thk(i,1:M));
Thk_error(2*i)=max(Thk(i,1:M));
end

    
    plot(V_LayerM,H_LayerM,'r','LineWidth',2);hold on;



% %title(['True and best model of each time']);

xlabel('S-wave velocity(m/s)');
ylabel('Depth(m)');
axis([0 1000 0 30]);
set(gca,'YDir','reverse');
set(gcf,'position',[300 300 300 300]);
for i=1:N1
    x1=V_error(2*i-1);
    x2=V_error(2*i);
    y1=(H_Layer(2*i-1)+H_Layer(2*i))/2;
    y2=y1;
    plot([x1,x2],[y1,y2],'g-','LineWidth',2);hold on;
end
for i=1:N1-1
    x1=(V_Layer(2*i)+V_Layer(2*i+1))/2;
    x2=x1;
    y1=Thk_error(2*i-1)+H_Layer(2*i-1);
    y2=Thk_error(2*i)+H_Layer(2*i-1);
    plot([x1,x2],[y1,y2],'g-','LineWidth',2);hold on;
end
legend("Average","Individual","ErrorBar");

function[V,H]= GetLayerPoint(Vs,Thk)
Nv=size(Vs,1);
V=zeros(Nv*2,1);
H=zeros(Nv*2,1);
V(1,1)=Vs(1);
H(1,1)=0;
for i=1:Nv-1
    V(2*i,1)=Vs(i);
    V(2*i+1,1)=Vs(i+1);
    H(2*i,1)=H(2*i-1,1)+Thk(i);
    H(2*i+1,1)=H(2*i,1);
end
V(2*Nv,1)=Vs(Nv);
H(2*Nv,1)=30;
end