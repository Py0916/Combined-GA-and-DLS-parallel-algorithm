%��ȡGA���ݽ���ļ�
clear;clc;
close all;

% file='Ӳ_100Ⱥ_20��_3��_1���_1.GA_DLS_M_R';%1.6bad
% file='Ӳ_100Ⱥ_20��_3��_1���_2.GA_DLS_M_R';%1.6 bad
% file='Ӳ_100Ⱥ_20��_3��_1���_3.GA_DLS_M_R';%1.8good+best

% file='Ӳ_100Ⱥ_20��_3��_1���_9.GA_DLS_M_R';%RMS0.99good+best
file='Ӳ_100Ⱥ_20��_3��_1���_10.GA_DLS_M_R';%RMS0.99goodchoose

idraw=37;

IsSavePng=0;

fid=fopen(file);
tline=fscanf(fid,'%f',[5,1]);
Nf=tline(1);%Ƶ����
M=tline(2);%����
N=tline(3);%Ⱥ��
Nl=tline(4);%����
Nm=tline(5);%ģʽ��
Freq=fscanf(fid,'%f',[Nf,1]);
Vs=fscanf(fid,'%f',[Nl,M+1]);
Thk=fscanf(fid,'%f',[Nl-1,M+1]);
for i=1:M+1
    V_M(i,:,:)=fscanf(fid,'%f',[Nf,Nm]);
end
Rms=fscanf(fid,'%f',[N,M]);
fclose(fid);
%���ݶ�ȡ���
step=1;
II=floor(M/step);
for i=1:II
    figure;
    [FF,V1,V2]=DeleteZero2(Freq,V_M(1,:,1),V_M(i*step+1,:,1));
    plot(FF,V1,'ro','MarkerFaceColor','r','MarkerSize',5);hold on;
    plot(FF,V2,'bo','MarkerFaceColor','b','MarkerSize',5);hold on;
    
    [FF,V1,V2]=DeleteZero2(Freq,V_M(1,:,2),V_M(i*step+1,:,2));
    plot(FF,V1,'r*','MarkerFaceColor','r','MarkerSize',5);hold on;
    plot(FF,V2,'b*','MarkerFaceColor','b','MarkerSize',5);hold on;
    
    [FF,V1,V2]=DeleteZero2(Freq,V_M(1,:,3),V_M(i*step+1,:,3));
    plot(FF,V1,'ro','MarkerSize',5);hold on;
    plot(FF,V2,'bo','MarkerSize',5);hold on;
    
%     [FF,VV]=DeleteZero(Freq,V_M(1,:,1));
%     plot(FF,VV,'ro','MarkerFaceColor','r','MarkerSize',5);hold on;
%     [FF,VV]=DeleteZero(Freq,V_M(i*step+1,:,1));
%     plot(FF,VV,'bo','MarkerFaceColor','b','MarkerSize',5);hold on;
%     
%     [FF,VV]=DeleteZero(Freq,V_M(1,:,2));
%     plot(FF,VV,'r*', 'MarkerFaceColor','r');hold on;
%     [FF,VV]=DeleteZero(Freq,V_M(i*step+1,:,2));
%     plot(FF,VV,'b*', 'MarkerFaceColor','b');hold on;
%     
%     [FF,VV]=DeleteZero(Freq,V_M(1,:,3));
%     plot(FF,VV,'ro', 'MarkerSize',5);hold on;
%     [FF,VV]=DeleteZero(Freq,V_M(i*step+1,:,3));
%     plot(FF,VV,'bo', 'MarkerSize',5);hold off;
    
%     title(['Dispersion points of generation:',num2str(i*step)]);
%     title(['Dispersion points of true and inverse model']);
    xlabel('Frequency(Hz)');
    ylabel('Phase velocity(m/s)');
%     legend('M0-The' ,'M0-Inv','M1-The','M1-Inv','M2-The','M2-Inv');
%     legend('M0-True' ,'M0-Inverted','M1-True','M1-Inverted','M2-True','M2-Inverted');
%     legend('M0-True' ,'M0-Inverted','M1-True','M1-Inverted');
    set(gcf,'position',[300 300 400 350]);
    if(IsSavePng)
        saveas(gca,['GA_Dispersion_Iteration-',num2str(i*step),'.png']);
    end
end


if(file(1)=='Ӳ')
    %Ӳ�в�
    V_True=[200;400;300;400;500;600];
    Thk_True=[2;2;2;4;4];
else
    %���в�
    V_True=[200;300;400;200;500;600];
    Thk_True=[2;2;4;2;4];
end
V_True=[200;300;400;500];
Thk_True=[5;5;5];
[V_Layer0,H_Layer0]=GetLayerPoint(V_True,Thk_True);

step=5;
II=floor(M/step);
for i=1:II
    figure;
    plot(V_Layer0,H_Layer0,'r--','LineWidth',3);hold on;
    Leg="Initial";
    
    for j=1:step
        [V_Layer,H_Layer]=GetLayerPoint(Vs(:,(i-1)*step+j+1),Thk(:,(i-1)*step+j+1));
        plot(V_Layer,H_Layer,'-','LineWidth',1.5);hold on;
        Leg=[Leg,num2str((i-1)*step+j)];
        
    end
    legend(Leg);
    
%     title(['Model of generation:',num2str((i-1)*step+1),'~',num2str(i*step)]);
    
    xlabel('Vs(m/s)');
    ylabel('Depth(m)');
    axis([0 1000 0 30]);
    set(gca,'YDir','reverse');
    set(gcf,'position',[300 300 300 250]);
    if(IsSavePng)
        saveas(gca,['GA_Model_Iteration-',num2str((i-1)*step+1),'~',num2str(i*step),'.png']);
    end
end
 figure;
    plot(V_Layer0,H_Layer0,'r-','LineWidth',3);hold on;
    Leg="Initial";
%     Vs(2,M+1)=396;Vs(3,M+1)=302;

        [V_Layer,H_Layer]=GetLayerPoint(Vs(:,idraw+1),Thk(:,idraw+1));
        plot(V_Layer,H_Layer,'-','LineWidth',1.5);hold on;
        Leg=[Leg,"Inverted"];
    legend(Leg);
    
%     title(['True and Inverse model by GA-DLS']);
    xlabel('Vs(m/s)');
    ylabel('Depth(m)');
    axis([0 1000 0 30]);
    set(gca,'YDir','reverse');
    set(gcf,'position',[300 300  400 350]);
    

DrawPhaseMap(Freq,V_M,idraw);
%      figure;
%     plot(V_Layer0,H_Layer0,'r-','LineWidth',3);hold on;
%     Leg="True";
%     
%         [V_Layer,H_Layer]=GetLayerPoint(Vs(:,17),Thk(:,17));
%         plot(V_Layer,H_Layer,'-','LineWidth',1.5);hold on;
%         Leg=[Leg,"Inverse"];
%     legend(Leg);
%     
%     title(['True and Inverse model by GA-DLS']);
%     xlabel('Vs(m/s)');
%     ylabel('Depth(m)');
%     axis([0 1000 0 25]);
%     set(gca,'YDir','reverse');
%     set(gcf,'position',[300 300 300 400]);


%����������ͼ
% M=M/2;
Z=Rms(:,1:M);
% X=1:M;
% Y=1:N;
% [XX,YY]=meshgrid(X,Y);
% 
% figure;
% mesh(XX,YY,Z);
% % title('Rms variation by generation and individual');
% xlabel('Generation');
% ylabel('Individual');
% zlabel('Rms(m/s)');
ZZ=sort(Z,1);
% set(gcf,'position',[300 300 400 350]);
% if(IsSavePng)
%     saveas(gca,['GA_Rms_G_I','.png']);
% end
% 
% figure;
% mesh(XX,YY,ZZ);
% % title('RMSE variation by generation and individual');
% xlabel('Generation');
% ylabel('Individual');
% zlabel('RMSE(m/s)');
% set(gcf,'position',[300 300 400 350]);
% set(gca,'yTick',[0:40:80]);
% set(gca,'YTickLabel',[0,50,100]);
% if(IsSavePng)
%     saveas(gca,['GA_Rms_G_I_Sort','.png']);
% end
% figure;
% surf(XX,YY,Z);
% figure;
% plot3(XX,YY,Z);
for i=1:M
    ZMin(i)=min(ZZ(:,i));
    ZMax(i)=max(ZZ(1:10,i));
    ZAvg(i)=sum(ZZ(1:10,i))/10;
end
figure;
plot(ZMin,'ro-','MarkerFaceColor','r','MarkerSize',3);hold on;
plot(ZMax,'go-','MarkerFaceColor','g','MarkerSize',3);hold on;
plot(ZAvg,'bo-','MarkerFaceColor','b','MarkerSize',3);hold on;
% axis([0 15 0 60]);
% tmp1=ZMin(end);tmp2=length(ZMin);
tmp1=ZMin(8);tmp2=8;
    plot(tmp2,tmp1,'black:o','MarkerFaceColor','black','MarkerSize',3);
    tmp1=round(tmp1,2);
    text(tmp2+0.5,tmp1+2.5,['(',num2str(tmp2),',',num2str(tmp1),')'],'color',[0,0,0]);
% title('Rms variation by generation');
xlabel('Generation');
ylabel('RMSE(m/s)');
legend('Min of 10% individual','Max of 10% individual','Avg of 10% individual');
set(gcf,'position',[300 300 400 350]);
if(IsSavePng)
    saveas(gca,['GA_Rms','.png']);
end


%����������ͼ����
% for i=1:M
%     Rms(i,:)=fgetl(fid);
% end
% �����Ƕ�ȡ���ݽ��rms����
% clear;clc;
% close all;
% dataA=importdata('2.M_Rms');
% Z=dataA';
% [M,N]=size(Z);
% X=1:N;
% Y=1:M;
% [XX,YY]=meshgrid(X,Y);
% ZZ=sort(Z,1);
% figure;
% mesh(XX,YY,Z);
% figure;
% surf(XX,YY,Z);
% figure;
% plot3(XX,YY,Z);
% for i=1:N
%     ZMin(i)=min(Z(:,i));
% end
% figure;
% plot(ZMin);
function[F1,V1]= DeleteZero(F,V)
Nf=size(F);
VV=reshape(V,Nf);
ii=1;
tmp=VV(ii);
for i=1:Nf
    if(VV(i)~=0)
        F1(ii)=F(i);
        V1(ii)=V(i);
        ii=ii+1;
    end
end
end
function[F1,Out_V1,Out_V2]= DeleteZero2(F,V1,V2)
Nf=size(F);
VV1=reshape(V1,Nf);
VV2=reshape(V2,Nf);
ii=1;

for i=1:Nf
    if(VV1(i)>49&VV2(i)>49)
        F1(ii)=F(i);
        Out_V1(ii)=VV1(i);
        Out_V2(ii)=VV2(i);
        ii=ii+1;
    end
end
end
function[V,H]= GetLayerPoint(Vs,Thk)
Nv=size(Vs,1);
V=zeros(Nv*2,1);
H=zeros(Nv*2,1);
V(1,1)=Vs(1);
H(1,1)=0;
for i=1:Nv-1
    V(2*i,1)=Vs(i);
    V(2*i+1,1)=Vs(i+1);
    H(2*i,1)=H(2*i-1,1)+Thk(i);
    H(2*i+1,1)=H(2*i,1);
end
V(2*Nv,1)=Vs(Nv);
H(2*Nv,1)=30;
end