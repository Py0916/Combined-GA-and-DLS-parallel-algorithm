%��ȡDSL���ݽ���ļ�
clear;clc;
close all;
file='��_3��_���1_6.DLS_M_R';%Choosed
% file='Ӳ_3��_���1_2.DLS_M_R';%Choosed
IsSavePng=0;

fid=fopen(file);
tline=fscanf(fid,'%f',[4,1]);
Nf=tline(1);%Ƶ����
M=tline(2);%��������
Nl=tline(3);%����
Nm=tline(4);%ģʽ��
Freq=fscanf(fid,'%f',[Nf,1]);
Vs=fscanf(fid,'%f',[Nl,M]);
Thk=fscanf(fid,'%f',[Nl-1,M]);
for i=1:M+1
    V_M(i,:,:)=fscanf(fid,'%f',[Nf,Nm]);
end
Rms=fscanf(fid,'%f',[M,1]);
fclose(fid);
%���ݶ�ȡ���
step=1;
II=floor(M/step);
for i=1:II
    figure;
    
    [FF,VV]=DeleteZero(Freq,V_M(1,:,1));
    plot(FF,VV,'ro','MarkerFaceColor','r','MarkerSize',5);hold on;
    [FF,VV]=DeleteZero(Freq,V_M(i*step+1,:,1));
    plot(FF,VV,'bo','MarkerFaceColor','b','MarkerSize',5);hold on;

    [FF,VV]=DeleteZero(Freq,V_M(1,:,2));
    plot(FF,VV,'r*', 'MarkerFaceColor','r');hold on;
    [FF,VV]=DeleteZero(Freq,V_M(i*step+1,:,2));
    plot(FF,VV,'b*', 'MarkerFaceColor','b');hold on;

    [FF,VV]=DeleteZero(Freq,V_M(1,:,3));
    plot(FF,VV,'ro', 'MarkerSize',5);hold on;
    [FF,VV]=DeleteZero(Freq,V_M(i*step+1,:,3));
    plot(FF,VV,'bo', 'MarkerSize',5);hold off;

%     title(['Dispersion points of true and inverse model']);
%     title(['Dispersion points of iteration:',num2str(i*step)]);
    xlabel('Frequency(Hz)');
    ylabel('Phase velocity(m/s)');
    legend('M0-The' ,'M0-Inv','M1-The','M1-Inv','M2-The','M2-Inv');
    legend('M0-Measured' ,'M0-Initial','M1-Measured','M1-Initial','M2-Measured','M2-Initial');
%     legend('M0-Measured' ,'M0-Inverted','M1-Measured','M1-Inverted','M2-Measured','M2-Inverted');
    set(gcf,'position',[300 300 400 350]);
    if(IsSavePng)
        saveas(gca,['DLS_Dispersion_Iteration-',num2str(i*step),'.png']);
    end
end


if(file(1)=='Ӳ')
    %Ӳ�в�
    V_True=[200;400;300;400;500;600];
    Thk_True=[2;2;2;4;4];
else
    %���в�
    V_True=[200;300;400;200;500;600];
    Thk_True=[2;2;4;2;4];
end
[V_Layer0,H_Layer0]=GetLayerPoint(V_True,Thk_True);

step=1;
II=floor(M/step);
II=floor(M/step);
for i=1:II
    figure;
    plot(V_Layer0,H_Layer0,'r-','LineWidth',3);hold on;
    Leg="True";
    
    for j=1:step
        [V_Layer,H_Layer]=GetLayerPoint(Vs(:,(i-1)*step+j),Thk(:,(i-1)*step+j));
        plot(V_Layer,H_Layer,'-','LineWidth',1.5);hold on;
        Leg=[Leg,num2str((i-1)*step+j)];
        if(j==1)
%             Leg=["True","Initial"];
            Leg=["True","Inverted"];
        end
    end
    legend(Leg);

%     title(['Model of iteration:',num2str((i-1)*step+1),'~',num2str(i*step)]);
%     if(j==1)
%             title("True and Inverse model");
%         end
    xlabel('S-wave velocity(m/s)');
    ylabel('Depth(m)');
    axis([0 1000 0 20]);
    set(gca,'YDir','reverse');
    set(gcf,'position',[300 300 300 250]);
    if(IsSavePng)
        saveas(gca,['DLS_Model_Iteration-',num2str((i-1)*step+1),'~',num2str(i*step),'.png']);
    end
end

Z=Rms;
figure;
plot(Z,'ro-','MarkerFaceColor','r','MarkerSize',3);hold on;

% title('RMSE variation by iteration');
    xlabel('Iteration');
    ylabel('RMSE(m/s)');
    set(gcf,'position',[300 300 300 250]);
    axis([0 15 0 60]);
%     [tmp1,tmp2]=min(Z);
tmp1=Z(end);tmp2=length(Z);
    plot(tmp2,tmp1,'black:o','MarkerFaceColor','black','MarkerSize',3);
    tmp1=round(tmp1,2);
    text(tmp2-2.5,tmp1+4.5,['(',num2str(tmp2),',',num2str(tmp1),')'],'color',[0,0,0]);
    if(IsSavePng)
        saveas(gca,['DLS_Rms','.png']);
    end
function[F1,V1]= DeleteZero(F,V)
Nf=size(F);
VV=reshape(V,Nf);
ii=1;
tmp=VV(ii);
while(tmp==0)
    ii=ii+1;
    tmp=VV(ii);
end
F1=F(ii:end);
V1=VV(ii:end);
end
function[F1,Out_V1,Out_V2]= DeleteZero2(F,V1,V2)
Nf=size(F);
VV1=reshape(V1,Nf);
VV2=reshape(V2,Nf);
ii=1;
tmp1=VV1(ii);
tmp2=VV2(ii);
while(tmp1<50||tmp2<50)
    ii=ii+1;
    tmp1=VV1(ii);
    tmp2=VV2(ii);
end
F1=F(ii:end);
Out_V1=VV1(ii:end);
Out_V2=VV2(ii:end);
end
function[V,H]= GetLayerPoint(Vs,Thk)
Nv=size(Vs,1);
V=zeros(Nv*2,1);
H=zeros(Nv*2,1);
V(1,1)=Vs(1);
H(1,1)=0;
for i=1:Nv-1
    V(2*i,1)=Vs(i);
    V(2*i+1,1)=Vs(i+1);
    H(2*i,1)=H(2*i-1,1)+Thk(i);
    H(2*i+1,1)=H(2*i,1);
end
V(2*Nv,1)=Vs(Nv);
H(2*Nv,1)=30;
end