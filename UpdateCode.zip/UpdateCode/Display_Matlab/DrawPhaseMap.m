function DrawPhaseMap(Freq,V_M,ii)
file='G:\GA_DSL�о�\����\4013.txt';
% file='C:\Users\lez-pc\Desktop\Zd_3.txt';
DataRaw=load(file);
% DataSWS=zeros(2048,18);
DataSWS=DataRaw(:,2:end);%ƫ�ƾ�8m�������2m��18��������Ƶ��4096����������2048
%�ٶȽ���100~1000֮�䣬p=0.001~0.01��dV=50,��Ӧ��p=1/(V+dv*i)
%t���ֵ������tmax=T-Xmax/Vmin,����T=N/Fs������ʱ��
dX=1;
X=1:dX:18;
Fs=4096;

N=size(DataSWS,1);
nX=size(DataSWS,2);

dV=2;
V=dV:dV:1000;

freq=(1:1:50)*Fs/N;
wave_fft=zeros(N/2,nX);
for i=1:nX
    tmp=fft(DataSWS(:,i));
    wave_fft(:,i)=tmp(1:N/2)./abs(tmp(1:N/2));
end
lv=length(V);
lf=length(freq);
E=zeros(lv,lf);
for j=1:lf
    for i=1:lv
        for k=1:nX
            E(i,j)=E(i,j)+exp(1i*2*pi*freq(j)*X(k)/V(i))*wave_fft(j+1,k);
        end
    end
    E(:,j)=abs(E(:,j)./max(abs(E(:,j))));%��ÿ��Ƶ�ʽ��й�һ��
%     E(:,j)=abs(E(:,j));%�����й�һ����Ҫ�ɾ�һЩ
end
% E2=E(50:500,5:30);
E2=E;
x=[0 100];
y=[0 1000];
[n,m]=size(E2);
[xi,yi]=meshgrid(1:0.1:m,1:1:n);
zi=interp2(E2,xi,yi,'linear');
figure;
imagesc(x,y,zi);hold on;
colormap(jet);
% colorbar;
set(gca,'YDir','normal');
xlabel('Frequency(Hz)');
ylabel('Phase velocity(m/s)');
% X1=[14,16.4,19];Y1=[348,268,212];
% X2=[21.8,24.8,28,31.4,35,38.8];Y2=[404,350,308,268,234,211];
% X3=[35,38.8,42.8,47,51.4,56];Y3=[310,276,248,230,220,208];
% plot(X1,Y1,'bo-','MarkerFaceColor','b','MarkerSize',4);hold on;
% plot(X2,Y2,'bo-','MarkerFaceColor','b','MarkerSize',4);hold on;
% plot(X3,Y3,'bo-','MarkerFaceColor','b','MarkerSize',4);hold on;
% Vmm=struct2cell(load('G:\GA_DSL�о�\����\V_m.mat'));
% V_M=Vmm{1,1};
% FF=struct2cell(load('G:\GA_DSL�о�\����\Freq.mat'));
% Freq=FF{1,1};
% ii=56;
% [FF,V1,V2]=DeleteZero2(Freq,V_M(1,:,1),V_M(ii+1,:,1));
%     plot(FF,V1,'wo-','MarkerFaceColor','w','MarkerSize',5);hold on;
%     plot(FF,V2,'bo','MarkerFaceColor','b','MarkerSize',5);hold on;
%     
%     [FF,V1,V2]=DeleteZero2(Freq,V_M(1,:,2),V_M(ii+1,:,2));
%     plot(FF,V1,'w*-','MarkerFaceColor','w','MarkerSize',5);hold on;
%     plot(FF,V2,'b*','MarkerFaceColor','b','MarkerSize',5);hold on;
%     
%     [FF,V1,V2]=DeleteZero2(Freq,V_M(1,:,3),V_M(ii+1,:,3));
%     plot(FF,V1,'wo-','MarkerSize',5);hold on;
%     plot(FF,V2,'bo','MarkerSize',5);hold on;
    [FF,VV]=DeleteZero(Freq,V_M(1,:,1));
    plot(FF,VV,'co-','MarkerFaceColor','c','MarkerSize',4);hold on;
    [FF,VV]=DeleteZero(Freq,V_M(ii+1,:,1));
    plot(FF,VV,'bo','MarkerFaceColor','b','MarkerSize',4);hold on;
    
    [FF,VV]=DeleteZero(Freq,V_M(1,:,2));
    plot(FF,VV,'c*-', 'MarkerFaceColor','c','MarkerSize',8);hold on;
    [FF,VV]=DeleteZero(Freq,V_M(ii+1,:,2));
    plot(FF,VV,'b*', 'MarkerFaceColor','b','MarkerSize',3);hold on;
% legend("M0-Measured","M1-Measured")
%     legend("M0-Measured","M0-Inverted","M1-Measured","M1-Inverted")

    [FF,VV]=DeleteZero(Freq,V_M(1,:,3));
    plot(FF,VV,'c+-', 'MarkerSize',5);hold on;
    [FF,VV]=DeleteZero(Freq,V_M(ii+1,:,3));
    plot(FF,VV,'b+', 'MarkerSize',5);hold off;
    legend("M0-Measured","M0-Inverted","M1-Measured","M1-Inverted","M2-Measured","M2-Inverted")
    
end
function[F1,V1]= DeleteZero(F,V)
Nf=size(F);
VV=reshape(V,Nf);
ii=1;
tmp=VV(ii);
for i=1:Nf
    if(VV(i)~=0)
        F1(ii)=F(i);
        V1(ii)=V(i);
        ii=ii+1;
    end
end
end
function[F1,Out_V1,Out_V2]= DeleteZero2(F,V1,V2)
Nf=size(F);
VV1=reshape(V1,Nf);
VV2=reshape(V2,Nf);
ii=1;

for i=1:Nf
    if(VV1(i)>49&VV2(i)>49)
        F1(ii)=F(i);
        Out_V1(ii)=VV1(i);
        Out_V2(ii)=VV2(i);
        ii=ii+1;
    end
end
end